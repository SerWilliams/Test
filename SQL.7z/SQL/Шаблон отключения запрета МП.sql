select op.ID_op, op.opdate "���� ��������", dd.fullname, tp.id_top, op.opguid, op.opnumber,tp.fullname
from doc_Egais.Wbinformbreg_Doc_Header_Tbl dev
  left join whs.docreference dref on dev.id_document = dref.id_doc_depend
  left JOIN whs.DOCUMENT doc ON doc.id_document = dref.id_doc_master
  left join whs.doc_op do ON do.id_document = doc.id_document
  left join whs.operation op on do.id_op= op.id_op
  left join whs.typeop ty on ty.id_top = op.id_top
  join whs.typeop tp on tp.id_top = op.id_top
  join whs.warehouse dd on nvl(op.id_wso,op.id_wsi)=dd.id_ws
  where --dev.wb_number like '24474'
  op.id_op = -1126155548

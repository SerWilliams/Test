select
/*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/
tt.id_top,
 tt.FULLNAME,
 st.id_send_status,
 st.name,
 w.code "W_O_Code",
 w.fullname "W_O_fullname",
 o.OPDATE,
 o.OPNUMBER,
 o.opsum,
 wd.docnumber,
 wd.docdate,
 c2.code,
 c2.name,
 c2.inn,
 c2.kpp,
 ss.description,
 cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment",
 cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment",
 ss.last_work_date,
 o.ID_TOP,
 o.ID_OP
  from doc_egais.send_doc_egais_tbl ss
  join doc_egais.send_doc_status_egais_tbl st
    on st.id_send_status = ss.id_send_status
  join whs.operation o
    on o.ID_OP = ss.id_send_base
  join whs.contractor c2
    on c2.id_contr = o.ID_CONTR
  left join whs.docreference df
    on df.id_doc_master = ss.id_document
  left join whs.document wd
    on wd.id_document = ss.id_document
  left join doc_egais.ticket_doc_header_tbl th
    on th.id_document = nvl(ss.id_ticket, df.id_doc_depend)
  left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
  left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
  join whs.warehouse w
    on w.id_ws = o.ID_WSI
and w.lg1  in (101,201)
     join whs.typeop tt on tt.id_top = o.id_top
                    and upper(tt.fullname) like upper('������%�������') 
 where o.OPDATE >= '01.01.2016'
       and o.OPDATE < '30.09.2016'
   and ss.id_send_type = 1
--and tt.ID_TOP in (1,15,598,597,559,4,106,142,634,446,17,635,447,542,169,473,477)
and ss.id_send_status in (1,3,2,4,5,8,9,7)
--and ss.id_send_status in (3,7)
and w.lg1 = 101
--and wd.docnumber = '5880' and w.code='160365'
--and o.opsum = 0

--and o.id_op not in (-1007130849,)

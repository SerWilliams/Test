-- ����� ���� ��������� �������� �� �� � ��
select distinct c.name, a.NAME, max (op.OPDATE)
from
whs.article a
join whs.op_art oa on oa.ID_ART = a.ID_ART
join whs.operation op on op.ID_OP = oa.ID_OP
join whs.typeop t on t.ID_TOP = op.ID_TOP
join whs.contractor c on c.id_contr = op.ID_CONTR
join whs.warehouse wh on wh.id_ws = op.ID_WSI
where  wh.name = '��������' --op.id_wsi = 2707-- and op.opdate >= '01.01.2014'
and a.CODE in ('1000003761')
and c.name <> '��������'
group by a.NAME, c.name
order by a.name, max (op.OPDATE)


select * from doc_egais.send_doc_egais_tbl
  where id_send_base in (-1082573065,-1022846617)
  
select w.id_ws, r2.*, d.* from retail.registr_tbl r2 
join whs.warehouse w on w.code = r2.wscode
left join whs.document d on d.id_document = r2.id_document
--where r2.id_document = 328286392
where w.name = '���������' and r2.reg_id_b in ('FB-000000245148662', 'FB-000000245148661', 'FB-000000112537892')--and r2.move_type = 'P' and r2.alc_code = '0012389000001423573' --order by r2.id_registr desc



select * from WHS.ARTICLE_KISCONTR_LINK where code_egais = '0012389000001423573';-- id_article=112958;

--where r2.id_document in ('281416705','219539540')  
select * from whs.document_history where id_document in ( 357234141)
select * from whs.doc_status

select * from doc_egais.document_tbl where id_document in ( 357234141)

-- �������� ����� ���������� �2
select * from doc_egais.ACTRECALCAPR2_DOC_CONTENT_TBL where id_document in ( 357234141)
select * from doc_egais.actrecalcapr2_doc_confirm_tbl
doc_egais.ACTRECALCAPR2_DOC_CONTENT_TBL
doc_egais.ACTRECALCAPR2_DOC_CONFIRM_TBL
doc_egais.ACTRECALCAPR2_DOC_HEADER_TBL


select * from whs.doctype where id_doctype = 509

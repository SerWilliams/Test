select
/*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/
 tt.FULLNAME,
 st.id_send_status,
 st.name,
 w.code "W_O_Code",
 w.fullname "W_O_fullname",
 o.OPNUMBER,
 o.OPDATE,
 o.opsum,
 wd.docnumber,
 wd.docdate,
 c2.code,
 c2.name,
 c2.inn,
 c2.kpp,
 ss.description,
 cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment",
 cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment",
 ss.last_work_date,
 o.ID_OP,
 o.opguid,
 o.ID_TOP,
 wd.id_document
  from doc_egais.send_doc_egais_tbl ss
  join doc_egais.send_doc_status_egais_tbl st
    on st.id_send_status = ss.id_send_status
  join whs.operation o
    on o.ID_OP = ss.id_send_base
  join whs.contractor c2
    on c2.id_contr = o.ID_CONTR
  left join whs.docreference df
    on df.id_doc_master = ss.id_document
  left join whs.document wd
    on wd.id_document = ss.id_document
  left join doc_egais.ticket_doc_header_tbl th
    on th.id_document = nvl(ss.id_ticket, df.id_doc_depend)
  left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
  left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
  join whs.warehouse w
    on w.id_ws = o.ID_WSI
and w.lg1  in (101,201)
     join whs.typeop tt on tt.id_top = o.id_top
                      and upper(tt.fullname) like upper('������%�������') 
 where o.OPDATE >= '01.07.2016'
       and o.OPDATE < '20.07.2016'
   and ss.id_send_type = 1
and ss.id_send_status in (3,9,7)
and w.fullname like '���� ��%'
--and wd.docnumber = '5880' and w.code='160365'
--and o.opsum = 0

--and o.id_op in (-1007130849)

select * from doc_egais.ticket_doc_opresult_tbl
select * from doc_egais.ticket_doc_header_tbl
select * from doc_egais.ticket_doc_result_tbl
select * from whs.typeop tt where tt.id_top = 106

select
wh.fullname "�� ������"
, wh.code "��� ��"
, c.fullname "�� ����"
, c.code "��� ��"
, sd.id_send_status
, sd.id_doctype "��� �� � �������"
, sd.id_document "�� � �������"
, op.OPNUMBER
, op.OPDATE
, op.opsum
from whs.operation op
JOIN whs.op_art oa ON oa.id_op=op.id_op
JOIN whs.article ar ON ar.id_art=oa.id_art
JOIN whs.art_moreinfo am ON am.id_art=ar.id_art and am.id_add = 62
--����������� �������
left join whs.op_moreinfo om on om.id_op = op.id_op and om.id_add = 667 --om.vbool "�����������?"
--�� � ��
join whs.warehouse wh on wh.id_ws = op.ID_WSO
left join whs.contractor c on c.id_contr = op.id_contr
--������ � ������� �����
left join doc_egais.send_doc_egais_tbl sd on sd.id_send_base = op.ID_OP
-- ��, ��������� � ���������
left join whs.doc_op do on do.id_op = op.id_op
left join whs.document doc on doc.id_document = do.id_document and doc.id_doctype = 481
left join whs.document doc482 on doc482.id_document = do.id_document and doc482.id_doctype = 482
left join doc_egais.ticket_doc_header_tbl th on th.id_document = doc.id_document
left join doc_egais.ticket_doc_result_tbl tr on tr.id_ticket_doc_result = th.id_ticket_doc_result
left join doc_egais.ticket_doc_opresult_tbl opr on opr.id_ticket_doc_opresult = th.id_ticket_doc_opresult
where
op.ID_TOP = 106 and

op.opdate between '01.07.16' and '03.07.16'


-- select adi.id_add from whs.addition adi where adi.name = '���_���' -- ���. ���� ������ � ���. �����


SELECT count (ar.id_art)
--* --ar.code, ar.name, aat.alc_art_code, am.vstring as alcode
FROM whs.operation o
LEFT JOIN whs.op_art oa ON oa.id_op=o.id_op
LEFT JOIN whs.article ar ON ar.id_art=oa.id_art
LEFT JOIN whs.art_moreinfo am ON am.id_art=ar.id_art and am.id_add = 62
--left join whs.alc_art_type aat on aat.alc_art_code = am.vstring -- �����������
WHERE o.opNUMBER = '432367A1137' AND o.opdate = '21.02.2016' AND

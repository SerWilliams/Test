begin
  for cur in (select op.id_op  as parent_op
                    ,op2.id_op as slave_op
                from doc_egais.send_doc_egais_tbl sdt
                join whs.operation op on op.id_op = sdt.id_send_base
                                     and sdt.id_send_type = 1
                join whs.warehouse ws on op.id_wso = ws.id_ws
                join whs.opreference opr on opr.id_opref = op.id_op
                                        and opr.reftype = 'E'
                join whs.operation op2 on op2.id_op = opr.id_op
                left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base
                                                           and sdt.id_send_type = 1
                left join whs.docreference df on df.id_doc_master = sdt2.id_document
                left join doc_egais.ticket_doc_header_tbl tk on tk.id_document = df.id_doc_depend
                left join doc_egais.ticket_doc_result_tbl tor on tor.id_ticket_doc_result = tk.id_ticket_doc_result
                join whs.warehouse ws2 on ws2.id_ws = op2.id_wsi
               where --op.opdate between '01.07.2016' and '30.09.2016' --��� ������ �� ������
                     op2.ID_OP = -1423364878--id_op ������� �����������
                 and ws.lg1 = 601
                 and ws2.lg1 = 101
                 and op.id_top = 169
                 and substr(op.opnumber, 7, 1) like 'A'
                 and sdt.id_send_status = 11
                 and op.opsum <> 0
                 and op2.id_top in (1, 17, 634, 635)
                 and sdt2.id_send_status = 3)
  loop
    begin
      doc_egais.support_api.create_copy_e_doc_to_op(cur.parent_op, cur.slave_op, '��� ���������');
      dbms_output.put_line('parent_op = ' || cur.parent_op || '; slave_op = ' || cur.slave_op || ' - �������');
    exception
      when others then
        dbms_output.put_line('parent_op = ' || cur.parent_op || '; slave_op = ' || cur.slave_op || ' - ' || sqlerrm);
    end;
  end loop;
end;

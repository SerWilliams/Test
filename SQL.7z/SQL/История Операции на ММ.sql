select os.name as StatusName, ho.status, cast (ho.actdate as varchar (20)) as ACTDATE, ho.number, ho.opdate, ho.opsum, u.fullname, ho.username, eq.status as SendStatus,  ho.*, c.name as RC, eq.*
from operation op
join historyop ho on ho.id_op = op.id_op
join opstatus os on os.code = ho.status and os.typeop = op.typeop
join contractor c on c.id_contr = op.id_contr
join users u on u.alias =  ho.username
left join EVENT_QUEUE_OPERATION eq on eq.guid_op = op.opguid
where op.opguid = '3C9FADAEE7B211E53EB800E052AA386A';
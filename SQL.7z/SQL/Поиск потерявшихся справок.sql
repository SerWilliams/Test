select * from 
whs.document doc 
where
--doc.docdate = to_date('10.02.16') and
doc.docdate > to_date ('01.01.16') and
doc.docnumber like '%0000090'
and doc.id_doctype = 481
--doc.docguid in ('C66AE586AF184633BACCC48C462F8CDC','582ED824A2F64102AB9B2CC7034B9629')

-- ����� �������� � ����� (�����) ����������� ����������
select * from doc_egais.send_doc_egais_tbl where id_send_base in  (-1015209676) -- �� ������ �������� �� ��


select op.id_op, op.typeop, op.opsum, op.opnumber, os.name as status, op.* from whs.operation op 
left join whs.opstatus os on os.typeop = op.typeop and os.code = op.status
where op.id_op in (-964793144,-964794071) order by op.opnumber, op.id_op
select * from whs.opstatus
select * from whs.operation op where op.opdate = to_date ('14.01.16') and op.opguid = '0994DBC8D90F100002800080485D935D'
select * from whs.operation op where op.opnumber = '630316G1900' and op.typeop = '10'
select * from whs.document doc where doc.id_document = 191744318
select * from whs.warehouse wh where wh.id_ws = 14001
select * from whs.contractor co where co.id_contr = 104055
select * from whs.historyop ho where ho.id_op = -943253661
select opguid from whs.operation where id_op = -1017526823
select * from whs.historyop ho where ho.id_op = -991565681


-- ����� ����� � ���� �� REPLYGUID �� �� ��
SELECT *
    FROM doc_egais.document_tbl dtbl
    join whs.document doc ON doc.id_Document = dtbl.id_Document --and (doc.id_doctype = 477 or doc.id_doctype = 478)
    WHERE
    --dtbl.id_document in (132341360)
    dtbl.reply_id in hextoraw('658C3FF7CB7F4E06B250F4CEA2D9AB3B')


 SELECT *
   FROM whs.docreference dref
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
       WHERE
      dref.id_doc_master IN (151009283) -- ����������� id ����, ��� (481)
      --dref.id_doc_depend in (140164005)
      and 
      doc2.id_doctype in(483)   -- �������� ��� ��� 2 (2, 483/*,474*/,482,477,478)
      --and doc2.docguid in ('C66AE586AF184633BACCC48C462F8CDC','582ED824A2F64102AB9B2CC7034B9629')
      order by doc2.id_document, doc2.id_doctype
      
      
      
SELECT 'file://///Esb-egais-01/egais/' || to_char(df.lastdate, 'dd-mm-yyyy') || '/' || df.filename, doc.id_document, df.filename, doc.*
FROM whs.DOCUMENT doc
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE
doc.id_document in (186231270,186231272,186231274,186231276,186231278,186231280,186231282,186231284,186231288,186231290)


select * 
from filesregister 
where name in ('DB7521E15AC4489AA91F38B32343A1B6','658C3FF7CB7F4E06B250F4CEA2D9AB3B')


select * from doc_egais.document_tbl where id_document in (176699020,177434293,186231269) 

-- ������� ��������
select task.task_number, os.name, op.* from whs.operation op
join whs.opstatus os on os.typeop = op.typeop and os.code = op.status
left join whs.doc_task_tbl task on task.opguid = op.opguid
where
op.id_op in (-951947922)

select * from whs.article a where a.code = '1019640002'
select * from whs.artstatus



-- ������� �������� � �� ��
select os.name as StatusName, ho.status, cast (ho.actdate as varchar (20)) as ACTDATE, ho.opsum,ho.opdate, u.fullname, ho.username,  ho.*, c.name as Contractor
from whs.operation op
join whs.historyop ho on ho.id_op = op.id_op
join whs.opstatus os on os.code = ho.status and os.typeop = op.typeop
join whs.contractor c on c.id_contr = op.id_contr
--join whs.event_queue_in
join whs.users u on u.alias =  ho.username
where op.id_op in (-966079229);
--where op.opguid = '1D0CCEF8D90F100001809CD643631BC5';


select * 
from whs.event_queue_in eq
where eq.capture_guid = '5EC1D442D90F1000088074D435DB13A0' -- ����������� GUID_OBJ �� ������� EVENT_QUEUE_OPERATION �� ��

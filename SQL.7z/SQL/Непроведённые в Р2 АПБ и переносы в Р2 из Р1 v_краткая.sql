-- ������������ � �2 ��� � �������� � �2 �� �1 v_�������
with apb as (
select s.id_document, s.id_doctype, s.id_send_status, wh.code as oo_code from doc_egais.send_doc_egais_tbl s
join whs.warehouse wh on wh.guid = s.ws_guid
where s.id_doctype in (504,506)
and --wh.lg1 in (101, 201)
wh.code = '230633'
and (s.id_send_status = 11
--OR (s.id_send_status = 8/* and (s.last_work_date is null OR s.last_work_date <= to_date (sysdate-1/48))*/)
)
)
, count_at_506 as
(
select a.oo_code, ac.id_document, sum (ac.quantity) as quantity from
doc_egais.actchrgonshop_doc_content_tbl   ac
join apb a on a.id_document = ac.id_document
--join whs.article art on art.ID_ART = ac.id_art --�� ������������
where a.id_doctype = 506
group by a.oo_code, ac.id_document
)
, count_at_504 as (
select a.oo_code, tc.id_document, sum (tc.quantity) as quantity from
doc_egais.transferts_doc_content_tbl tc
join apb a on a.id_document = tc.id_document
--join whs.article art on art.ID_ART = tc.id_art -- ������ ����� ������� �� ���. ����, �. �. �� ����� ��������� id_art
where a.id_doctype = 504
group by a.oo_code, tc.id_document
)
, count_at_perenos as (
select * from count_at_506
union
select * from count_at_504
)

, provedeno_v_R2 as (
select a.oo_code, a.id_document, sum (r2.quantity) as quantity 
from apb a
join retail.registr_tbl r2 on r2.id_document = a.id_document and r2.move_type = 'P'
group by a.oo_code, a.id_document
)
select a.oo_code, a.id_document, d.lastdate, a.id_doctype, a.id_send_status, c.quantity as act_quantity, /*nvl (r2.quantity,0)*/r2.quantity as R2_quantity from apb a
join whs.document d on d.id_document = a.id_document
left join count_at_perenos c on c.oo_code = a.oo_code and c.id_document = a.id_document
left join provedeno_v_R2 r2 on r2.oo_code = c.oo_code and r2.id_document = c.id_document
where c.quantity > r2.quantity OR r2.quantity is null OR c.quantity is null

/* ���������� � �2 ��������� ���� ����������
M	504	
P	504	
M	505	
P	505	
M	506	
P	506	
M	507	
P	507	
P	509	
M	509	
*/
/*
-- ���������� �� ������
select wh.code, wh.name, dt.name, st.*, s.* from doc_egais.send_doc_egais_tbl s 
join whs.warehouse wh on wh.guid = s.ws_guid
join whs.doctype dt on dt.id_doctype = s.id_doctype
join doc_egais.send_doc_type_egais_tbl st on st.id_send_type = s.id_send_type
where s.id_doctype = 506
and wh.code = '508817'
*/
with apb as (
select s.id_document, s.id_doctype, s.id_send_status, wh.code as oo_code from doc_egais.send_doc_egais_tbl s
join whs.warehouse wh on wh.guid = s.ws_guid
where s.id_doctype in (506)
and --wh.lg1 in (101)--, 201)
wh.code = '230633'
and (s.id_send_status = 11
--OR (s.id_send_status = 8/* and (s.last_work_date is null OR s.last_work_date <= to_date (sysdate-1/48))*/)
)
)
select a.oo_code, ac.id_document, sum (ac.quantity) as quantity from
doc_egais.actchrgonshop_doc_content_tbl   ac
join apb a on a.id_document = ac.id_document
--join whs.article art on art.ID_ART = ac.id_art --�� ������������
where a.id_doctype = 506
group by a.oo_code, ac.id_document

select * from doc_egais.actchrgonshop_doc_content_tbl   ac where ac.id_document = 424322749
select * from retail.registr_tbl r2 where r2.id_document = 424322749 and r2.move_type = 'P'
select * from doc_egais.send_doc_egais_tbl s where s.id_document = 424322749


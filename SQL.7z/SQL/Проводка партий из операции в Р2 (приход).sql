
-- �������� ������ �� ������� � �2
with prihod as (
select
wb.reg_id_b, wbc.quantity
from whs.operation op
join whs.doc_op do on do.id_op = op.ID_OP
join whs.document d481 on d481.id_document = do.id_document and d481.id_doctype = 481 and (d481.isdeleted is null OR d481.isdeleted = 0)
join whs.docreference dr on dr.id_doc_master = d481.id_document
join whs.document d483 on d483.id_document = dr.id_doc_depend and d483.id_doctype = 483 --and (d483.isdeleted is null OR d483.isdeleted = 0)
join doc_egais.wbinformbreg_doc_content_tbl wb on wb.id_document = d483.id_document
join doc_egais.waybill_doc_content_tbl wbc on wbc.id_document = d481.id_document and wbc.id_position = wb.id_position
where op.ID_OP in (-1771048882,-1778303188)
)
/*
-1603616786
,-1634778819
,-1634748957
,-1634441494
,-1634764631
,-1634646449
,-1634763954
*/
select * from prihod p
left join retail.registr_tbl rm 
          on /*rm.id_document = p.id_document 
          and*/ rm.reg_id_b = p.REG_ID_B
          --and rm.wscode = p.wscode 
          and rm.move_type = 'P'
          --and rm.move_date >= p.move_date
where (rm.reg_id_b is null OR rm.reg_id_b = p.reg_id_b)
and rm.art_code = '3121630020'
--and rm.art_code not in ()
--and rm.alc_code in ('0150320000001206856','0010255000001942949','0014247000001191302')
/*
(-1185561545,-1184369138,-1132039557)
-1273449180	593441A1193	23.11.2016	30916,96	11	0150325000003726579	30	FB-000000558001330
-1286960696	593441A1205	05.12.2016	54544,83	11	0150325000003726579	30	FB-000000580130560
-1316828089	593441A1225	30.12.2016	126515,07	11	0150325000003726579	30	FB-000000631750545
-1205526558	593441A1127	22.09.2016	26950,2	  11	0150325000003726579	30	FB-000000441685215
-1249974119	593441A1169	02.11.2016	40565,8	  11	0150325000003726579	30	FB-000000518401057
-1299437634	593441A1216	16.12.2016	38101,18	11	0150325000003726579	30	FB-000000602417424

FB-000000441685215
FB-000000518401057
FB-000000558001330
FB-000000580130560
FB-000000602417424
FB-000000631750545

*/

/*select * from whs.doc_op do
--join whs.document d on d.id_document = do.id_document
where do.id_op = -1111580781*/

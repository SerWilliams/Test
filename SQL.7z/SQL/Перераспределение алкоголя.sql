﻿select * from whs.redistribution_status_tbl -- статусы заданий на перераспределение

-- Задания в ошибке или определённом статусе
select wh.name, st.name, rtt.* 
from whs.redistribution_task_tbl rtt
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from and wh.lg1 = '101'
where (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) > 0
--st.id_status not in (1,9,8,10)
--st.id_status = 8
--st.id_status = 6 or st.id_status = 7 or st.id_status = 15 or st.id_status = 8
--wh.id_ws = 12912 
and wh.name = 'Тянач'
order by rtt.id_task desc



-- успешно выполненные Задания 
select wh.fullname as Откуда, wh2.fullname as Куда, st.name as "Статус задания",
rtt.task_number as "Номер Задания", rtt.task_date as "Дата Задания", rtt.id_task
from whs.redistribution_task_tbl rtt
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from --and wh.lg1 = '101'
join whs.warehouse wh2 on wh2.id_ws = rtt.id_ws_to
where --(select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) > 0
--st.id_status not in (1,9,8,10)
--st.id_status in (8,1,2,4,6) and
st.id_status in (5,6,7,8) --and
--st.id_status = 6 or st.id_status = 7 or st.id_status = 15 or st.id_status = 8
--wh.id_ws = 12912 
--and wh.name = 'Атлант'
--rtt.task_date >= '01.05.2016' and rtt.task_date < '01.06.2016'
order by rtt.id_task desc


/
select 
wh.code, 
wh.name as "ММ"
,rtt.id_task as "Номер задания"
,rtt.task_date as "Дата задания"
,st.name as "Статус задания"
--, (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "Кол-во ТП"
--, (select sum (rtdt.quantity) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "Кол-во бутылок"
/*, (select count (oa.ID_ART) --t.fullname, sde.id_send_status as "Статус отправленного акта", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.op_art oa on oa.ID_OP = op.ID_OP
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      where r.id_task = rtt.id_task
      and op.ID_TOP = 106
            group by op.ID_OP)
      as "ТП в операциях возврата"
, (select sum (oa.QUANTITY) --t.fullname, sde.id_send_status as "Статус отправленного акта", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.op_art oa on oa.ID_OP = op.ID_OP
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      where r.id_task = rtt.id_task
      and op.ID_TOP = 106
            group by op.ID_OP)
      as "Бутылок в операциях возврата"
, (select sde.id_send_status --t.fullname, sde.id_send_status as "Статус отправленного акта", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.op_art oa on oa.ID_OP = op.ID_OP
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      where r.id_task = rtt.id_task
      and op.ID_TOP = 548)
      as "Возврат принят по ЕГАИС?" */  
, op.id_top 
, t.name as "Типовая операция"
, count (distinct op.id_op) as "Количество операций"
, count (rtdt.id_art) as "Количество ТП в заданиях"
, sum (rtdt.quantity) as "Количество бутылок в заданиях"
, count (oa.id_art) as "Количество ТП в операциях"
, sum (oa.quantity) as "Количество бутылок в операциях"
/*, case when op.id_top = 106 then sum (oa.quantity) 
      when op.id_top = 548 then sum (oa.quantity)
      end as "Количество бутылок"*/
--, rtt.* 
from whs.redistribution_task_tbl rtt
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from --and wh.lg1 = '101'
-- Берём перечень операций
      join whs.redistribution_queue_tbl r on r.id_task = rtt.id_task
      left join whs.operation op on op.id_op = r.id_op --and op106.ID_TOP = 106
      join whs.op_art oa on oa.ID_OP = op.ID_OP
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
-- Перечерь ТП в задачии
left join whs.redistribution_task_detail_tbl rtdt on rtdt.id_task = rtt.id_task
where (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) > 0 -- откидываем задания без ТП
--st.id_status not in (1,9,8,10)
--st.id_status = 8
--st.id_status = 6 or st.id_status = 7 or st.id_status = 15 or st.id_status = 8
--wh.id_ws = 12912 
--wh.name = 'Властелин'
--and rtt.task_date >= '27.10.2016' --and rtt.task_date < '01.11.2016'
and wh.code in ( '100048', '110015', '160493', '161815', '182387', '290028', '300060', '310103', '340126', '363627', '450034', '470003', '502403', '502406', '502602', '502654', '504081', '504336', '504353', '520176', '524578', '524620', '543386', '560123', '580013', '590143', '600057', '611751', '630013', '630559', '634275', '634368', '660003', '660590', '687383', '690092', '710060', '720037', '740043', '740120', '740609', '740618', '743055', '744091', '760013', '770088', '770184', '771728', '773361', '773421', '773452', '777832', '777852', '777868', '777870', '780177', '782493', '784166', '784393', '992366', '994214', '996324', '997725','997814')
--and op.id_top in  (106,548)
group by wh.code, wh.name, rtt.id_task, rtt.task_date, st.name, op.id_top, t.name--, wh.name
--order by rtt.id_task desc
/
select 
wh.name as "ММ"
, st.name as "Статус задания"
--, (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "Кол-во ТП"
--, (select sum (rtdt.quantity) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "Кол-во бутылок"

, op.id_top 
, t.name as "Типовая операция"
, count (distinct op.id_op)
, count (rtdt.id_art) as "Количество ТП в заданиях"
, sum (rtdt.quantity) as "Количество бутылок в заданиях"
, count (oa.id_art) as "Количество ТП в операциях"
, sum (oa.quantity) as "Количество бутылок в операциях"
/*, case when op.id_top = 106 then sum (oa.quantity) 
      when op.id_top = 548 then sum (oa.quantity)
      end as "Количество бутылок"*/
--, rtt.* 
from whs.redistribution_task_tbl rtt
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from and wh.lg1 = '101'
-- Берём перечень операций
      join whs.redistribution_queue_tbl r on r.id_task = rtt.id_task
      left join whs.operation op on op.id_op = r.id_op --and op106.ID_TOP = 106
      join whs.op_art oa on oa.ID_OP = op.ID_OP
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
-- Перечерь ТП в задачии
left join whs.redistribution_task_detail_tbl rtdt on rtdt.id_task = rtt.id_task
where (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) > 0 -- откидываем задания без ТП
--st.id_status not in (1,9,8,10)
--st.id_status = 8
--st.id_status = 6 or st.id_status = 7 or st.id_status = 15 or st.id_status = 8
--wh.id_ws = 12912 
--wh.name = 'Властелин'
and rtt.task_date >= '20.09.2016' and rtt.task_date < '01.11.2016'
and op.id_top in  (106,548)
group by st.name, op.id_top, t.name--, wh.name
--order by rtt.id_task desc


/
--вывод количественный
select 
wh.name as "ММ"
, st.name as "Статус задания"
, (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "Кол-во ТП в задании"
, (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task and rtdt.quantity_edo > 0) as "Кол-во ТП ЭДО"
, (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task and rtdt.quantity_au > 0) as "Кол-во ТП АУ"
, (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task and rtdt.quantity_rc > 0) as "Кол-во ТП Обороты с РЦ"
, (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task and rtdt.quantity_rest > 0) as "Кол-во ТП Остатки"
, (select sum (rtdt.quantity) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "Кол-во бутылок в задании"
, (select count (oa.ID_ART) --t.fullname, sde.id_send_status as "Статус отправленного акта", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
     from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.op_art oa on oa.ID_OP = op.ID_OP
      where r.id_task = rtt.id_task
      and op.ID_TOP = 106)
      as "ТП в операциях возврата"
, (select sum (oa.QUANTITY) --t.fullname, sde.id_send_status as "Статус отправленного акта", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.op_art oa on oa.ID_OP = op.ID_OP
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      where r.id_task = rtt.id_task
      and op.ID_TOP = 106)
      as "Бутылок в операциях возврата"
, rtt.* 
from whs.redistribution_task_tbl rtt
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from and wh.lg1 = '101'
where (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) > 0 -- откидываем задания без ТП
--st.id_status not in (1,9,8,10)
--st.id_status = 8
--st.id_status = 6 or st.id_status = 7 or st.id_status = 15 or st.id_status = 8
--wh.id_ws = 12912 
--wh.name = 'Властелин'
and rtt.task_date >= '27.10.2016'-- and rtt.task_date < '01.11.2016'
--group by st.name, op.id_top, t.name--, wh.name
order by rtt.id_task desc
/


/
--Выгрузка проблем перераспределения алкоголя
select 
wh.name as "ММ"
, st.name as "Статус задания"
, rdet.quantity as "Кол-во ТП в задании"--, (select rtdt. from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task and rtdt.id_art = rdet.id_art) as "Кол-во ТП"
, rdet.quantity_rc as "Количество в оборотах РЦ"
, rdet.quantity_comings as "Количество в приходах"
, rdet.quantity_edo as "Количество по расчету ЭДО"
, rdet.quantity_au as "Количество по расчету АУ"
--, (select sum (rtdt.quantity) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "Кол-во бутылок"
/*, (select oa.QUANTITY--count (oa.ID_ART) --t.fullname, sde.id_send_status as "Статус отправленного акта", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
     from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.op_art oa on oa.ID_OP = op.ID_OP  and oa.ID_ART = rdet.id_art
      where r.id_task = rtt.id_task
      and op.ID_TOP = 106)
      as "В операциях возврата"*/
/*, (select oa.sum (oa.QUANTITY) --t.fullname, sde.id_send_status as "Статус отправленного акта", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.op_art oa on oa.ID_OP = op.ID_OP
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      where r.id_task = rtt.id_task
      and op.ID_TOP = 106)
      as "Бутылок в операциях возврата"*/
, rtt.* 
from whs.redistribution_task_tbl rtt
join whs.redistribution_task_detail_tbl rdet on rdet.id_task = rtt.id_task
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from and wh.lg1 = '101'
where (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) > 0 -- откидываем задания без ТП
--st.id_status not in (1,9,8,10)
--st.id_status = 8
--st.id_status = 6 or st.id_status = 7 or st.id_status = 15 or st.id_status = 8
--wh.id_ws = 12912 
--wh.name = 'Властелин'
and rtt.task_date >= '09.11.2016' --and rtt.task_date < '01.11.2016'
--group by st.name, op.id_top, t.name--, wh.name
order by rtt.id_task desc
/

--вывод по типовым операциям
select 
wh.name as "ММ"
, st.name as "Статус задания"
, (select sum (rtdt.quantity) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "Кол-во бутылок в задании"
, (select sum (oa.QUANTITY) from whs.op_art oa where oa.ID_OP = op.ID_OP) as "Количество бутылок в операции"
, op.ID_OP
, op.ID_TOP
, s.id_send_status as "Статус Возврат от покупателя"
, rtt.* 
from whs.redistribution_task_tbl rtt
join whs.redistribution_queue_tbl r on r.id_task = rtt.id_task
join whs.operation op on op.ID_OP = r.id_op and op.ID_TOP = 1 --548, 169, 1
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from and wh.lg1 = '101'
where (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) > 0 -- откидываем задания без ТП
and rtt.task_date >= '20.09.2016' and rtt.task_date < '01.11.2016'
order by rtt.id_task desc

select * from whs.redistribution_task_tbl rtt

--Все задания с одного конкретного ММ на другой
-- Задания в ошибке или определённом статусе
select wh.code, wh.name, st.name, rtt.* from whs.redistribution_task_tbl rtt
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
join whs.warehouse whto on whto.id_ws = rtt.id_ws_to
where 
--rtt.id_task = 8918
wh.code in ('563365')
--and whto.name = 'Полифем'
order by st.name, rtt.id_task desc



-- Родительское задание на перераспрделениен
select wh.name, st.name, rtt.* from whs.redistribution_task_tbl rtt
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
where
rtt.id_task = 17357



-- операции по заданию
select t.fullname, sde.id_send_status as "Статус отправленной операции", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      --where r.id_task in (5731)--r.id_op = -1146487990
      where /*op.opnumber = '230178TORRA4331'*/r.id_task in (42798,42767,42689)
/*
31657
31585
31525
26402*/

      --and 
      /*(op.ID_TOP = 106
      and sde.id_send_status = 10)
      OR
      ((select rt.id_status from whs.redistribution_task_tbl rt where rt.id_task = r.id_task) in (9,10,7)
      and 
      (select sum(rdt.quantity_edo) from whs.redistribution_task_detail_tbl rdt where rdt.id_task = r.id_task) = 0)*/
      --and r.last_date >= '27.10.2016'
      
      
/*      select w.name, t.* from whs.redistribution_task_tbl t
      join whs.warehouse w on w.id_ws = t.id_ws_from
      where t.id_task=10908 */

--Операции по заданию в заданных статусах в очереди ЭДО
-- операции по заданию
select t.fullname, sde.id_send_status as "Статус отправленной операции", op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
      from whs.redistribution_queue_tbl r
      -- 106
      left join whs.operation op106 on op106.id_op = r106.id_op and op106.ID_TOP = 106
      left join whs.typeop t106 on r106.id_top=t106.id_top
      left join doc_egais.send_doc_egais_tbl sde106 on r106.id_op=sde106.id_send_base
      --169
      left join whs.operation op169 on op169.id_op = r169.id_op and op169.ID_TOP = 169
      left join whs.typeop t169 on r169.id_top=t169.id_top
      left join doc_egais.send_doc_egais_tbl sde169 on r169.id_op=sde169.id_send_base
      --548
      left join whs.operation op548 on op548.id_op = r548.id_op and op548.ID_TOP = 548
      left join whs.typeop t548 on r548.id_top=t548.id_top
      left join doc_egais.send_doc_egais_tbl sde548 on r548.id_op=sde548.id_send_base
      --1
      left join whs.operation op1 on op1.id_op = r1.id_op
      left join whs.typeop t1 on r1.id_top=t1.id_top
      left join doc_egais.send_doc_egais_tbl sde1 on r1.id_op=sde1.id_send_base
      --where r.id_task in (5731)--r.id_op = -1146487990
      where /*op.opnumber = '230178TORRA4331'*/r.id_task in (10908)

-- состав эТТН
select d481.isdeleted, d483.isdeleted, p.*, wc.*, wb.* from whs.doc_op dop
join whs.document d481 on d481.id_document = dop.id_document and d481.id_doctype = 481 and (d481.isdeleted = 0 OR d481.isdeleted is null)
join whs.docreference dr on dr.id_doc_master = d481.id_document
join whs.document d483 on d483.id_document = dr.id_doc_depend --and d483.id_doctype = 483 --and (d483.isdeleted = 0 OR d483.isdeleted is null)
left join doc_egais.waybill_doc_content_tbl wc on wc.id_document = d481.id_document
left join  doc_egais.product_tbl p on p.id_product = wc.id_product
left join doc_egais.wbinformbreg_doc_content_tbl wb on wb.id_document = d483.id_document and wc.id_position = wb.id_position
where dop.id_op = -1194966547
and wc.id_position = '47'

0003924000001455974	4	166119902	520335659	438659238	4	FA-000000007497316	FB-000000346213279	438659238

FA-000000005459766	FB-000000346213279           0003924000001455974
0003924000001455974
Вино Мускатное Крымское белое полусладкое 0,75л (Инкерман):6	1000152113
      
-- Задания, где статусы операций в очереди операций задания не равны статусам этих операций в очереди ЭДО
-- операции по заданию
select t.fullname, sde.id_send_status as "Статус отправленной операции", r.id_send_status, op.opnumber, op.OPDATE, op.OPSUM, r.*--, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      left join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      where 
      sde.id_send_status <> r.id_send_status
      

-- Задания по которым добавлено более 30 ТП
select wh.name, st.name 
, (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) as "кол-во ТП"
, rtt.* 
from whs.redistribution_task_tbl rtt
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from and wh.lg1 = '101'
where (select count (rtdt.id_art) from whs.redistribution_task_detail_tbl rtdt where rtdt.id_task = rtt.id_task) > 30
--st.id_status not in (1,9,8,10)
--st.id_status = 8
--st.id_status = 6 or st.id_status = 7 or st.id_status = 15 or st.id_status = 8
--wh.id_ws = 12912 
--wh.name = 'Властелин'
order by rtt.id_task desc
     
      
update whs.redistribution_queue_tbl r
set r.id_send_status = 11
where r.id_queue = 4165 and r.id_task = 5731 and r.id_op = -1181512250;
commit;


331135429 -- отправлено с Граве      
513576
513373
504123

select * from doc_egais. send_doc_egais_tbl sde where sde.id_send_base = -1181512129

select * from whs.redistribution_queue_tbl
-- в id_document для переноса остатков может быть указан id_send_base из таблицы doc_egais. send_doc_egais_tbl sde

select * from whs.document where id_document = 513576

select * from whs.operation op where op.id_op = -1147693522


-- состав родительского задания
select * from whs.redistribution_task_detail_tbl rtdt
where
rtdt.id_task = 5623

-- выгрузка ТП и количества из родительского задания
select art.code, rtdt.quantity from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
where rtdt.id_task in (5731
,5729
,5728
,5726
,5723)

select * from whs.redistribution_task_tbl rtt

-- выгрузка ТП и количества из родительского задания c отбором по ММ и ТП
select distinct 
wh.name ,wh.code
, st.name
, art.code
, rtdt.quantity as "Количество"
, rtdt.quantity_rest as "Количество по учету"
, art.name
, op.id_op
, op.opnumber
, op.opdate
, oa.quantity as "Количество в операции"
, sde.id_send_status as "Статус ЭДО"
, rtt.*
, rtdt.*
from whs.redistribution_task_tbl rtt
join whs.redistribution_task_detail_tbl rtdt on rtdt.id_task =  rtt.id_task
join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
join whs.warehouse whto on whto.id_ws = rtt.id_ws_to
left join whs.redistr_fr_task_det_tbl rfdt on rfdt.id_task = rtt.id_task
left join whs.redistribution_queue_tbl r on r.id_foreign_task = rfdt.id_foreign_task
left join whs.operation op on op.id_op = r.id_op --and op.typeop = 21
left join whs.op_art oa on oa.id_op = op.id_op and oa.id_art = art.id_art
left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
where 
/*rtt.id_task in (5731
,5729
,5728
,5726
,5723)*/
wh.name = 'Патака' -- ММ Донор
--and whto.name = 'Полифем' -- ММ получатель
--and art.code in ('9799901504') -- коды ТП
--(and (op.id_op is not null and op.typeop = 21)-- or (op.id_op is null)) -- тип операции 10, 20, 21, 11
--and op.opnumber in ('233723TORRA1247')
--and rtt.id_status <> 10
and oa.quantity is null
order by op.opnumber, art.code, st.name, rtt.id_task desc


select * from whs.redistr_foreign_task_tbl rft 

select t.fullname,r.*, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      where r.id_foreign_task in (3643, 3644,3645) --r.id_op = -1147693518--r.id_task in (4486,4484)
      and op.typeop = 21



-- заголовок дочернего задания
select st.name, rft.* from whs.redistr_foreign_task_tbl rft 
join whs.redistribution_status_tbl st on st.id_status = rft.id_status
where
rft.id_task = 545

-- Результат расчёта блока ЭДО
select */*sum (quantity) */from whs.redistrib_edo_res_tbl where id_task=32571


select * from whs.redistr_fr_task_det_tbl rfdt -- детали дочернего задания
left join whs.article art on art.id_art = rfdt.id_art
where
rfdt.id_task in (5731
,5729
,5728
,5726
,5723) --and art.code = '1000129025'
--rfdt.id_foreign_task = 3643 --and art.code = '1000108963'
--and (rfdt.quantity <> rfdt.quantity_RC_FACT or rfdt.quantity_RC_FACT is null)--условие выводить только ТП с изменённым фактическим количеством
and (rfdt.quantity = rfdt.quantity_RC_FACT)--условие выводить только ТП без изменений фактического количества



-- оценка убытков по перераспределению
select * from whs.redistr_fr_task_det_tbl rfdt -- детали дочернего задания
left join whs.article art on art.id_art = rfdt.id_art
where
rfdt.id_task in (5731
,5729
,5728
,5726
,5723) --and art.code = '1000129025'
--rfdt.id_foreign_task = 3643 --and art.code = '1000108963'
--and (rfdt.quantity <> rfdt.quantity_RC_FACT or rfdt.quantity_RC_FACT is null)--условие выводить только ТП с изменённым фактическим количеством
and (rfdt.quantity = rfdt.quantity_RC_FACT)--условие выводить только ТП без изменений фактического количества



/* Три типовых действия
1. Установить в структуре UNI_RDA.T_RDA_CONFIG настройку "DFVALUE" в значение "2" по строке "Тип обработки задания перераспределения алкоголя". Т.е. чтобы при создании заданий остатки запрашивались из ЕГАИС (сейчас проверяется только по ЭДО).

2. Произвести отмену заданий "В работе"
В таблице родительских заданий установить статус "Отменено"
В таблице дочерних заданий так же поставить статус "Отменено"

3. Произвести повторную постановку заданий в очередь (передернуть статус), которые упали в статус "Ошибка отправки операций"
В таблице родительских заданий установить статус "Операции в очереди"
В таблице дочерних заданий так же поставить вместо статус "Операции в очереди", но только у тех дочерних, которые были в статусе "Ошибка отправки операций"
*/

select * from UNI_RDA.T_RDA_CONFIG
update UNI_RDA.T_RDA_CONFIG
set DFVALUE = '2'
where DFNAME = 'Тип обработки задания перераспределения алкоголя' and dfcode = 'redist_processing_type'

-- Cмена статусе заданий на переарстредение
-- Родитель
UPDATE whs.redistribution_task_tbl rtt
SET rtt.id_status = '10' -- устанавливаемый статус
WHERE rtt.id_task = 5627;
commit;

select * from whs.redistr_foreign_task_tbl rft 

-- Дочернее
UPDATE whs.redistr_foreign_task_tbl rft 
SET rft.id_status = '10' -- устанавливаемый статус
where 
rft.id_task = 5627; -- id родительского задания
--and rft.id_foreign_task = 1825; -- id нужного дочернего задания
commit;

--Задание в статусе Запрос остатков ЕГАИС, ответ уже пришел и далее должна пройти обработка  ЭДО и передать данные на вход АУ
--(список операций по заданию)
select * from   whs.redistribution_queue_tbl where id_task=2141 -- смотрим документ, по которому осуществлялся запрос в ЕГАИС


-- ищем задания, в которых есть указанные операции

select t.name, w.fullname, op.* from whs.operation op
join whs.warehouse w on w.id_ws = op.id_wso
join whs.typeop t on t.id_top = op.id_top
where op.opguid in (hextoraw('0C2C13F63EC411E6B2DCF8B1A0A0DC23'), hextoraw ('5D1858743EC411E6B2DCF8B1A0A0DC23')) 

select * from   whs.redistribution_queue_tbl rt
join whs.operation op on op.id_op = nvl (rt.id_op, rt.id_op_parent)
where op.opguid in (hextoraw('0C2C13F63EC411E6B2DCF8B1A0A0DC23'), hextoraw ('5D1858743EC411E6B2DCF8B1A0A0DC23')) 


select t.name, re.*, op.* from whs.opreference re
join whs.operation op on op.id_op = re.id_op
join whs.typeop t on t.id_top = op.id_top
where re.id_opref in (-1118879038,
-1118877701)

select * from uni_reg_doc.mm_gm_access_list


--смотрим документ ответа от ЕГАИС
select * from whs.docreference dref
join whs.document d on dref.id_doc_depend=d.id_document
where dref.id_doc_master=228324095

--результат обработки ЭДО - пусто
select * from   whs.redistrib_edo_res_tbl where id_task=2141

--Данные ЭДО не обработаны и задание "зависло" в статусе запроса остатков.

select id_ws, code, name,fullname from whs.warehouse wh where wh.code in ('230907')--,'300020')

11196622	Расход (продажа)•Магнит	202319300	773375A1099	06.11.16 00:00:00	12
11196621	Расход (продажа)•Магнит	202319574	774784A1099/2	06.11.16 00:00:00	12

14976	773375	Арсенолит	Сеть МД•Москва Север•Арсенолит
12315	774784	Васили	Сеть МД•Москва Запад•Васили
14976
12315

-- запрашивает остатки со склада объекта
-- Запрос остатков из Склада ОО
begin 
doc_egais.support_api.queue_rests_1ws(p_id_ws => '285');
end;



-- Ответ на этот запрос
select /*+ leading(q, d, w)
           index(q QUERY_DOC_HEADER_QTYPE_IDX)
           index(d DOCUMENT_PK) use_nl(d)
           index(w P_WAREHOUSE) use_nl(w)*/
w.id_ws, w.code, w.fullname, q.id_document, d.fsrar_id,
      (select rr.id_document
         from whs.docreference rf
         join doc_egais.replyrests_doc_header_tbl rr on rr.id_document = rf.id_doc_depend
        where rf.id_doc_master = q.id_document) id_rest,
      (select rr.rests_date
         from whs.docreference rf
         join doc_egais.replyrests_doc_header_tbl rr on rr.id_document = rf.id_doc_depend
        where rf.id_doc_master = q.id_document)
 from doc_egais.query_doc_header_tbl q
 join doc_egais.document_tbl d on d.id_document = q.id_document
 join whs.warehouse w on w.id_ws = d.id_ws
where q.id_query_type = 7
  and d.lastdate >= to_date('29.05.2017 08:15:00','dd.mm.yyyy hh24:mi:ss')
  --and d.lastdate < to_date('28.06.2016 17:00:00','dd.mm.yyyy hh24:mi:ss')
  and w.id_ws in (/*select id_ws from doc_egais.transfer_shop_idws_tbl*/81791)
  
-- контент ответа на запрос остатков склада
select p.alc_code, r.quantity, r.*, p.* from doc_egais.replyrests_doc_rest_tbl r 
left join doc_egais.product_tbl p on p.id_product = r.id_product
where r.id_document = 757346964
and p.alc_code in ('0003924000001455974') 
660816970
660816950
select * from whs.doctype



-- просмотр состава зарегистрированного в ЕГАИС по приходу
select wb.reg_id_b, wb.wbi_reg_id_b, p.alc_code, wb.quantity, wb.*, d481.* from whs.operation op
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
join whs.docreference dr on dr.id_doc_depend = s.id_document
join whs.document d481 on d481.id_document = dr.id_doc_master and d481.id_doctype = 481
join doc_egais.waybill_doc_content_tbl wb on wb.id_document = d481.id_document
join doc_egais.product_tbl p on p.id_product = wb.id_product
where op.id_op = -1216919639
  
  
select * from whs.doctype where id_doctype = 509
  
-- Запрос остатков с ТЗ объекта
begin
  doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 2258);
end;



--ответ на запос остатков ТЗ объекта
select w.id_ws, w.code, w.fullname, q.id_document, d.fsrar_id,
      (select rrs.id_document
         from whs.docreference rf
         join doc_egais.replyrestshop_doc_header_tbl rrs on rrs.id_document = rf.id_doc_depend
        where rf.id_doc_master = q.id_document) id_rest,
      (select rrs.restdate
         from whs.docreference rf
         join doc_egais.replyrestshop_doc_header_tbl rrs on rrs.id_document = rf.id_doc_depend
        where rf.id_doc_master = q.id_document)
 from doc_egais.query_doc_header_tbl q
 join doc_egais.document_tbl d on d.id_document = q.id_document
 join whs.warehouse w on w.id_ws = d.id_ws
where q.id_query_type = 8
  and d.lastdate >= to_date('11.05.2017 10:50:00','dd.mm.yyyy hh24:mi:ss') and w.id_ws in (150738);

-- контент ответа на запрос остатков
select p.alc_code, r.quantity, r.*, p.* from doc_egais.replyrestshop_doc_content_tbl r 
left join doc_egais.product_tbl p on p.id_product = r.id_product
where r.id_document = 757375709
and p.alc_code in ('0031655000001334745')
738637191
738636528

-- Просто проверка запросов и ответов
select distinct qt.name
, doc.id_Doctype
, dtb.id_ws
, w.name
, doc.username
, doc.*
, dtb.* 
from whs.document doc
join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
join whs.warehouse w on dtb.id_ws=w.id_ws
left join doc_egais.query_doc_header_tbl qh on dtb.id_document=qh.id_document
left join doc_egais.query_type_tbl qt on qh.id_query_type=qt.id_query_type --and qh.id_query_type=7
where
     doc.id_Doctype in  (473, 479, 511) --479 ответ 473 запрос
     and w.id_ws in   (397) -- id_ws магазина
     and dtb.lastdate > trunc(sysdate)-0.5
    -- and doc.username in ('NAG_M_A', 'ZAYCE_AA')
     order by dtb.id_ws, doc.id_Doctype, doc.id_document, qt.name


 -- состав задания на перенос остатков?..
 select * from doc_egais.transferfs_doc_content_tbl
 where id_document = 347236205
 
 -- состав ответа от ЕГАИС
 479	815	Òàìàíü	DOC_EGAIS	489677355	479
511	815	Òàìàíü	DOC_EGAIS	489677689	511


select * from doc_egais
     

-- Просмотр способа связи запроса остатков и ответа на него
select * from  doc_egais.QUERY_DOC_REST_STATUS_TBL
     
--823     

--если вдруг интересно - вот твой запрос ушел)


--365

select * from whs.operation where id_op = -1050850920
select * from whs.document where id_document = 227762800


select * from whs.docreference dr 
join whs.document doc on doc.id_document = dr.id_doc_depend
where dr.id_doc_master = 227770359


select wh.name otkuda, wh2.name kuda, st.name stat_rodit, st2.name stat_detka, rtt.*, rft.*
from whs.redistribution_task_tbl rtt
join whs.redistr_foreign_task_tbl rft on rft.id_task=rtt.id_task
join whs.redistribution_status_tbl st on st.id_status = rtt.id_status
join whs.redistribution_status_tbl st2 on st2.id_status = rft.id_status
join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
join whs.warehouse wh2 on wh2.id_ws = rtt.id_ws_to
where st.name = 'Ошибка отправки операций'
and st2.name = 'Ошибка отправки операций'



--проверяем в журнале внутренних проверок: (причины, по которым система блокирует отправку)
    select
dt.name, v.id_document, vv.name, vs.name, v.result_text, v.lastdate, va.name, r.vnumber, r.vstring
from doc_egais.doc_verification_journal_tbl v
join WHS.doctype dt on dt.id_doctype = v.id_doctype
join doc_egais.doc_verification_tbl vv on vv.id_verification = v.id_verification
join doc_egais.doc_verification_status_tbl vs on vs.id_vrf_status = v.id_vrf_status
join doc_egais.doc_verification_result_tbl r on r.id_vrf_journal = v.id_vrf_journal
join doc_egais.doc_verification_addition_tbl va on va.id_vrf_add = r.id_vrf_add
where v.id_document in (287654928);


--Смотрим действует ли лицензия:
select d.name, als.state_name, als.is_deleted, ald.date_start, ald.date_end, ald.lastdate
from whs.alc_license_division ald
join whs.division d on d.id_div=ald.id_div
join whs.contractor cc on cc.id_contr=d.id_contr
join whs.alc_license_state als on als.id_alc_license_state=ald.id_alc_license_state
where cc.fullname like '%Выползово%'
order by ald.date_end desc;



select dt.name, do.*, doc.* from whs.doc_op do
left join whs.document doc on doc.id_document = do.id_document
join whs.doctype dt on dt.id_doctype = doc.id_doctype -- расшифровка типа документа
where do.id_op = -1050850920

227762800

select * from doc_egais. wd where wd.id_document = 227762800  -- ЭД
select * from doc_egais.product_tbl

select * from doc_egais.waybill_doc_content_tbl wc where wc.id_document = 227770359

select * from whs.document doc where doc.docnumber = '563385RA0030'

-- операции по заданию
select t.fullname,r.*, op.*,sde.*
      from whs.redistribution_queue_tbl r
      left join whs.operation op on op.id_op = r.id_op
      join whs.typeop t on r.id_top=t.id_top
      left join doc_egais. send_doc_egais_tbl sde on r.id_op=sde.id_send_base
      where r.id_foreign_task in (343) --r.id_op = -1147693518--r.id_task in (4486,4484)
      and op.typeop = 21
      
select * from whs.redistribution_queue_tbl
      
4483
4482
4481
4464
4462
4324
4241
4164
4140
4132
4106
4105
4085
4083
4065
4062
3992      
      
select * from whs.doc_op do 
join whs.document d on d.id_document = do.id_document
where do.id_op = -1082476444
and d.id_doctype = 481


-1082476444
287654928

2. Смотрим ответ от ЕГАИС по проблемной операции в статусе "10" в очереди. Берем id_tiket из очрееди
 select td.id_document, tdo.*--,tdo.operation_comment
 from doc_egais.ticket_doc_header_tbl  td
left join doc_egais.ticket_doc_result_tbl  tdr on td.id_ticket_doc_result=tdr.id_ticket_doc_result
left join doc_egais.ticket_doc_opresult_tbl  tdo on td.id_ticket_doc_opresult = tdo.id_ticket_doc_opresult
 where td.id_document=287654928
 
 
select distinct
 wd.id_position
 --, pr.*
 , wd.id_product
 , wd.quantity
 , wd.reg_id_a
 , wd.reg_id_b
 , ak.code_egais
 , ar.id_art
 , ar.code
 , ar.name
 , oa.id_op
 , oa.id_art
 , oa.quantity
  from  doc_egais.waybill_doc_content_tbl wd
  join doc_egais.product_tbl pr on wd.id_product=pr.id_product
  left join whs.article_kiscontr_link ak on pr.alc_code=ak.code_egais
  left  join whs.article ar on ak.id_article=ar.id_art
  join whs.article ar on ak.id_article=ar.id_art
  left join whs.op_art oa on ak.id_article=oa.id_art and oa.id_op=-1050850920
    where
     wd.id_document=227770359
     and    oa.id_op is not null and oa.id_op <> 0
     and      wd.id_position =1 
     
     
--4. смотрим сколько нашли при расчете остатков ЭДО и по каким разделам Б
select rd.*, rdh.reg_id, rdh.id_analyticopart
from whs.redistrib_edo_res_tbl  rd
join whs.document d on rd.id_document=d.id_document
left join whs.docreference dref on d.id_document=dref.id_doc_depend
left join doc_egais.replyformb_doc_header_tbl  rdh on dref.id_doc_master=rdh.id_document
where id_task=4721 and id_art=556177
--quantity - количество к возврату фактическое
--quantity_required - количество к возврату
--quantity_rc_max - количество в приходах

select * from doc_egais.replyformb_doc_header_tbl where id_analyticopart = 30016714


--5. смотрим какую аналитику привязали к товару с какими разделами Б
 select rt.*,  rdh.reg_id, rdh.id_analyticopart
  from acan.redist_task_analytic_tbl rt
left join whs.docreference dref on rt.id_document=dref.id_doc_depend
left join doc_egais.replyformb_doc_header_tbl  rdh on dref.id_doc_master=rdh.id_document
  where rt.id_task = 4721  and rt.id_art=556177
 

/*6. Смотрим сколько остатков по товару из  ЕГАИС есть по товару.
если не производился запрос остатков, то запрашиваем остатки по МХ
проверяем пришел ли ответ:*/
select qt.name,doc.*, dtb.* from whs.document doc
join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
join whs.warehouse w on dtb.id_ws=w.id_ws
left join doc_egais.query_doc_header_tbl qh on dtb.id_document=qh.id_document
left join doc_egais.query_type_tbl qt on qh.id_query_type=qt.id_query_type --and qh.id_query_type=7
where
     doc.id_Doctype = 479
     and w.code = '992366'
     --and w.name = 'Дамижан'
     
     225723169
     228730878
     
--Запрос остатков в ЕГАИС по справке     
begin
  doc_Egais.Query_Api.qfrombhistory_send_query(17336,'FB-000000350278324');
  doc_Egais.Query_Api.qfrombhistory_send_query(17336,'FB-000000350278353');
    doc_Egais.Query_Api.qfrombhistory_send_query(17336,'FB-000000350278879');
      doc_Egais.Query_Api.qfrombhistory_send_query(17336,'FB-000000350279308');
        doc_Egais.Query_Api.qfrombhistory_send_query(17336,'FB-000000350279101');  
end;

-- Посмотреть ответ запроса остатков в ЕГАИС по справке
--Движения по Б из ЕГАИС
select rh.*, rhh.doctype, rhh.regid, rhh.quantity, rhh.operdate, rhh.description
from doc_egais.document_tbl dtb
join doc_Egais.Replyhistf2_Doc_Header_Tbl rh On rh.id_document = dtb.id_document
join doc_Egais.Replyhistf2_Doc_History_Tbl rhh ON rhh.id_document = dtb.id_document
where
     dtb.id_ws = 17336 and dtb.lastdate >= to_date('12.08.2016')
     and rh.reg_id_b = 'FB-000000350278324'
     
  
 --смотрим в результатах ответа по остаткам на складе кол-во товара в разрезе разделов Б
select
       doc.id_document
       , ws.fullname
       , dhed.rests_date
       , pr.full_name
       , pr.alc_code
       , dcon.quantity
       , dcon.reg_id_a
       , dcon.reg_id_b
from whs.document doc
left join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
left join whs.warehouse ws on ws.id_ws = dtb.id_ws
left join doc_egais.replyrests_doc_header_tbl dhed ON dhed.id_Document = dtb.id_document
left join doc_egais.replyrests_doc_rest_tbl dcon ON dcon.id_document = dtb.id_document
left join doc_egais.product_tbl pr ON pr.id_product = dcon.id_product
WHERE
doc.id_document = 495906055  and pr.alc_code in ('0012389000001954629','0001528000001781181')   


495906055	479   


--смотрим в результатах ответа по остаткам на ТЗ кол-во товара в разрезе разделов Б
select
       doc.id_document
       , ws.fullname
       , dhed.rests_date
       , pr.full_name
       , pr.alc_code
      , dscon.quantity
from whs.document doc
left join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
left join whs.warehouse ws on ws.id_ws = dtb.id_ws
left join doc_egais.replyrests_doc_header_tbl dhed ON dhed.id_Document = dtb.id_document
left join doc_Egais.Replyrestshop_Doc_Content_Tbl dscon ON dscon.id_document = dtb.id_document
left join doc_egais.product_tbl pr ON pr.id_product = dscon.id_product
WHERE
doc.id_document = 495905936  and pr.alc_code in ('0012389000001954629','0001528000001781181')

495906055	479
495905936	511


--7. проверяем "откуда родился" раздел Б

select
    d.id_document
    , d.id_doctype
    , wd.reg_id_a
    , wd.reg_id_b
    , wd.id_analyticopart
    ,dop.id_op
    , t.fullname
    , c.name as "КА"
    , w1.fullname as "Куда"
    , w2.fullname as "Откуда"
from  doc_egais.wbinformbreg_doc_content_tbl wbd
join whs.docreference dref on wbd.id_document=dref.id_doc_depend
join whs.document d on dref.id_doc_master=d.id_document
left join doc_egais.waybill_doc_content_tbl wd on d.id_document=wd.id_document and wbd. id_position= wd.id_position
left join whs.doc_op dop on d.id_document=dop.id_document
left join whs.operation o on dop.id_op=o.id_op
left join whs.typeop t on o.id_top=t.id_top
 left  join whs.warehouse w1 on o.id_wsi=w1.id_ws
 left join whs.contractor c on o.id_contr=c.id_contr
 left  join whs.warehouse w2 on o.id_wso=w2.id_ws
where wbd.reg_id_b='FB-000000148355781'
--раздел А соотвествует разделу А в ответе ЕГАИС
--определяем где произошла подмена дальше

select * from  doc_egais.wbinformbreg_doc_content_tbl wbd where reg_id_b='FB-000000108103533'


--Принудительный запрос в ЕГАИС
begin
doc_egais.support_api.queue_rests_1ws(p_id_ws => '854'); end;


--1)Что вернул егаис ,
select qt.name,doc.*, dtb.* 
from whs.document doc 
join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document 
join whs.warehouse w on dtb.id_ws=w.id_ws 
left join doc_egais.query_doc_header_tbl qh on dtb.id_document=qh.id_document 
left join doc_egais.query_type_tbl qt on qh.id_query_type=qt.id_query_type --and qh.id_query_type=7 
where
     doc.id_Doctype = 479  --для проверки ответа тип "479"
      --and w.fullname =  'Сеть МД•Ярославль•Атлант'
      and w.code =  '992366'
      and dtb.lastdate > trunc(sysdate) -1
тип 473 вопрос
ответ 479


--нужно проверить наличие справок А и Б в БД (кроме той, что я проверил уже см. письмо ниже):
SELECT *
FROM doc_egais.document_tbl dtbl
join whs.document doc ON doc.id_Document = dtbl.id_Document --and (doc.id_doctype = 477 or doc.id_doctype = 478)
WHERE
UPPER(REPLY_ID) in hextoraw('4F2970FB4F674A83AAB5C779EBE3B572') --список ReplyID

-- Поиск файла по REPLYGUID из filesregister на ОО
select * from doc_egais.document_tbl dtbl where reply_id = hextoraw('AE8A1ECE01C648028E25C34DFA0DC5DD')


-- Проверка, находится ли задание в отложенном запуске
select * from dba_scheduler_jobs where lower(job_name) = 'redistr_processing_task_Номер задания'


--Результаты выполнения джоба, еще одна таблица:
--Выбрать все джобы с похожим redistr_processing_task
select * from dba_scheduler_job_run_details where lower(job_name) like '%redistr_processing_task%'
--ну или можно конкретный посмотреть
select * from dba_scheduler_job_run_details where lower(job_name) = 'redistr_processing_task_Номер задания'



-- Движения по разделу Б в ГК
select ac.id_document, ac.docnumber, ac.quantity, ac.operation_date
from registr_egais.accepted_doc_tbl ac
where
     ac.reg_id_b = 'FB-000000350278324'




Вводная:
усечение количества товара (усечение происходит,  если не найдены докумены к этому товару), может быть по несколькм причинам:
- если перераспределяем не на тот РЦ откуда получили товар в разрезе FA, FB
- если в базе найдены проблемы со связями документов  (привязано более одной эл. справки  к бумажной, или наоборот нет связей между различными типами документов)
- если разделы FA FB были образованы при помощи Виндетты.


Разбор вела от последнего пункта:
1. Смотрим есть ли остаток в ЕГАИС. 
     select
       doc.id_document
       , ws.fullname
       , dhed.rests_date
       , pr.full_name
       , pr.alc_code
       , dcon.quantity
       , dcon.reg_id_a
       , dcon.reg_id_b
from whs.document doc
left join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
left join whs.warehouse ws on ws.id_ws = dtb.id_ws
left join doc_egais.replyrests_doc_header_tbl dhed ON dhed.id_Document = dtb.id_document
left join doc_egais.replyrests_doc_rest_tbl dcon ON dcon.id_document = dtb.id_document
left join doc_egais.product_tbl pr ON pr.id_product = dcon.id_product
WHERE
doc.id_document = 332034035  --ИД документа ответа по остаткам на МХ
and pr.alc_code='0036813000001303803'; -- алко код полученный в п.3
Остатко имеется. 

2. Смотрим  в какой расходной операции участвовал FB-000000200982569, и какие FA FB были использованы в  расходной операции.

select
    d.id_document
    , d.id_doctype
    , wd.reg_id_a
    , wd.reg_id_b
    , wd.id_analyticopart
    ,dop.id_op
    , t.fullname
    , c.name as "КА"
    , w1.fullname as "Куда"
    , w2.fullname as "Откуда"
from  doc_egais.wbinformbreg_doc_content_tbl wbd
join whs.docreference dref on wbd.id_document=dref.id_doc_depend
join whs.document d on dref.id_doc_master=d.id_document
left join doc_egais.waybill_doc_content_tbl wd on d.id_document=wd.id_document and wbd. id_position= wd.id_position
left join whs.doc_op dop on d.id_document=dop.id_document
left join whs.operation o on dop.id_op=o.id_op
left join whs.typeop t on o.id_top=t.id_top
left  join whs.warehouse w1 on o.id_wsi=w1.id_ws
left join whs.contractor c on o.id_contr=c.id_contr
left  join whs.warehouse w2 on o.id_wso=w2.id_ws
where wbd.reg_id_b in (
'FB-000000350278324'); --подставляем разделы Б
----Берем ид  операции Расход (продажа)?Магнит

 
3. Смотрим участие в Виндетте расходной операции
select * from doc_egais.vdt_moverests_log_tbl where
  id_op=-1067168965  and new_reg_id_b='FB-000000159006866';

Видим, что эти разделы были сформирваны в результате обработки V:
 
Результат обработки (ACTION_RESULT) = 1 значит, успешно прошла обработка V.

Если старые разделы FA/FB  не равны новым разделам FA/FB  (подменяли партии), то такие разделы Б не используем при формировании операций перераспределения. тем самым усекаем кол-во товара возможного к перераспределению.


select om.vbool "Виртуальное?", wh.fullname, doc.id_document "ID ЭД", des1.id_send_status "Статус прихода", 
des2.id_send_status "Статус расхода", op.* from whs.operation op
join whs.warehouse wh on wh.id_ws = nvl(op.id_wsi, op.id_wso)
left join whs.doc_op dp on dp.id_op = op.id_op
left join whs.document doc on doc.id_document = dp.id_document 
left join doc_egais.send_doc_egais_tbl des1 on des1.id_send_base = op.id_op
left join doc_egais.send_doc_egais_tbl des2 on des2.id_send_base = doc.id_document
left join whs.op_moreinfo om on om.id_op = op.id_op and om.id_add = 667
where op.opnumber = '153355RA000001' 
and doc.id_doctype = 481 -- если возвращает пустое значение не выполнять условие

select * from whs.operation where opnumber = '543344RR013' 

select * from whs.opreference opr 
join whs.operation op on  op.id_op = opr.id_op
where opr.id_opref = -1144428475

select * from whs.warehouse w where w.id_ws = 18145

-- Пример разбора
Привет!
Игорь, посмотри пожалуйтса как провели Акт постановки на баланс  по аналитическому учету в алгоритме перераспределения.
Проблема  в следующем:
по заданию 4245 перераспределяли "Водка Абсолют 40% 0,5л (Швеция) :12"   по результатам ЭДО подобрали 1 шт. по акту. На вход АУ передали акт в разрезе двух РЦ: РЦ Шахты, РЦ Батайск.
                (передаем Акты по всем возможным РЦ , т.к. нет возможности по акту точно определить в разрезе какого РЦ        перераспределять продукцию. Подбор РЦ происходит на шаге подбора аналитик) 

В результате сформировались две операции Возврата поставщику, и акт учелся в обеих операция. После того как первая подтвердилась в ЕГАИС, вторая упала в необеспеченный расход.
ИД задания 4245
ИД товара 225225
ИД акта 309504560


Детальный разбор:
Позиция , упавшая в ошибку имеет разделы: FA-000000019284034   FB-000000322209803. Проверяем наличие остатка в ЕГАИс по этим разделам.
Про проверки наличия остатков в ЕГАИС на 28 число выдает:
 
Остатки на 29 число:
 
Отсюда,  кто-то "съел"  требуемый раздел. и потому теперь при отправке падаем в необеспеченный расход.
Проверяю, какие ТТН ЕГАИС были сформрованы с  FB-000000322209803
                select * from DOC_EGAIS.WAYBILL_DOC_CONTENT_TBL  where reg_id_b='FB-000000322209803';

Проверяю к каким  операциям привязаны ТТН ЕГАИС и  какое задание содержит операции:
select 
  r.*
from whs.doc_op dop
left join whs.document doc on dop.id_document=doc.id_document
join whs.redistribution_queue_tbl r on dop.id_op=r.id_op
where 
--            dop.id_op=-1018017374;
                doc.id_document in (
  316836698,
316836700,
316849551);
    
Вижу, что в раздел Б ушел в текущем задании 4245.
Смотрю,  сколько подобрали остатка по ЭДО:
                select * from WHS.REDISTRIB_EDO_RES_TBL where id_task =4245 and ID_ART=225225;
 
Виже, что подобрали один документ  (Акт постановки на баланс) с остатком на 1. В данных фактического остатка АРМ результат "2"
 

-- Запросы, поставленные в очередь по id заданий
select w.fullname, sde.*
     from DOC_EGAIS.SEND_DOC_EGAIS_TBL sde
      join whs.warehouse w on sde.WS_GUID=w.GUID
     where id_send_base in (
     498575,
499215,
494323,
498600,
492271,
493419,
479855,
476878);



Проверим сколько остатка в ЕГАИС по этой товарной позиции
  select
       doc.id_document
       , ws.fullname
       , dhed.rests_date
       , pr.full_name
       , pr.alc_code
       , dcon.quantity
       , dcon.reg_id_a
       , dcon.reg_id_b
from whs.document doc
left join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
left join whs.warehouse ws on ws.id_ws = dtb.id_ws
left join doc_egais.replyrests_doc_header_tbl dhed ON dhed.id_Document = dtb.id_document
left join doc_egais.replyrests_doc_rest_tbl dcon ON dcon.id_document = dtb.id_document
left join doc_egais.product_tbl pr ON pr.id_product = dcon.id_product
WHERE
doc.id_document = 327878710  --ИД документа ответа по остаткам на МХ  316418813
and pr.alc_code='0036813000001303803' ;-- алко код полученный в п.3


2. Посмотрю документы по разделам Б и их соответсвие результатам ЭДО
Разделы Б берем из остатков ЕГАИС
select 
  ad.REG_ID_B, 
  ac.REG_ID_A, 
  d.id_doctype, 
  d.id_document as"АПБ_ЕГАИС", 
  d1.id_document  as"АПБ"
  , adc.QUANTITY
from  doc_egais.actinvinfbreg_doc_infb_tbl ad
join doc_egais.actinvinfbreg_doc_cont_tbl  ac on ad.ID_ACTINVINFBREG_DOC_CONT=ac.ID_ACTINVINFBREG_DOC_CONT
join whs.docreference dref on ac.id_document=dref.ID_DOC_DEPEND
join whs.document  d on dref.ID_DOC_master=d.id_document
join whs.docreference dref1 on d.id_document=dref1.id_doc_master
join whs.document  d1 on dref1.ID_DOC_depend=d1.id_document and d1.id_doctype=491
join doc_egais.actchargeon_doc_content_tbl adc on d.id_document=adc.ID_DOCUMENT
where ad.REG_ID_B in (
'FB-000000350278324',
'FB-000000350278353',
'FB-000000350278879',
'FB-000000350279102',
'FB-000000350279308',
'FB-000000350279101');

2. А сколько выдал  блок ЭДО
select  distinct  id_document, id_art, quantity
from WHS.REDISTRIB_EDO_RES_TBL where id_task =4721 and ID_ART=556177; --таблица результатов по ЭДО



В рамках задачи перераспрепределения алкоголя с ОО осуществляется:
•	перенос продукции из ТЗ в склад
o	 формируется при создании задания перераспределения
•	перенос продукци из склада в ТЗ 
o	формируется после создания операции Возврата поставщику  и отправляет обратно в ТЗ неиспользованную продукцию 
o	формируется для Прихода перераспределения 

Посмотрела  как отрабатывает процесс и обнаружила проблему по отправке данных в ЕГАИС:
1. Задания по переносу остатка  из  из Р1 <-> Р2  (туда и обратно) зависли в очереди исходящих документов в статусе 7.

     select w.fullname, sde.*
     from DOC_EGAIS.SEND_DOC_EGAIS_TBL sde
      join whs.warehouse w on sde.WS_GUID=w.GUID
     join  DOC_EGAIS.REG_TRANSFER_TASK_TBL  rtt on sde.id_send_base=rtt.id_transfer_task 
       where sde.id_send_type=6  
       and rtt.id_transfer_task_base=7
      and id_transfer_task_type=1;  --перенос остатка из склада в ТЗ

 select w.fullname, sde.*, r.*
  from DOC_EGAIS.SEND_DOC_EGAIS_TBL sde
  join whs.warehouse w on sde.WS_GUID=w.GUID
  left join whs.redistribution_queue_tbl r on r.id_document = sde.id_send_base
   join  DOC_EGAIS.REG_TRANSFER_TASK_TBL  rtt on sde.id_send_base=rtt.id_transfer_task 
     where sde.id_send_type=6  
     and rtt.id_transfer_task_base=7
     and id_transfer_task_type=2  --перенос остатка из ТЗ в склад
     and  r.id_task in (4882) -- задание с проблемой переноса

Наиболеее критичный случай, когда не прокачивается  перенос остатка из ТЗ в склад (id_transfer_task_type=2). потому что в таком случае перераспредеелния не ддойдет даже до создания операций  (а следовательно ничего не будет отражено в ЕГАИС)



331135429 -- отправлено с Граве      
513576
513373
504123

-- Выяснение документов, отправленных по переносу остатков по заданию
 select w.fullname, sde.*, r.*
  from DOC_EGAIS.SEND_DOC_EGAIS_TBL sde
  join whs.warehouse w on sde.WS_GUID=w.GUID
  left join whs.redistribution_queue_tbl r on r.id_document = sde.id_send_base
   join  DOC_EGAIS.REG_TRANSFER_TASK_TBL  rtt on sde.id_send_base=rtt.id_transfer_task 
     where sde.id_send_type=6  
     and rtt.id_transfer_task_base=7
     and id_transfer_task_type=2  --перенос остатка из ТЗ в склад
     and  r.id_task in (4882) -- задание с проблемой переноса

select * from whs.redistribution_queue_tbl
-- в id_document для переноса остатков может быть указан id_send_base из таблицы doc_egais. send_doc_egais_tbl sde



--Бронь на партию
select * from whs.redistrib_task_doc_content_tbl where reg_id_b in ('FB-000000479745009')

-- сопоставление количества товара в задании с количеством товра в Р2 по нашим расчётам (ver 3.1)
with id_arft as (
select art.code, art.id_art, rtdt.quantity, wh.code as wscode from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
where rtdt.id_task in (8050)
)
,
arts as
 (select distinct a.id_art
                 ,a.NAME
                 ,a.code art_code
                 ,ap.alc_code
                 , ia.wscode
                 , ia.quantity as quantitytask
    from id_arft ia
    join whs.article a on a.ID_ART = ia.id_art
    join whs.article_kiscontr_link akl on a.id_art = akl.id_article
    join onsi_egais.alc_prod_prov_link_tbl ppl on akl.id_article_kiscontr_link = ppl.id_article_kiscontr_link
                                              and ppl.is_deleted != 1
    join onsi_egais.alc_org_link_tbl aol on ppl.id_alc_org_link = aol.id_alc_org_link
                                        and aol.isdeleted != 1
    join onsi_egais.alc_product_tbl ap on aol.id_alc_product = ap.id_alc_product
   join id_arft on a.id_art = id_arft.id_art
)
, rest_vw as (
select 
vw.wscode
, vw.alc_code
, sum (vw.quantity) as quantity
from arts a
join RETAIL.Registr_Rest_Vw vw on vw.wscode = a.wscode and vw.alc_code = a.alc_code
where vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code
)
, rest_artcode as ( -- количество по коду товара
select arts.art_code
      ,sum (rest_vw.quantity) as quantity
  from arts
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  group by arts.art_code
)
, reserv as ( -- бронь по справкам всего
select r.reg_id_b
     ,sum (bron.quantity) as quantity
  from retail.registr_tbl r
  left join whs.redistrib_task_doc_content_tbl bron on bron.reg_id_b = r.reg_id_b
   where r.alc_code in (select alc_code
                        from arts)
         and bron.used = '1'
  group by r.reg_id_b
)
select case when (rest_vw.quantity - nvl (reserv.quantity,0)) >= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков  по алк. коду"
      , case when (rest_artcode.quantity - nvl (reserv.quantity,0))>= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков по коду ТП"
      ,arts.id_art
      ,arts.art_code
      ,arts.alc_code
      ,arts.name
      ,rest_artcode.quantity as "Остаток по Коду ТП"
      ,rest_vw.quantity as "Остаток по Алк коду"
      ,arts.quantitytask as "Количество в задании"
      ,r.quantity - nvl(rm.quantity, 0) as "Остаткок по справке"
      ,reserv.quantity as "Бронь по справке"
      ,r.reg_id_b
  from retail.registr_tbl r
  /*join whs.document d on r.id_document = d.id_document
                 and d.id_doctype = 504*/ -- документ переноса не участвует в отборе
 /* join doc_egais.transferts_doc_content_tbl dc on r.id_document = dc.id_document
                                              and dc.reg_id_b = r.reg_id_b
                                              and nvl(dc.isvendetta, 0) != 1*/
  left join arts on r.alc_code = arts.alc_code
  left join rest_artcode on rest_artcode.art_code = arts.art_code
  left join retail.registr_tbl rm on rm.move_type = 'M'
                                 and r.wscode = arts.wscode /*task.wscode*/
                                 and r.reg_id_b = rm.reg_id_b
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  left join reserv on reserv.reg_id_b = r.reg_id_b
  where r.move_type = 'P'
   and r.wscode = arts.wscode /*task.wscode*/
   and r.alc_code in (select alc_code
                        from arts)
   --and r.reg_id_b is not null -- исключение из вывода неизвестных в Р2 FB 
   --and arts.art_code in ('1000169965') -- просмотр по заданным ТП
 order by id_art ASC, r.move_date desc




select max (doc.id_document), wh.id_ws
from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
join doc_egais.document_tbl dtb ON dtb.id_ws = wh.id_ws
join whs.document doc on dtb.id_document = doc.id_document 
where rtdt.id_task in (12827) and doc.id_doctype = 511
group by wh.id_ws 


 --- Сопоставление количества товара в задании с количеством товра в Р2 по нашим расчётам (ver 4.1)
with params as(
select 
'3121840077' as tp_code, -- Код ТП
'12827' as id_task -- номер задания
from dual
),
tz as ( -- Jc
select max (doc.id_document) as id_doc, wh.id_ws
from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
join doc_egais.document_tbl dtb ON dtb.id_ws = wh.id_ws
join whs.document doc on dtb.id_document = doc.id_document 
where rtdt.id_task in (select id_task from params) and doc.id_doctype = 511
group by wh.id_ws 
),
id_arft as (
select art.code, art.id_art, rtdt.quantity, wh.code as wscode from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
where rtdt.id_task = (select id_task from params) --and rc.id_document = 438137398
)
,
arts as
(select distinct a.id_art
                 ,a.NAME
                 ,a.code art_code
                 ,ap.alc_code
                 , ia.wscode
                 , ia.quantity as quantitytask
    from id_arft ia
    join whs.article a on a.ID_ART = ia.id_art
    join whs.article_kiscontr_link akl on a.id_art = akl.id_article
    join onsi_egais.alc_prod_prov_link_tbl ppl on akl.id_article_kiscontr_link = ppl.id_article_kiscontr_link
                                              and ppl.is_deleted != 1
    join onsi_egais.alc_org_link_tbl aol on ppl.id_alc_org_link = aol.id_alc_org_link
                                        and aol.isdeleted != 1
   join onsi_egais.alc_product_tbl ap on aol.id_alc_product = ap.id_alc_product
   join id_arft on a.id_art = id_arft.id_art
)
, rest_vw as (
select 
vw.wscode
, vw.alc_code
, sum (vw.quantity) as quantity
from arts a
join RETAIL.Registr_Rest_Vw vw on vw.wscode = a.wscode and vw.alc_code = a.alc_code
where vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code
)
, rest_artcode as ( -- количество по коду товара
select arts.art_code
      ,sum (rest_vw.quantity) as quantity
  from arts
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  group by arts.art_code
)
, reserv as ( -- бронь по справкам всего
select r.reg_id_b
     ,sum (bron.quantity) as quantity
  from retail.registr_tbl r
  left join whs.redistrib_task_doc_content_tbl bron on bron.reg_id_b = r.reg_id_b
   where r.alc_code in (select alc_code
                        from arts)
         and bron.used = '1'
  group by r.reg_id_b
)
, egais as (
select distinct
       rc.quantity qeg
       ,rtdt.quantity -- rc.quantity diff
       , kl.code_egais 
       , kl.id_article
   from whs.redistribution_task_detail_tbl rtdt
   join WHS.ARTICLE_KISCONTR_LINK kl on kl.id_article = rtdt.id_art
   join doc_egais.product_tbl pt on pt.alc_code = kl.code_egais
   left join doc_egais.replyrestshop_doc_content_tbl rc on rc.id_product = pt.id_product
                                                        and rc.id_document = (select id_doc from tz) --ид запрос ЕГАИС ТЗ
                                                        --and pt.alc_code = c.alc_code
   where rtdt.id_task = (select id_task from params) and rc.quantity is not null
)
select distinct case when r.reg_id_b is null then 'Справка отсутствует'
       when (rest_vw.quantity - nvl (reserv.quantity,0)) >= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков  по Алк коду"
      , case when (rest_artcode.quantity - nvl (reserv.quantity,0))>= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков по коду ТП"
      --,arts.id_art
      ,arts.art_code as "Код товара"
      ,arts.alc_code as "Алк код"
      , (rest_vw.quantity - nvl (reserv.quantity,0)) as "Остатки в нашем регистре Р2"
      --,arts.name as "Наименование продукции"
      --,rest_artcode.quantity as "Остаток по Коду ТП"
      --,rest_vw.quantity as "Остаток по Алк коду"
      ,arts.quantitytask as "Количество в задании"
      ,nvl (r2.quantity,0) - nvl(rm.quantity, 0) as "Остаткок по справке Б"
      ,nvl (reserv.quantity, 0) as "Бронь по справке Б"
      ,r.reg_id_b as "Номер справки Б"
      ,egais.qeg as "По ЕГАИС"
  from retail.registr_tbl r
  left join retail.registr_tbl r2 on r2.id_registr = r.id_registr and r2.reg_id_b is not null
  /*join whs.document d on r.id_document = d.id_document
                 and d.id_doctype = 504*/ -- документ переноса не участвует в отборе
/* join doc_egais.transferts_doc_content_tbl dc on r.id_document = dc.id_document
                                              and dc.reg_id_b = r.reg_id_b
                                              and nvl(dc.isvendetta, 0) != 1*/
  left join arts on r.alc_code = arts.alc_code
  left join egais on egais.code_egais = r.alc_code
  left join rest_artcode on rest_artcode.art_code = arts.art_code
  left join retail.registr_tbl rm on rm.move_type = 'M'
                                 and r.wscode = arts.wscode /*task.wscode*/
                                 and r.reg_id_b = rm.reg_id_b
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  left join reserv on reserv.reg_id_b = r.reg_id_b
  where r.move_type = 'P'
   and r.wscode = arts.wscode /*task.wscode*/
   and r.alc_code in (select alc_code
                        from arts)
   --and r.reg_id_b is not null -- исключение из вывода неизвестных в Р2 FB 
   --and arts.art_code in ('1000169965') -- просмотр по заданным ТП
--order by id_art ASC, r.move_date desc





 --- Сопоставление количества товара в задании с количеством товра в Р2 по нашим расчётам (ver 4.2)
with tz as (
select max (doc.id_document) as id_doc, wh.id_ws
from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
join doc_egais.document_tbl dtb ON dtb.id_ws = wh.id_ws
join whs.document doc on dtb.id_document = doc.id_document 
where rtdt.id_task = 12827 and doc.id_doctype = 511
group by wh.id_ws 
),
id_arft as (
select art.code, art.id_art, rtdt.quantity, wh.code as wscode from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
where rtdt.id_task = 12827 --and rc.id_document = 438137398
)
,
arts as
(select distinct a.id_art
                 ,a.NAME
                 ,a.code art_code
                 ,ap.alc_code
                 , ia.wscode
                 , ia.quantity as quantitytask
    from id_arft ia
    join whs.article a on a.ID_ART = ia.id_art
    join whs.article_kiscontr_link akl on a.id_art = akl.id_article
    join onsi_egais.alc_prod_prov_link_tbl ppl on akl.id_article_kiscontr_link = ppl.id_article_kiscontr_link
                                              and ppl.is_deleted != 1
    join onsi_egais.alc_org_link_tbl aol on ppl.id_alc_org_link = aol.id_alc_org_link
                                        and aol.isdeleted != 1
   join onsi_egais.alc_product_tbl ap on aol.id_alc_product = ap.id_alc_product
   join id_arft on a.id_art = id_arft.id_art
)
, rest_vw as (
select 
vw.wscode
, vw.alc_code
, sum (vw.quantity) as quantity
from arts a
join RETAIL.Registr_Rest_Vw vw on vw.wscode = a.wscode and vw.alc_code = a.alc_code
where vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code
)
, rest_artcode as ( -- количество по коду товара
select arts.art_code
      ,sum (rest_vw.quantity) as quantity
  from arts
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  group by arts.art_code
)
, reserv as ( -- бронь по справкам всего
select r.reg_id_b
     ,sum (bron.quantity) as quantity
  from retail.registr_tbl r
  left join whs.redistrib_task_doc_content_tbl bron on bron.reg_id_b = r.reg_id_b
   where r.alc_code in (select alc_code
                        from arts)
         and bron.used = '1'
  group by r.reg_id_b
)
, egais as (
select distinct
       rc.quantity qeg
       ,rtdt.quantity 
       , kl.code_egais 
       , kl.id_article
   from whs.redistribution_task_detail_tbl rtdt
   join tz on tz.id_doc is not null
   --join params on params.id_task is not null
   join WHS.ARTICLE_KISCONTR_LINK kl on kl.id_article = rtdt.id_art
   join doc_egais.product_tbl pt on pt.alc_code = kl.code_egais
   left join doc_egais.replyrestshop_doc_content_tbl rc on rc.id_product = pt.id_product and rc.id_document = tz.id_doc --ид запрос ЕГАИС ТЗ
   where rtdt.id_task = 12827 and rc.quantity is not null
)
select distinct /*case when r.reg_id_b is null then 'Справка отсутствует'
       when (rest_vw.quantity - nvl (reserv.quantity,0)) >= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков  по Алк коду"*/
      /*, case when (rest_artcode.quantity - nvl (reserv.quantity,0))>= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков по коду ТП"*/
      --,arts.id_art
      arts.art_code as "Код товара"
      ,arts.alc_code as "Алк код"
      --, (rest_vw.quantity - nvl (reserv.quantity,0)) as "Остатки в нашем регистре Р2"
      --,arts.name as "Наименование продукции"
      ,rest_artcode.quantity as "Остаток по Коду ТП"
      , nvl (reserv.quantity,0) as "В резерве"
      ,rest_vw.quantity as "Остаток по Алк коду"
      ,arts.quantitytask as "Количество в задании"
      --,nvl (r2.quantity,0) - nvl(rm.quantity, 0) as "Остаткок по справке Б"
      ,reserv.quantity as "Бронь по справке Б"
      ,r.reg_id_b as "Номер справки Б"
      ,egais.qeg as "По ЕГАИС"
  from retail.registr_tbl r
  left join retail.registr_tbl r2 on r2.id_registr = r.id_registr and r2.reg_id_b is not null
  left join arts on r.alc_code = arts.alc_code
  left join egais on egais.code_egais = r.alc_code
  left join rest_artcode on rest_artcode.art_code = arts.art_code
  left join retail.registr_tbl rm on rm.move_type = 'M'
                                 and r.wscode = arts.wscode /*task.wscode*/
                                 and r.reg_id_b = rm.reg_id_b
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  left join reserv on reserv.reg_id_b = r.reg_id_b
  where r.move_type = 'P'
   and r.wscode = arts.wscode /*task.wscode*/
   and r.alc_code in (select alc_code
                        from arts)
                        
                        
                        
                        
/
 --- Сопоставление количества товара в задании с количеством товра в Р2 по нашим расчётам (ver 5.0)
with tz as (
select max (doc.id_document) as id_doc, wh.id_ws
from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
join doc_egais.document_tbl dtb ON dtb.id_ws = wh.id_ws
join whs.document doc on dtb.id_document = doc.id_document 
where rtdt.id_task =10663 and doc.id_doctype = 511
group by wh.id_ws 
),
id_arft as (
select art.code, art.id_art, rtdt.quantity, wh.code as wscode from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
where rtdt.id_task = 10663
)
,
arts as
(select distinct a.id_art
                 ,a.NAME
                 ,a.code art_code
                 ,ap.alc_code
                 , ia.wscode
                 , ia.quantity as quantitytask
    from id_arft ia
    join whs.article a on a.ID_ART = ia.id_art
    join whs.article_kiscontr_link akl on a.id_art = akl.id_article
    join onsi_egais.alc_prod_prov_link_tbl ppl on akl.id_article_kiscontr_link = ppl.id_article_kiscontr_link
                                              and ppl.is_deleted != 1
    join onsi_egais.alc_org_link_tbl aol on ppl.id_alc_org_link = aol.id_alc_org_link
                                        and aol.isdeleted != 1
   join onsi_egais.alc_product_tbl ap on aol.id_alc_product = ap.id_alc_product
   join id_arft on a.id_art = id_arft.id_art
)
, rest_vw as (
select 
vw.wscode
, vw.alc_code
, sum (vw.quantity) as quantity
from arts a
join RETAIL.Registr_Rest_Vw vw on vw.wscode = a.wscode and vw.alc_code = a.alc_code
where vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code
)
, rest_artcode as ( -- количество по коду товара
select arts.art_code
      ,sum (rest_vw.quantity) as quantity
  from arts
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  group by arts.art_code
)
, reserv as ( -- бронь по справкам всего
select r.reg_id_b
     ,sum (bron.quantity) as quantity
  from retail.registr_tbl r
  left join whs.redistrib_task_doc_content_tbl bron on bron.reg_id_b = r.reg_id_b
   where r.alc_code in (select alc_code
                        from arts)
         and bron.used = '1'
  group by r.reg_id_b
)
/*, egais as (
select distinct
       rc.quantity qeg
       ,rtdt.quantity -- rc.quantity diff
       , kl.code_egais 
       , kl.id_article
   from whs.redistribution_task_detail_tbl rtdt
   join WHS.ARTICLE_KISCONTR_LINK kl on kl.id_article = rtdt.id_art
   join doc_egais.product_tbl pt on pt.alc_code = kl.code_egais
   left join doc_egais.replyrestshop_doc_content_tbl rc on rc.id_product = pt.id_product and rc.id_document = (select id_doc from tz) --ид запрос ЕГАИС ТЗ
   where rtdt.id_task = 10663 -- ид задания
   and rc.quantity is not null
)*/
select distinct /*case when r.reg_id_b is null then 'Справка отсутствует'
       when (rest_vw.quantity - nvl (reserv.quantity,0)) >= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков  по Алк коду"
      , case when (rest_artcode.quantity - nvl (reserv.quantity,0))>= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков по коду ТП"
      --,arts.id_art
      ,arts.art_code as "Код товара"
      ,arts.alc_code as "Алк код"
      , (rest_vw.quantity - nvl (reserv.quantity,0)) as "Остатки в нашем регистре Р2"
      --,arts.name as "Наименование продукции"
      --,rest_artcode.quantity as "Остаток по Коду ТП"
      --,rest_vw.quantity as "Остаток по Алк коду"
      ,arts.quantitytask as "Количество в задании"
      ,nvl (r2.quantity,0) - nvl(rm.quantity, 0) as "Остаткок по справке Б"
      ,reserv.quantity as "Бронь по справке Б"
      ,r.reg_id_b as "Номер справки Б"
      ,egais.qeg as "По ЕГАИС"*/
      *
  from retail.registr_tbl r
  left join retail.registr_tbl r2 on r2.id_registr = r.id_registr and r2.reg_id_b is not null
  left join arts on r.alc_code = arts.alc_code
  --left join egais on egais.code_egais = r.alc_code
  left join rest_artcode on rest_artcode.art_code = arts.art_code
  left join retail.registr_tbl rm on rm.move_type = 'M'
                                 and r.wscode = arts.wscode /*task.wscode*/
                                 and r.reg_id_b = rm.reg_id_b
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  left join reserv on reserv.reg_id_b = r.reg_id_b
  where r.move_type = 'P'
   and r.wscode = arts.wscode /*task.wscode*/
   and r.alc_code in (select alc_code from arts)                 
/

 -- Сопоставление количества товара в задании с количеством товра в Р2 по нашим расчётам (ver 4.1 _Screbcov_RI)
with params as(
select 
'9717500041' as tp_code, -- Код ТП
'340126' as oo_code, -- Код ОО
'8050' as id_task -- Номер задания 
from dual
)
, prihod as ( -- все приходы
select --a.name, op.OPDATE, op.ID_OP, a.CODE, c.fullname, op2.ID_OP as op2
 a.ID_ART/* as art*/, sum (oa.QUANTITY) as sum_prihod, c.fullname as rc_name, wh.code as oo_code, c.code as rc--_code
from
whs.article a
join whs.op_art oa on oa.ID_ART = a.ID_ART
join whs.art_moreinfo am on a.ID_ART = am.id_art
join whs.addition adi on adi.ID_ADD = am.id_add
join whs.operation op on op.ID_OP = oa.ID_OP
join whs.op_moreinfo om on om.id_op = op.ID_OP
join whs.warehouse wh on wh.id_ws = op.ID_WSI
left join whs.opreference opr on op.ID_OP = opr.id_op
join whs.operation op2 on opr.id_opref = op2.ID_OP and op2.ID_TOP = 169
left join whs.contractor c on c.id_contr = op.ID_CONTR
where
a.CODE in (select tp_code from params) and 
wh.code in (select oo_code from params)
and om.id_add = 660 and om.vbool = 1 and op.id_top = 1
and am.vstring not like '000' -- исключение безалкогольного пива
and adi.name like 'Алк_код'
and op.opdate >= '01.01.2016'
group by c.fullname, a.ID_ART, c.code, wh.code
)

, license as ( -- лицензии
select max (ald.date_end), max (ald.lastdate) as license_end, cc.code
from whs.alc_license_division ald
join whs.division d on d.id_div=ald.id_div
join whs.contractor cc on cc.id_contr=d.id_contr
join whs.alc_license_state als on als.id_alc_license_state=ald.id_alc_license_state
where cc.code like (select rc from prihod)
group by cc.code
)

, id_arft as ( -- тп из задания
select art.code as code, art.id_art, rtdt.quantity, wh.code as wscode 
from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
where rtdt.id_task = (select id_task from params)
)

, arts as ( --коды егаис
select distinct a.id_art
                 ,a.NAME
                 ,a.code as art_code
                 ,ap.alc_code as alc_code
                 , ia.oo_code
                 --, ia.quantity as quantitytask
    from prihod ia
    join whs.article a on a.ID_ART = ia.id_art
    join whs.article_kiscontr_link akl on a.id_art = akl.id_article
    join onsi_egais.alc_prod_prov_link_tbl ppl on akl.id_article_kiscontr_link = ppl.id_article_kiscontr_link
                                              and ppl.is_deleted != 1
    join onsi_egais.alc_org_link_tbl aol on ppl.id_alc_org_link = aol.id_alc_org_link
                                        and aol.isdeleted != 1
   join onsi_egais.alc_product_tbl ap on aol.id_alc_product = ap.id_alc_product
   join prihod on a.id_art = prihod.id_art
)

, rest_vw as ( -- остатки р2
select 
vw.wscode
, vw.alc_code as alc_code
, sum (vw.quantity) as quantity
from arts ar
join RETAIL.Registr_Rest_Vw vw on vw.wscode = ar.code and vw.alc_code = ar.alc_code
where vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code
)

, rest_artcode as ( -- количество по коду товара
select arts.art_code
      ,sum (rest_vw.quantity) as quantity
  from arts
  left join rest_vw on rest_vw.wscode = arts.code and rest_vw.alc_code = arts.alc_code
  group by arts.art_code
)
, reg_id_b as ( -- уникальные справки в регистре движений по Р2
select distinct r.reg_id_b
  from retail.registr_tbl r
   where r.alc_code in (select alc_code
                        from arts)
)
, reserv as ( -- бронь по справкам всего
select r.reg_id_b, r.id_task as task,stat2.name as stat_name 
     ,sum (bron.quantity)as quantity
  from reg_id_b r
  left join whs.redistrib_task_doc_content_tbl bron on bron.reg_id_b = r.reg_id_b
  join whs.redistribution_task_tbl stat1 on bron.id_task = stat1.id_task
  join whs.redistribution_status_tbl stat2 on stat2.id_status = stat1.id_status
   where bron.used = '1'
group by r.reg_id_b
)

, tz as (
select max (doc.id_document) as id_doc, wh.id_ws, eg.quantity, wa.CODE
from doc_egais.replyrestshop_doc_content_tbl eg
join whs.document doc on eg.id_document = doc.id_document
join doc_egais.product_tbl pt on pt.id_product = eg.id_product
join WHS.ARTICLE_KISCONTR_LINK kl on pt.alc_code = kl.code_egais
join whs.article wa on wa.ID_ART = kl.id_article
join doc_egais.document_tbl dt on dt.id_document = eg.id_document
join whs.warehouse wh on dt.id_ws = dt.id_ws
where wa.code = (select tp_code from params) and wh.code = (select oo_code from params) and doc.id_doctype = 511-- and rc.quantity is not null
group by wh.id_ws, eg.quantity
)
select * from tz
select distinct case when r.reg_id_b is null then 'Справка отсутствует'
       when (rest_vw.quantity - nvl (reserv.quantity,0)) >= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков  по Алк коду"
      , case when (rest_artcode.quantity - nvl (reserv.quantity,0))>= arts.quantitytask then 'Достаточно'
        else 'Не хватает' end as "Остатков по коду ТП"
      , case when (nvl (r2.quantity,0) - nvl(rm.quantity, 0))>= arts.quantitytask then 'Достаточно' else 'Не хватает' end as "Остаток по справке Б"    
      
      , prihod.sum_prihod 
      , prihod.rc_name
      , prihod.rc_code 
      , reserv.task
      , reserv.stat_name 
      , license.license_end 
      --,arts.id_art
      , arts.art_code as "Код товара"
      , arts.alc_code as "Алк код"
      , r.reg_id_b as "Номер справки Б"
      , (rest_vw.quantity - nvl (reserv.quantity,0)) as "Остатки в Р2"
      , arts.name as "Наименование продукции"
      , rest_artcode.quantity as "Остаток по Коду ТП"
      --,rest_vw.quantity as "Остаток по Алк коду"
      , id_arft.quantitytask as "Количество в задании"
      , nvl (r2.quantity,0) - nvl(rm.quantity, 0) as "Остаткок по справке Б"
      , tz.qeg as "По ЕГАИС"
      , reserv.quantity as "Бронь по справке Б"
  from whs.article a
  left join whs.article a2 on a.code = a2.CODE
  left join prihod on params.tp_code = a2.CODE 
  left join license on license.code = prihod.rc_code
  left join id_arft on id_arft.code = prihod.code
  left join arts on arts.art_code = id_arft.code
  left join rest_vw on rest_vw. 
  left join rest_artcode on
  left join red_id_b on
  left join reserv on
  left join tz on
  
  
  
  
  
  from retail.registr_tbl r
  left join retail.registr_tbl r2 on r2.id_registr = r.id_registr and r2.reg_id_b is not null
  /*join whs.document d on r.id_document = d.id_document
                 and d.id_doctype = 504*/ -- документ переноса не участвует в отборе
/* join doc_egais.transferts_doc_content_tbl dc on r.id_document = dc.id_document
                                              and dc.reg_id_b = r.reg_id_b
                                              and nvl(dc.isvendetta, 0) != 1*/
  left join arts on r.alc_code = ap.alc_code
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  
  left join tz on egais.code_egais = r.alc_code
  left join rest_artcode on rest_artcode.art_code = arts.art_code
  left join retail.registr_tbl rm on rm.move_type = 'M'
                                 and r.wscode = arts.wscode /*task.wscode*/
                                 and r.reg_id_b = rm.reg_id_b
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  left join reserv on reserv.reg_id_b = r.reg_id_b
  where r.move_type = 'P'
   and r.wscode = arts.wscode /*task.wscode*/
   and r.alc_code in (select alc_code
                        from arts)
   --and r.reg_id_b is not null -- исключение из вывода неизвестных в Р2 FB 
   --and arts.art_code in ('1000169965') -- просмотр по заданным ТП
--order by id_art ASC, r.move_date desc




 --- Сопоставление количества товара в задании с количеством товра в Р2 по нашим расчётам (ver 6.0)
with params as(
select 
'3121840077' as tp_code, -- Код ТП
'12827' as id_task -- номер задания
from dual
),
tz as ( -- Выяснение последнего ответа на запрос остатков в ТЗ из ЕГАИС
select max (doc.id_document) as id_doc, wh.id_ws
from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
join doc_egais.document_tbl dtb ON dtb.id_ws = wh.id_ws
join whs.document doc on dtb.id_document = doc.id_document 
where rtdt.id_task in (select id_task from params) and doc.id_doctype = 511
group by wh.id_ws 
),
id_arft as ( -- определение МХ и количества в задании
select art.code, art.id_art, rtdt.quantity, wh.code as wscode, wh.id_ws 
from whs.redistribution_task_detail_tbl rtdt
left join whs.article art on art.id_art = rtdt.id_art
join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task
left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from
where rtdt.id_task = (select id_task from params) and art.CODE = (select tp_code from params)
)
, prihod as ( -- Обороты в приходах
select --a.name, op.OPDATE, op.ID_OP, a.CODE, c.fullname, op2.ID_OP as op2
 a.ID_ART/* as art*/, sum (oa.QUANTITY) as sum_prihod, c.fullname as rc_name, wh.code as oo_code, c.code as rc--_code
from
whs.article a
join whs.op_art oa on oa.ID_ART = a.ID_ART
join whs.art_moreinfo am on a.ID_ART = am.id_art
join whs.addition adi on adi.ID_ADD = am.id_add
join whs.operation op on op.ID_OP = oa.ID_OP
join whs.op_moreinfo om on om.id_op = op.ID_OP
join whs.warehouse wh on wh.id_ws = op.ID_WSI
left join whs.opreference opr on op.ID_OP = opr.id_op
join whs.operation op2 on opr.id_opref = op2.ID_OP and op2.ID_TOP = 169
left join whs.contractor c on c.id_contr = op.ID_CONTR
join id_arft on id_arft.id_art = a.id_art
where
a.CODE in (select tp_code from params) and 
wh.code = id_arft.wscode
and om.id_add = 660 and om.vbool = 1 and op.id_top = 1
and am.vstring not like '000' -- исключение безалкогольного пива
and adi.name like 'Алк_код'
and op.opdate >= '01.01.2016'
group by c.fullname, a.ID_ART, c.code, wh.code
)
, license as ( -- лицензии ОО
select max (ald.date_end) as date_end, max (ald.lastdate) as lastdate, id_arft.wscode
from whs.alc_license_division ald
join whs.division d on d.id_div=ald.id_div
join whs.contractor cc on cc.id_contr=d.id_contr
join whs.alc_license_state als on als.id_alc_license_state=ald.id_alc_license_state
left join id_arft on 1=1
where cc.code = ('    '||id_arft.wscode)-- можно выводить по РЦ, если подставить код РЦ (select rc from prihod)
group by id_arft.wscode
)
,arts as
(select distinct a.id_art --маппинг кодов ТП на коды ЕГАИС, получение алк. кодов ЕГАИС
                 ,a.NAME
                 ,a.code art_code
                 ,ap.alc_code
                 , ia.wscode
                 , ia.quantity as quantitytask
    from id_arft ia
    join whs.article a on a.ID_ART = ia.id_art
    join whs.article_kiscontr_link akl on a.id_art = akl.id_article
    join onsi_egais.alc_prod_prov_link_tbl ppl on akl.id_article_kiscontr_link = ppl.id_article_kiscontr_link
                                              and ppl.is_deleted != 1
    join onsi_egais.alc_org_link_tbl aol on ppl.id_alc_org_link = aol.id_alc_org_link
                                        and aol.isdeleted != 1
   join onsi_egais.alc_product_tbl ap on aol.id_alc_product = ap.id_alc_product
   join id_arft on a.id_art = id_arft.id_art
)
, rest_vw as ( --остаток в нашем Р2
select 
vw.wscode
, vw.alc_code
, sum (vw.quantity) as quantity
from arts a
join RETAIL.Registr_Rest_Vw vw on vw.wscode = a.wscode and vw.alc_code = a.alc_code
where vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code
)
, rest_tu as ( -- остаток по ТУ ММ
select r.id_art, r.fquant, ia.id_ws from id_arft ia
join whs.rest r on r.id_art = ia.id_art and r.id_ws = ia.id_ws
where r.mn = (select max (r. mn) as mn from id_arft ia
             join whs.rest r on r.id_art = ia.id_art and r.id_ws = ia.id_ws
              group by ia.id_ws)
)
, rest_artcode as ( -- количество по коду товара
select arts.art_code
      ,sum (rest_vw.quantity) as quantity
  from arts
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  group by arts.art_code
)
, reserv as ( -- бронь по справкам всего
select r.reg_id_b
     ,sum (bron.quantity) as quantity
  from retail.registr_tbl r
  left join whs.redistrib_task_doc_content_tbl bron on bron.reg_id_b = r.reg_id_b
   where r.alc_code in (select alc_code
                        from arts)
         and bron.used = '1'
  group by r.reg_id_b
)
, egais as ( --остатки в ТЗ по ЕГАИС
select distinct
       rc.quantity qeg
       ,rtdt.quantity -- rc.quantity diff
       , kl.code_egais 
       , kl.id_article
   from whs.redistribution_task_detail_tbl rtdt
   join WHS.ARTICLE_KISCONTR_LINK kl on kl.id_article = rtdt.id_art
   join doc_egais.product_tbl pt on pt.alc_code = kl.code_egais
   left join doc_egais.replyrestshop_doc_content_tbl rc on rc.id_product = pt.id_product
                                                        and rc.id_document = (select id_doc from tz) --ид запрос ЕГАИС ТЗ
                                                        --and pt.alc_code = c.alc_code
   where rtdt.id_task = (select id_task from params) and rc.quantity is not null
)
select distinct case when r.reg_id_b is null then 'Справка отсутствует'
       when (rest_vw.quantity - nvl (reserv.quantity,0)) >= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков  по Алк коду"
      , case when (rest_artcode.quantity - nvl (reserv.quantity,0))>= arts.quantitytask then 'Достаточно'
       else 'Не хватает' end as "Остатков по коду ТП"
      --,arts.id_art
      ,arts.art_code as "Код товара"
      ,arts.alc_code as "Алк код"
      , (rest_vw.quantity - nvl (reserv.quantity,0)) as "Остатки в нашем регистре Р2"
      --,arts.name as "Наименование продукции"
      , l.date_end as "Дата окончания лицензии"
      /*, l.code as lcode 
      , arts.wscode as artswscode*/
      , p.sum_prihod as "Обороты с РЦ"
      , p.rc_name as "РЦ поставщик" 
      , p.rc as "Код РЦ поставщика"
      , rest_tu.fquant as "Остатки по ТУ"
      --,rest_artcode.quantity as "Остаток по Коду ТП"
      --,rest_vw.quantity as "Остаток по Алк коду"
      ,arts.quantitytask as "Количество в задании"
      ,nvl (r2.quantity,0) - nvl(rm.quantity, 0) as "Остаткок по справке Б"
      ,nvl (reserv.quantity, 0) as "Бронь по справке Б"
      ,r.reg_id_b as "Номер справки Б"
      ,egais.qeg as "По ЕГАИС"
  from retail.registr_tbl r
  left join retail.registr_tbl r2 on r2.id_registr = r.id_registr and r2.reg_id_b is not null
  /*join whs.document d on r.id_document = d.id_document
                 and d.id_doctype = 504*/ -- документ переноса не участвует в отборе
/* join doc_egais.transferts_doc_content_tbl dc on r.id_document = dc.id_document
                                              and dc.reg_id_b = r.reg_id_b
                                              and nvl(dc.isvendetta, 0) != 1*/
  left join arts on r.alc_code = arts.alc_code
  left join egais on egais.code_egais = r.alc_code
  left join rest_artcode on rest_artcode.art_code = arts.art_code
  left join retail.registr_tbl rm on rm.move_type = 'M'
                                 and r.wscode = arts.wscode /*task.wscode*/
                                 and r.reg_id_b = rm.reg_id_b
  left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code
  left join reserv on reserv.reg_id_b = r.reg_id_b
  left join rest_tu on rest_tu.id_art = arts.id_art
  left join prihod p on p.id_art = arts.id_art
  left join license l on l.wscode = arts.wscode
  where r.move_type = 'P'
   and r.wscode = arts.wscode /*task.wscode*/
   and r.alc_code in (select alc_code
                        from arts)
   --and r.reg_id_b is not null -- исключение из вывода неизвестных в Р2 FB 
   --and arts.art_code in ('1000169965') -- просмотр по заданным ТП
--order by id_art ASC, r.move_date desc

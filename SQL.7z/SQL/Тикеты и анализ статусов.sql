--�������� �������:
select td.id_document, tdr.comments,tdo.operation_comment
from doc_egais.ticket_doc_header_tbl  td
left join doc_egais.ticket_doc_result_tbl  tdr on td.id_ticket_doc_result=tdr.id_ticket_doc_result
left join doc_egais.ticket_doc_opresult_tbl  tdo on td.id_ticket_doc_opresult = tdo.id_ticket_doc_opresult
where td.id_document in (382713989)

--������������� ����� ������ ��� ������� �������� � 10 �������:
with
  source_data as(
      SELECT
        op.id_op, op.ID_WSO, stt.fullname, op.opnumber, op.opdate, sd.id_document, dh.ticket_date, dres.*
      from doc_egais.send_doc_egais_tbl sd
      Left join whs.operation op on op.ID_OP = sd.id_send_base
      LEFT JOIN whs.warehouse stt ON stt.guid = sd.ws_guid
      LEFT JOIN  whs.docreference dref ON dref.id_doc_master = sd.id_document
      JOIN doc_egais.ticket_doc_header_tbl dh ON dh.id_document = dref.id_doc_depend
        JOIN doc_egais.ticket_doc_opresult_tbl dres ON dres.id_ticket_doc_opresult = dh.id_ticket_doc_opresult
      WHERE
      stt.lg1 = 601 and sd.id_doctype = 481 AND sd.id_Send_status = 10 AND op.opdate > TO_DATE('24.08.2016')

  )
  select 
      s.id_op, s.opnumber, s.opdate, s.id_wso, s.fullname, 
      s.ticket_date, s.operation_comment, s.id_document,
      wc.id_position, pr.alc_code, wc.quantity, wc.reg_id_a, wc.reg_id_b, wc.id_analyticopart
  from source_data s
  join DOC_EGAIS.waybill_doc_content_tbl wc on wc.id_document = s.id_document and wc.id_position in (
          select res from table(whs.clob2cursor(s.operation_comment, ' '))
          where regexp_like(trim(res), '^[[:digit:]]+$')
        )
  join doc_Egais.Product_Tbl pr ON pr.id_product = wc.id_product
  order by s.opdate desc, wc.id_position;



-- ������, ������������ � ������� ��������� + ���� �� �������� ���������� (�� ��)
with a_list as
(
select /*+ materialize*/
       w.id_ws,
       w.higher,
       w.code as wscode,
       w.fullname as wsname,
       op.opdate,
       op.id_op,
       sdt.id_doctype,
       sdt.id_document,
       trim(replace(replace(regexp_substr(cast(tor.operation_comment as varchar2(4000))
                           ,'(�������).+(�����)'),'�������',''),'�����','')) as positions
from doc_egais.send_doc_egais_tbl sdt
join whs.operation op on op.ID_OP = sdt.id_send_base
join whs.warehouse w on w.guid = sdt.ws_guid
join doc_egais.ticket_doc_header_tbl tk on tk.id_document = sdt.id_ticket
join doc_egais.ticket_doc_opresult_tbl tor on tor.id_ticket_doc_opresult = tk.id_ticket_doc_opresult
where 1=1
  and sdt.id_send_status = 10
  and op.id_top = 169 and sdt.id_send_type = 1
  and ((sdt.last_work_date > to_date('24.08.2016','dd.mm.yyyy')
  and op.opdate > to_date('24.08.2016','dd.mm.yyyy')
and w.fullname not like '%������������%' and w.fullname not like '%�����������%')
  or
  (sdt.last_work_date > to_date('29.08.2016','dd.mm.yyyy')
  and op.opdate > to_date('29.08.2016','dd.mm.yyyy')
  and w.fullname like '%������������%')
  or
  (sdt.last_work_date > to_date('06.09.2016','dd.mm.yyyy')
  and op.opdate > to_date('06.09.2016','dd.mm.yyyy')
  and w.fullname like '%�����������%'))),
b_list as (
select /*+ materialize
           leading(a wc p aoa art q qd)
           use_nl(wc) use_nl(p)
           use_nl(aoa) use_nl(art)
           use_nl(q) use_nl(qd)*/
       a.id_ws
      ,a.wscode
      ,a.wsname
      ,a.opdate
      ,a.id_op
      ,a.positions
      ,wc.id_position
      ,p.alc_code
      ,wc.quantity
      ,aoa.ID_ART
      ,art.code as artcode
      ,art.NAME as artname
      ,aoa.QUANTITY as op_quant
            ,(select to_char(q.start_date,'dd.mm.yyyy hh24:mi:ss')
          from acan.ai_queue_tbl q
          join acan.ai_queue_detail_tbl qd on qd.id_document = q.id_document
         where q.id_ws = a.higher
           and q.status = 2
           and qd.id_art = art.id_art
           and q.start_date = (select max(q2.start_date)
                                 from acan.ai_queue_tbl q2
                                 join acan.ai_queue_detail_tbl qd2 on qd2.id_document = q2.id_document
                                where q2.id_ws = q.id_ws
                                  and q2.status = 2
                                  and qd2.id_art = qd.id_art)) as start_recalc_date
                                  
,(select to_char(q.end_date,'dd.mm.yyyy hh24:mi:ss')
          from acan.ai_queue_tbl q
          join acan.ai_queue_detail_tbl qd on qd.id_document = q.id_document
         where q.id_ws = a.higher
           and q.status = 2
           and qd.id_art = art.id_art
           and q.start_date = (select max(q2.start_date)
                                 from acan.ai_queue_tbl q2
                                 join acan.ai_queue_detail_tbl qd2 on qd2.id_document = q2.id_document
                                where q2.id_ws = q.id_ws
                                  and q2.status = 2
                                  and qd2.id_art = qd.id_art)) as end_recalc_date

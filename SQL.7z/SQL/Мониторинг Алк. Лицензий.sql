--select * from table(doc_egais.monitoring_api.mon_div_license(sysdate));


with w_list as
(select /*+ materialize*/ w.id_ws
from whs.storage_tbl w
where w.code in (select opnumber from doc_egais.tt_opnumber))

select whh.code, whh.fullname, q.*, case q.status when '1' then '�������� ������' when '3' then '������� �����' else '������' end STATUS
from doc_egais.query_doc_header_tbl h
join doc_egais.document_tbl dd on dd.id_document = h.id_document
left join whs.warehouse whh on whh.id_ws =dd.id_ws
join whs.document d on d.id_document = dd.id_document
/*left */join doc_egais.query_doc_status_tbl q on q.id_doc_query = dd.id_document
where h.id_query_type = 12
and d.lastdate > to_date('20171111 12:43:00','yyyymmdd hh24:mi:ss')
and d.lastdate < to_date('20171111 12:45:00','yyyymmdd hh24:mi:ss')
and dd.id_ws in (select id_ws from w_list)
order by whh.fullname



with w_list as
(select /*+ materialize*/ w.id_ws
from whs.storage_tbl w
where w.code in (select opnumber from doc_egais.tt_opnumber))

select count (distinct dd.id_ws) "���-�� ��", case q.status when '1' then '�������� ������' when '3' then '������� �����' else '������' end STATUS
from doc_egais.query_doc_header_tbl h
join doc_egais.document_tbl dd on dd.id_document = h.id_document
left join whs.warehouse whh on whh.id_ws =dd.id_ws
join whs.document d on d.id_document = dd.id_document
/*left */join doc_egais.query_doc_status_tbl q on q.id_doc_query = dd.id_document
where h.id_query_type = 12
and d.lastdate > to_date('20171111 12:43:00','yyyymmdd hh24:mi:ss')
and d.lastdate < to_date('20171111 12:45:00','yyyymmdd hh24:mi:ss')
and dd.id_ws in (select id_ws from w_list)
group by q.status

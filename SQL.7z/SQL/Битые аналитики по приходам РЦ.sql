 -----�������� �� ��-
with t as( 
select op.ID_OP, op.opnumber, op.opdate,  cc.fullname as cname,cc.code,
w.fullname as wname, oa.id_art, max(oa.QUANTITY) as op_quant, sum(aop.quantity) as an_quant from whs.operation op 
left join whs.contractor cc on cc.id_contr=op.id_contr 
left join whs.warehouse w on w.id_ws=op.id_wso 
left join whs.op_art oa on oa.ID_OP = op.ID_OP 
left join acan.analyticopart_tbl aop on op.opguid=aop.opguid and oa.ID_ART=aop.id_art 
where trim(op.opnumber) = '560186A1129' 
 and op.opdate ='17.02.2016' 
 and op.id_top = 169 
group by op.ID_OP, oa.id_art, op.opnumber, cc.fullname, w.fullname, op.opdate, cc.code 
) 
select
t.opnumber,
t.opdate,
t.code, 
case when sum(t.op_quant) = sum(nvl(t.an_quant,0)) then 1 else 0 end 
from t 
group by t.opnumber, t.opdate, t.code
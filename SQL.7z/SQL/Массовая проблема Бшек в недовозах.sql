------ �������� �������� ��� ���� �� ��������
        with docB as (
            select     /*+ leading(sde opr)
                       index(sde SEND_DOC_TYPE_IDX)
                       index(opr p_operation) use_nl(opr)*/
                  distinct t.id_doc_replyB
             from doc_egais.send_doc_egais_tbl sdt 
              join whs.operation op on op.id_op = sdt.id_send_base
              join table(doc_Egais.Outgoing_Doc_Api.vw_info_waybill_au(op.id_op, null)) t ON 1=1
            where 
              op.id_top = 169
              and sdt.last_work_date > '01.01.2016'
              and op.opdate >= to_date ('01.04.2016')--between to_date() and to_date('02.') --> '25.08.2016'
              and sdt.id_send_status = 3
              and sdt.id_doctype = 481
              and t.id_doc_replyB is not null
             -- and sdt.id_send_base = -1177549118
              and sdt.description like ('ORA-20000: � ��������� ������� � ������� ����������� ��������� ��. ������� ������ �%') 
              and not exists(
                  select 1
                  from  whs.docreference df
                  where
                        df.id_doc_depend = t.id_Doc_replyB
                        and df.reftype = 'A'
              )
        ), 
        oplist as (
               select distinct do.id_op
               from whs.doc_op do
               join docB db ON db.id_doc_replyB = do.id_document
        )
        --������ ���� �� ����� �������
        select 
               '������� (����)',
               op.ID_TOP, op.ID_OP, op.OPDATE, sd.id_send_status, sd.description, 
               coalesce(sd.ticket_date, sd.send_date, sd.add_date) As date1, 
               '������� (����)',
               op2.ID_top, op2.ID_OP, op2.OPDATE,  sd2.id_send_status, sd2.description, 
               coalesce(sd2.ticket_date, sd2.send_date, sd2.add_date) As date2,
               '������ ������',
               op3.ID_top, op3.ID_OP, op3.OPDATE, sd3.id_send_status, sd3.description, 
               coalesce(sd3.ticket_date, sd3.send_date, sd3.add_date) As date3,
               '������ ������',
               op4.ID_top, op4.ID_OP, op4.OPDATE, sd4.id_send_status, sd4.description, 
               coalesce(sd4.ticket_date, sd4.send_date, sd4.add_date) As date4, sd4.id_wbinform 
               
        from whs.operation op
        join doc_Egais.Send_Doc_Egais_Tbl sd ON sd.id_send_base = op.ID_OP
        join whs.opreference opf ON opf.id_op = sd.id_send_base and opf.reftype = 'E'

        join whs.operation op2 ON op2.ID_OP = opf.id_opref 
        join doc_Egais.Send_Doc_Egais_Tbl sd2 ON sd2.id_send_base = op2.ID_OP
        join whs.opreference opf2 ON opf2.id_op = sd2.id_send_base and opf2.reftype in ('W', '2')
        join oplist ol ON ol.id_op = op2.ID_OP

        join whs.operation op3 ON op3.ID_OP = opf2.id_opref
        join doc_Egais.Send_Doc_Egais_Tbl sd3 ON sd3.id_send_base = op3.ID_OP
        join whs.opreference opf3 ON opf3.id_op = sd3.id_send_base and opf3.reftype = 'E'

        join whs.operation op4 ON op4.ID_OP = opf3.id_opref
        join doc_Egais.Send_Doc_Egais_Tbl sd4 ON sd4.id_send_base = op4.ID_OP
        where
             sd4.id_send_status = 11
             and sd3.id_send_status <>11 
          --   and sd2.id_send_status <> 11
     --        and sd.id_send_status <> 11

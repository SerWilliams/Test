-- ������ ������ Oracle
select * from v$version

select * from whs.operation op where op.OPNUMBER = '230908A3167'

select * from doc_egais.send_doc_egais_tbl s where s.id_send_base in (-1211541984)

select * from whs.historyop h 
where h.opnumber in ('777803I4472','777803I4544','777803I4555','777803I5487Peren','777803I5488Peren')
--h.id_op in (-1518946903,	-1554874560)
order by h.id_op, h.ROWID

select * from whs.warehouse wh where wh.code = '230909'
select * from whs.warehouse wh where wh.id_ws = 2
select * from whs.warehouse wh where wh.id_region = 346 -- location 1608, id_geosite = 858, id_corp_region

-- ������ �������� �� ���� � ���� �� ��
select min (o.OPDATE)
from whs.op_moreinfo om
join whs.operation o on o.ID_OP = om.id_op
join whs.typeop t on t.ID_TOP = o.ID_TOP
join whs.warehouse wh on wh.id_ws = nvl (o.ID_WSI, o.ID_WSO)
where om.id_add = 692
and wh.code = '230909'


select *
             from whs.warehouse w
               join whs.corp_region cr on w.id_corp_region = cr.id_corp_region 
               join whs.corp_region cr1 on cr.higher = cr1.id_corp_region 
               join whs.corp_region cr2 on cr1.higher = cr2.id_corp_region
             where cr.name = '��' and cr2.name = '�����' and cr1.name = '���������'

-- ����� ������ �� �������� � ���� � ��
select *
from whs.operation op
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
left join doc_Egais.Reg_Transfer_Task_Tbl r on op.ID_OP = r.id_op
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = r.id_transfer_task
where op.OPGUID = hextoraw ('546CDB34A48715BAE0537DA20C0AD985')
select
ad.name, 
om.*
 from operation op
left join op_moreinfo om on om.id_op=op.id_op
left join addition ad on ad.id_add=om.id_add
 where op.opguid in ('CA3A534ED90F10000380008048598F6E')
 
select 1 from whs.distribute_tngp_ws where id_ws = v_id_ws
select * from whs.distribute_tngp_ws where id_ws = v_id_ws

DECLARE
lk number;
begin
  for cur in (select * from doc_egais.send_doc_egais_tbl s where s.id_send_base in (-1563893783,-1563893772,-1563893704,-1563891728,-1565871673))
    loop
      select op.id_op into lk from whs.operation op where op.id_op = cur.id_send_base;
/*      if lk > 10 
        then 
          else if lk = 10
          then
            else
              lk = 0
              end if;*/
      dbms_output.put_line (lk || ' - ');
      end loop;
end;

SHOW TO_CHAR(SYSDATE, NA, NLS_DATE_LANGUAGE 'german')

select * from whs.

select distinct c.code, c.fullname,c.kpp, wh.code, wh.name/*, st.**/ from doc_egais.send_doc_egais_tbl st
join whs.warehouse wh on wh.guid = st.ws_guid
join whs.operation op on op.ID_OP = st.id_send_base
join whs.contractor c on c.id_contr = op.ID_CONTR
where op.opguid in (hextoraw ('9FB4F100AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('A0C39DB2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('50BD4944AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('569DABE2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('36E40288AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('380EBD74AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('39366D3CAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('2619F0A2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('27372C48AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('286206C4AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('1E9EE242AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('1FAC549EAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('20D36006AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('9FD24D14AB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('ACC1428CAB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('AEFEAE86AB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('B15F3556AB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('BA67007AAB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('BCE327C0AB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('A3237B32AB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('A5BA058CAB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('A817546AAB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('AA92DAF2AB2F11E6BB41F8B1A0A0EDC6'),
hextoraw ('4A9C4A54AB3711E6BB41F8B1A0A0EDC6'),
hextoraw ('B9516C1AAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('C8098274AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('C97F4404AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('CAEDDE40AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('CC589AEAAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('CDDD0112AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('CF3F82DCAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('D116D222AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('D29017B2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('D3DB67D4AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('D52B5BE4AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('BDA42C3AAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('D69585EAAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('D7F5DD4AAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('D95ECE30AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('DAD0B152AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('DC3797EAAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('DDA50644AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('DF019764AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('E06A541AAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('E1D393A2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('E3457AFCAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('C3B861C2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('E4BD4D38AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('E630D4B4AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('E7981114AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('E91555E2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('EA853F1EAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('EBE60CA8AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('ED6C6388AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('EF881040AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('C52830B4AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('C69D78F0AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('F1667B72AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('FACAD456AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('FC855D66AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('FE6A8840AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('F348D5A2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('F5376EBEAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('F726CFD0AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('F8FD6D50AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('A5AD5BBAAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('159E0308AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('17A5D18AAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('18F0FA06AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('1A154AC2AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('11D5EA92AB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('13251F4EAB3011E6BB41F8B1A0A0EDC6'),
hextoraw ('146A67ECAB3011E6BB41F8B1A0A0EDC6'))
--where id_send_base in ('-1214169696','-1256503530','-1151370013','-1152391964','-1151289125','-1152625186','-1153460241','-1152570641','-1150581717','-1154481232','-1151536828','-1153599586','-1154551524','-1155565926','-1154695305','-1196672594')--(-1260238860,-1264621884,-1262463152)
--= -1233887583
--in (-1263211265,-1262147219,-1261032677,-1259897153,-1258736836,-1257603929,-1256674252,-1255440876,-1254375198,-1265290365,-1264181338,-1253429334,-1253258998,-1252061475,-1254616309,-1255527447,-1252152486,-1251057679,-1263257673,-1262202498,-1261098118,-1260008842,-1258799197,-1257710327,-1256581587,-1253328117,-1243843929,-1263209056,-1259818068,-1243717072,-1234905356,-1234901377,-1241266650,-1266294435,-1263911168,-1260987336,-1259813068,-1258583270,-1258582818,-1257630398,-1256435567,-1255447868,-1265174694,-1263571259,-1263157205,-1259991011,-1232716148,-1257544419,-1212047692,-1243376844,-1234732554,-1241463829,-1249667496,-1247800569,-1244319413,-1256683666,-1254521643,-1209903617,-1239026559,-1240015186,-1242746998,-1262287101,-1233860998,-1231808696,-1244083457,-1235102698,-1259164440,-1262151170,-1233531726,-1264621884,-1262463152,-1260238860,-1251406114,-1256966935,-1248065393,-1251233323,-1240312690,-1250906247,-1242169619,-1247760820,-1248788049,-1243764705,-1257794053,-1255465519,-1260660676,-1245227292,-1242837969,-1236990310,-1236061984,-1230516182,-1242220981,-1262110500,-1265268725,-1259112952,-1257980741,-1259164303,-1255686167,-1252449692,-1233887583,-1263073862,-1265286131,-1233523930,-1264565746,-1213276958,-1213062668,-1234001781,-1232781084,-1233023469,-1258005991,-1252433536,-1262411814,-1260228992,-1264062989,-1263127493,-1262138562,-1258582229,-1264076398,-1165104348,-1233516923,-1241628766,-1251655008,-1258362756,-1258052260,-1263095660,-1175802204,-1248691198,-1256497531,-1255615956,-1254538122,-1253465689,-1265307250,-1264210766,-1263204247,-1261154385,-1258846855,-1257951596,-1257950832,-1265411708,-1263278658,-1261112935,-1258865429,-1256613972,-1254455022,-1252305386,-1250024453)
and wh.code not in ('502789','400075','560149','560169','640049','440004','770106','610162','610604','730093','230201','770136','610108','320030','771348','729755','620031','517036','610648','230815','230211','230207','230771','770003','520194','524600','524602','520065','524708','773071','230727','090004','502375','773375','770068','662011','668623','770025','771743','784356','784304','110058','502736','130011','130050','470155','260010','260106','260380','260265','260286','210075','744057','740650','630552','691091','690012','691074','570066','570018','860315','670060','687370')

select * from whs.document d where d.id_document in (404218324, 403522325)
select op.ID_OP from whs.operation op where op.opguid = hextoraw ('0A0AD4CAACD011E69152F8B1A0A0D9A4')

select * from whs.warehouse wh where wh.guid in (hextoraw ('028EDD9E85E911DEB12A003048579853'),hextoraw ('0695C6CFD98D11DEBCB7003048579853'),hextoraw ('0A891250EA7011E58C245EF3FCE0557F'),hextoraw ('0F40E6E1EFAB11E2B8F15EF3FCE053DF'),hextoraw ('191E551AA69811E2924F5EF3FCE0557F'),hextoraw ('1EC2156DD15311E1B71A0021281A0D5A'),hextoraw ('1EC21580D15311E1B71A0021281A0D5A'),hextoraw ('211C1B9B615A11E2A3C05EF3FCE053DF'),hextoraw ('264C7B08CA7411DF8B6B0021281A0D5A'),hextoraw ('2E2F108D2BDA11E69BDD5EF3FCE0557F'),hextoraw ('374553672BAB11E69BDD5EF3FCE0557F'),hextoraw ('41557C69084711DC87F900093D12899D'),hextoraw ('41557CD5084711DC87F900093D12899D'),hextoraw ('41557D05084711DC87F900093D12899D'),hextoraw ('41557D42084711DC87F900093D12899D'),hextoraw ('41557D86084711DC87F900093D12899D'),hextoraw ('47895A04084711DC87F900093D12899D'),hextoraw ('47895A2B084711DC87F900093D12899D'),hextoraw ('47895ABA084711DC87F900093D12899D'),hextoraw ('47895B03084711DC87F900093D12899D'),hextoraw ('47895B94084711DC87F900093D12899D'),hextoraw ('47895C15084711DC87F900093D12899D'),hextoraw ('4A3963F5CDED11DF8B6B0021281A0D5A'),hextoraw ('4AAFA15A5E6211E48EC45EF3FCE0557F'),hextoraw ('4E130E96084711DC87F900093D12899D'),hextoraw ('53A17FB1087111E68C245EF3FCE0557F'),hextoraw ('543FC40F084711DC87F900093D12899D'),hextoraw ('543FC454084711DC87F900093D12899D'),hextoraw ('543FC47B084711DC87F900093D12899D'),hextoraw ('54F4C80DBDBE11E58C245EF3FCE0557F'),hextoraw ('5A7D2B55084711DC87F900093D12899D'),hextoraw ('5A7D2BA6084711DC87F900093D12899D'),hextoraw ('5A7D2C48084711DC87F900093D12899D'),hextoraw ('5A7D2CA0084711DC87F900093D12899D'),hextoraw ('5E3A5C91F9AF11E29C6A5EF3FCE0557F'),hextoraw ('5E3A5CADF9AF11E29C6A5EF3FCE0557F'),hextoraw ('6146DA39683911DF84D70021281A0D5A'),hextoraw ('6F3C932D1BFB11E68C245EF3FCE0557F'),hextoraw ('7318B7C068CE11E48EC45EF3FCE0557F'),hextoraw ('741C27CDF62611E089AA0021281A0D5A'),hextoraw ('7A3F38AB5B2911E39F3C5EF3FCE053DF'),hextoraw ('7C8BA6286D8911E0BB430021281A0D5A'),hextoraw ('7D7FE79A82C211DF91940021281A0D5A'),hextoraw ('7F4B92F2757E11DDB108003048579853'),hextoraw ('839EC56B922511E2B8F15EF3FCE053DF'),hextoraw ('8F652E03AB0411DFAC200021281A0D5A'),hextoraw ('983FA66A585011DFADA90021281A0D5A'),hextoraw ('99D8843D791911E48EC45EF3FCE0557F'),hextoraw ('A1B27F4E173C11E68C245EF3FCE0557F'),hextoraw ('A405C9A457AC11E69BDD5EF3FCE0557F'),hextoraw ('A73363A7069C11DFA8B0003048579853'),hextoraw ('AA3773A13F9911E39F3C5EF3FCE053DF'),hextoraw ('AE976F29241C11E39C6A5EF3FCE0557F'),hextoraw ('AEFF6D63309F11E3888C5EF3FCE053DF'),hextoraw ('B270F494215A11E58A1D5EF3FCE0557F'),hextoraw ('B821C3BFFD6111E4A0D05EF3FCE0557F'),hextoraw ('BC4F5968345F11E69BDD5EF3FCE0557F'),hextoraw ('BE3B82C419E111E39C6A5EF3FCE0557F'),hextoraw ('C37535F862CA11E19D080021281A0D5A'),hextoraw ('C379587E303111DC8F9600093D12899D'),hextoraw ('C3795880303111DC8F9600093D12899D'),hextoraw ('C422809AF49311E4A0D05EF3FCE0557F'),hextoraw ('C5150CC574BE11E6840B5EF3FCE0557F'),hextoraw ('C6E2337EC48C11E397885EF3FCE0557F'),hextoraw ('CB1C1A6993A911E397885EF3FCE0557F'),hextoraw ('CB927BBADA8811E397885EF3FCE0557F'),hextoraw ('CBBD8672615911E0BBBD0021281A0D5A'),hextoraw ('CC64F93734C111E39C6A5EF3FCE0557F'),hextoraw ('D3DE22B034A611E39C6A5EF3FCE0557F'),hextoraw ('D5550E6EF52E11E29C6A5EF3FCE0557F'),hextoraw ('E4BAD57C2CBC11DD992A00093D12899D'),hextoraw ('E5254BC4FA9E11E388785EF3FCE0557F'),hextoraw ('F2150B1614B311E58A1D5EF3FCE0557F'),hextoraw ('FD8CCD661E5911E58A1D5EF3FCE0557F'),hextoraw ('FEA5B5C14A1511DE914B003048579853'))

select o.ID_OP, o.OPNUMBER, o.OPDATE, a.CODE as "��� ��", a.NAME as "������������", oa.QUANTITY as "����������", oa.OPSUM as "�����" from whs.op_art oa 
join whs.article a on a.ID_ART = oa.id_art
join whs.operation o on o.ID_OP = oa.ID_OP
where oa.ID_OP in 
(
select op.ID_OP from whs.operation op where op.OPNUMBER in ('230114RA000001', '660554RA000001', '660554RA000002', '660554RA000003', '660554RA000004', '660554RA000005', '743055RA000001', '524626RA000001', '560197RA000001', '153355RA000001', '644708RA000002', '670101RA000001', '230741RA000001', '230704RA000002', '703033RA000001', '703033RA000002', '610202RA000001', '760013RA000001')  and op.ID_TOP = 64
)
order by o.ID_OP


select oa.ID_OP, a.ID_ART, a.CODE, a.NAME, oa.QUANTITY, oa.OPSUM, WHS.ALCART_PKG.ART_IS_ALCDECLARING(oa.ID_ART, SYSDATE) AS DECLARING, WHS.ALCART_PKG.ART_IS_ALCLICENSING(oa.ID_ART, SYSDATE) AS LICENSING from whs.op_art oa
join whs.article a on a.ID_ART = oa.ID_ART
where oa.ID_OP in (-1265307250,-1265286131,-1265268725,-1265174694,-1264565746,-1264210766,-1264076398,-1264062989,-1263571259,-1263257673,-1263209056,-1263204247,-1263157205,-1263127493,-1263073862,-1262287101,-1262202498,-1262138562,-1262110500,-1261098118,-1260987336,-1260008842,-1259818068,-1259813068,-1258799197,-1258583270,-1258582818,-1258582229,-1257710327,-1257630398,-1256581587,-1256435567,-1255527447,-1255447868,-1253328117,-1252152486,-1251057679,-1250906247,-1242169619)
order by oa.ID_OP

select * from whs.art_moreinfo
select * from whs.addition
SELECT 
WHS.ALCART_PKG.ART_IS_ALCDECLARING(503599, SYSDATE) AS DECLARING, 
WHS.ALCART_PKG.ART_IS_ALCLICENSING(503599, SYSDATE) AS LICENSING
FROM DUAL;

select * form whs.doc_op do where do.id_op = 

select do.id_op, count (ddo.id_document)--, d.id_document, count (d.id_document) 
from whs.doc_op do
join whs.document ddo on ddo.id_doctype = 482 and ddo.id_document = do.id_document and (ddo.isdeleted = 0 OR ddo.isdeleted is null)
join  whs.docreference dr on dr.id_doc_master = ddo.id_document
join whs.document d on d.id_document = dr.id_doc_depend and d.id_doctype = 480
where do.id_op in ('-1214169696','-1256503530','-1151370013','-1152391964','-1151289125','-1152625186','-1153460241','-1152570641','-1150581717','-1154481232','-1151536828','-1153599586','-1154551524','-1155565926','-1154695305','-1196672594') 
group by do.id_op--, d.id_document


select do.id_op, ddo.id_document, count (d.id_document), op.OPNUMBER, wh.code, wh.name
from whs.doc_op do
join whs.operation op on op.ID_OP = do.id_op
join whs.warehouse wh on wh.id_ws = nvl (op.id_wsi, op.id_wso)
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
join whs.document ddo on ddo.id_doctype = 482 and ddo.id_document = do.id_document and (ddo.isdeleted = 0 OR ddo.isdeleted is null)
join  whs.docreference dr on dr.id_doc_master = ddo.id_document
join whs.document d on d.id_document = dr.id_doc_depend and d.id_doctype = 480-- and (d.isdeleted = 0 OR d.isdeleted is null)
where do.id_op in (-1154551524,-1152625186) 
group by do.id_op, ddo.id_document, wh.code, wh.name, op.OPNUMBER, s.id_document


-- ����� ������������ ����������
 SELECT do.id_op, op.OPNUMBER, op.ID_TOP, s.id_send_status, doc.id_document, doc.id_doctype, dmaster.id_document as dmaster, dmaster.id_doctype, dmaster.isdeleted
FROM whs.DOCUMENT doc
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
left join whs.docreference dr on dr.id_doc_depend = doc.id_document
left join whs.document dmaster on dmaster.id_document = dr.id_doc_master --and (dmaster.isdeleted is null or dmaster.isdeleted = 0)
left join whs.doc_op do on do.id_document = dmaster.id_document
left join whs.operation op on op.ID_OP = do.id_op
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = do.id_op
WHERE 
/*doc.id_document = 
433173058 - ��������� ����� �������������
773363A1614 - ������� ����� ��������
773363A1614/1 - �� ���� ������� ��������
����� ��������, ������������ � ��������� ������ <tc:OperationComment>��������� �773363A1614/1 �� 04.10.2016 00:00:00 ������������</tc:OperationComment>*/
df.filename like ('DFD80A3C6BAA4013A45798F99E7E9052%')





select do.id_op, d481.id_document as "481", count (ddo.id_document) as "���-�� 482 � 481", ddo.id_document as "482", d.id_document as "480", d.id_doctype, count (d.id_document) as "���-�� 480 � 482"
select d481.id_document, d481.lastdate, ddo.id_document, ddo.lastdate, d.id_document, d.lastdate
from whs.doc_op do
join whs.document d481 on d481.id_doctype = 481 and d481.id_document = do.id_document
left join whs.docreference dr481 on dr481.id_doc_master = d481.id_document
join whs.document ddo on ddo.id_doctype = 482 and ddo.id_document = dr481.id_doc_depend
join  whs.docreference dr on dr.id_doc_master = ddo.id_document
join whs.document d on d.id_document = dr.id_doc_depend and d.id_doctype = 480
where do.id_op in (-1233887583)--(-1241112067,-1262073443,-1215082297,-1241488230,-1219185634,-1254297950,-1236793628,-1223559101,-1263175533,-1227765337,-1255837666,-1257348729,-1217122273,-1232545414,-1255066152,-1239049702,-1234635290,-1248723841,-1259773326,-1233883673,-1247724271,-1252008760,-1211141907,-1230015448,-1210783011,-1250900025,-1251546901,-1249758395,-1249893655,-1221396432,-1247067641,-1243161472,-1258299212,-1260937427,-1203686603,-1219212291,-1254161569,-1225591975,-1212895362,-1246752287,-1226682989,-1260618138,-1253174244,-1245425322) 
group by do.id_op, d481.id_document ,ddo.id_document, d.id_document, d.id_doctype


select *  from doc_egais.send_doc_egais_tbl   
where id_send_base in (-1250095693)
---��� 7-��. ������� ������ 18 ������


-- �������� � �2 �� ������� �� �������� � �1
select rm.reg_id_b, rm.alc_code, rm.move_type, sum (rm.quantity) --de.id_document, de.fsrar_id, tsh.identity, ts.reg_id_b, rm.* 
from doc_egais.transferfs_doc_content_tbl ts 
left join retail.registr_tbl rm on rm.reg_id_b = ts.reg_id_b
join doc_egais.transferfs_doc_header_tbl tsh on tsh.id_document = ts.id_document
join doc_egais.document_tbl de on de.id_document = ts.id_document
where ts.id_document = 463439257
and ts.alc_code in ('0031518000001288050', '0032688000001237535', '0037316000001467766', '0323105000003441443', '0323105000003441445') and rm.wscode = '230218'
group by rm.reg_id_b, rm.alc_code, rm.move_type
-- ������ move_type = P
FB-000000516387550
FB-000000516387558
FB-000000516387588
FB-000000516387589
FB-000000516387578



with id_arft as ( select art.code, art.id_art, rtdt.quantity, wh.code as wscode from whs.redistribution_task_detail_tbl rtdt left join whs.article art on art.id_art = rtdt.id_art join whs.redistribution_task_tbl rtt on rtt.id_task = rtdt.id_task left join whs.warehouse wh on wh.id_ws = rtt.id_ws_from where rtdt.id_task = 8050) , arts as (select distinct a.id_art                  ,a.NAME                  ,a.code art_code                  ,ap.alc_code                  , ia.wscode                  , ia.quantity as quantitytask     from id_arft ia     join whs.article a on a.ID_ART = ia.id_art     join whs.article_kiscontr_link akl on a.id_art = akl.id_article     join onsi_egais.alc_prod_prov_link_tbl ppl on akl.id_article_kiscontr_link = ppl.id_article_kiscontr_link                                               and ppl.is_deleted != 1     join onsi_egais.alc_org_link_tbl aol on ppl.id_alc_org_link = aol.id_alc_org_link                                         and aol.isdeleted != 1    join onsi_egais.alc_product_tbl ap on aol.id_alc_product = ap.id_alc_product    join id_arft on a.id_art = id_arft.id_art ) , rest_vw as ( select  vw.wscode , vw.alc_code , sum (vw.quantity) as quantity from arts a join RETAIL.Registr_Rest_Vw vw on vw.wscode = a.wscode and vw.alc_code = a.alc_code where vw.rest_type in ('1','2','5') group by vw.wscode, vw.alc_code ) , rest_artcode as (select arts.art_code       ,sum (rest_vw.quantity) as quantity   from arts   left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code   group by arts.art_code ) , reserv as (select r.reg_id_b      ,sum (bron.quantity) as quantity   from retail.registr_tbl r   left join whs.redistrib_task_doc_content_tbl bron on bron.reg_id_b = r.reg_id_b    where r.alc_code in (select alc_code                         from arts)          and bron.used = '1'   group by r.reg_id_b ) , egais as ( select distinct        rc.quantity qeg        ,rtdt.quantity         , kl.code_egais         , kl.id_article    from whs.redistribution_task_detail_tbl rtdt   join WHS.ARTICLE_KISCONTR_LINK kl on kl.id_article = rtdt.id_art    join doc_egais.product_tbl pt on pt.alc_code = kl.code_egais    left join doc_egais.replyrestshop_doc_content_tbl rc on rc.id_product = pt.id_product and rc.id_document = 423433531   where rtdt.id_task = 8050 and rc.quantity is not null ) select distinct case when r.reg_id_b is null then '������� �����������'        when (rest_vw.quantity - nvl (reserv.quantity,0)) >= arts.quantitytask then '����������'        else '�� �������' end as "��������  �� ��� ����"       , case when (rest_artcode.quantity - nvl (reserv.quantity,0))>= arts.quantitytask then '����������'        else '�� �������' end as "�������� �� ���� ��"       ,arts.art_code as "��� ������"       ,arts.alc_code as "��� ���"       , (rest_vw.quantity - nvl (reserv.quantity,0)) as "������� � ����� �������� �2"       ,arts.quantitytask as "���������� � �������"       ,nvl (r2.quantity,0) - nvl(rm.quantity, 0) as "�������� �� ������� �"       ,reserv.quantity as "����� �� ������� �"       ,r.reg_id_b as "����� ������� �"       ,egais.qeg as "�� �����"   from retail.registr_tbl r   left join retail.registr_tbl r2 on r2.id_registr = r.id_registr and r2.reg_id_b is not null   left join arts on r.alc_code = arts.alc_code   left join egais on egais.code_egais = r.alc_code   left join rest_artcode on rest_artcode.art_code = arts.art_code   left join retail.registr_tbl rm on rm.move_type = 'M'                                  and r.wscode = arts.wscode                                  and r.reg_id_b = rm.reg_id_b   left join rest_vw on rest_vw.wscode = arts.wscode and rest_vw.alc_code = arts.alc_code   left join reserv on reserv.reg_id_b = r.reg_id_b   where r.move_type = 'P'    and r.wscode = arts.wscode     and r.alc_code in (select alc_code from arts) 



-- ������� ���� ������� ������������ ��������
select orf.id_op as �����,  dh.actdate as "���� Insert ������ � ����", s.*
from whs.opreference orf
join whs.operation op on op.id_op = orf.id_opref and op.ID_TOP = 169 --169 ���� ������
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
join whs.document_history dh on dh.id_document=s.id_ticket and dh.action = 'I'
where orf.id_op in (-1231231284,-1232430463,-1236961694,-1237865133,-1239369958,-1240235550,-1239371422,-1240476210,-1241471841,-1243555530,-1243555163,-1244704856,-1244562452,-1249840868,-1249867163,-1249840768,-1249760950,-1249197933,-1249768253,-1249824698,-1250938110,-1250964027,-1250934193,-1250963763,-1250963762,-1250903754,-1250709959,-1250708547,-1250961091,-1250516585,-1250588726,-1251171553,-1251207984,-1251229874,-1250938673,-1250588659,-1251510370,-1252018771,-1251865886,-1251541107,-1251652444,-1251531965,-1252001855,-1252373519,-1252019111,-1251645905,-1251510384,-1252340453,-1253058943,-1252579315,-1252579315,-1252739759,-1253153636,-1253094219,-1252954019,-1252679324,-1252512521,-1252906951,-1253154456,-1253099341,-1252588103,-1253192536,-1252768590,-1253204063,-1253221373,-1253427526,-1253673640,-1253803311,-1254258651,-1254223596,-1254224806,-1254290619,-1254286580,-1254364898,-1254223609,-1254296644,-1254357708,-1254506695,-1253650500,-1253950283,-1254494518,-1254622474,-1254893674,-1255389256,-1255250930,-1255585558,-1254851243,-1255495133,-1254892047,-1255909466,-1256435396,-1256468429,-1256287707,-1256239317,-1265571370,-1265610940,-1265610627,-1267060383,-1267060346,-1268283285,-1268283272,-1268333549,-1268219370,-1268308085,-1269187849,-1269187834,-1269480436,-1268645995,-1269006641,-1270387339,-1270524971,-1270479318,-1271271574,-1271400080,-1271496733,-1271263537,-1270514209,-1271496808,-1272604251,-1272604237,-1272653579,-1272535185,-1272244989,-1272114402,-1272330709,-1273577358,-1273711556,-1273698655,-1273698568,-1273711569,-1273852024,-1273851991,-1273576101,-1273459611,-1273459205,-1273674785,-1274780475,-1274780465,-1274837011,-1274836942,-1274707876,-1274787725,-1274640449,-1274440103,-1274471439,-1273569738,-1274473217,-1275895853,-1275895827,-1275837528,-1274627485,-1275444624,-1275582390,-1275142630,-1275563815,-1276077419,-1274739839,-1274617129,-1275778385,-1275559328,-1275401946,-1275882627,-1275875236,-1276098842,-1277092015,-1277092005,-1277284803,-1277284783,-1276963210,-1277024318,-1276034923,-1276888787,-1276782163,-1275666402,-1276781265,-1276640581,-1276260883,-1276244655,-1276714557,-1276710104,-1276704701,-1277224592,-1276028028,-1276023922,-1276661371,-1276975587,-1278017120,-1278034970,-1278073413,-1276893663,-1276821933,-1277852286,-1277541830,-1277922971,-1277869311,-1278006893,-1278099570,-1277186150,-1277791710,-1277970456,-1277969941,-1277970392,-1277970013,-1278003711,-1278003984,-1278003553,-1279225720,-1277964403,-1277941742,-1278125290,-1278647576,-1279168008,-1279084691,-1278984931,-1279031745,-1279031522,-1278852632,-1278834890,-1278285940,-1278066521,-1279024526,-1279052590,-1280235471,-1280386944,-1280386907,-1279151598,-1279247655,-1280040110,-1280321850,-1280321817,-1280321788,-1280336062,-1279509631,-1280114372,-1280431276,-1280352021,-1280455546,-1279534533,-1279607277,-1280072370,-1280501515,-1280114557,-1280325877,-1280114221,-1280047202,-1279366252,-1280463268,-1279453091,-1280442401,-1280331304,-1280476954,-1280452712,-1279945089,-1280319233)


-- �������� ����� API �� id_op
select regexp_replace(l.chdata, '(-\d{8,10});.+', '\1') from doc_egais.log_action_support l 
join whs.operation op on op.id_op = regexp_replace(l.chdata, '(-\d{8,10});.+', '\1')-- l.chdata
where op.id_op in (-1231231284,-1236961694,-1239371422,-1239369958,-1240235550,-1240476210,-1241471841,-1243555530,-1243555163,-1244562452,-1244704856,-1252340453,-1252579315,-1252579315,-1265571370,-1265610940,-1265610627,-1267060346,-1267060383,-1268219370,-1268308085,-1268283272,-1268283285,-1268333549,-1269187849,-1269187834,-1269480436,-1270387339,-1270479318,-1270514209,-1270524971,-1271263537,-1271271574,-1271400080,-1271496733,-1271496808,-1272114402,-1272244989,-1272330709,-1272535185,-1272604251,-1272604237,-1272653579,-1273459611,-1273459205,-1273576101,-1273569738,-1273577358,-1273674785,-1273698568,-1273711556,-1273698655,-1273711569,-1273851991,-1273852024,-1274440103,-1274471439,-1274473217,-1274627485,-1274640449,-1274617129,-1274707876,-1274739839,-1274787725,-1274780465,-1274780475,-1274837011,-1274836942,-1275142630,-1275401946,-1275444624,-1275559328,-1275563815,-1275582390,-1275666402,-1275778385,-1275837528,-1275882627,-1275875236,-1275895827,-1275895853,-1276098842,-1276028028,-1276023922,-1276034923,-1276077419,-1276260883,-1276244655,-1276640581,-1276661371,-1276704701,-1276710104,-1276714557,-1276781265,-1276782163,-1276821933,-1276888787,-1276893663,-1276963210,-1276975587,-1277024318,-1277092005,-1277224592,-1277092015,-1277186150,-1277541830,-1277284803,-1277284783,-1277791710,-1277852286,-1277869311,-1277922971,-1277941742,-1277964403,-1277969941,-1277970013,-1277970456,-1277970392,-1278003711,-1278003553,-1278003984,-1278006893,-1278034970,-1278017120,-1278066521,-1278073413,-1278099570,-1278125290,-1278285940,-1278647576,-1278834890,-1278852632,-1278984931,-1279024526,-1279031522,-1279031745,-1279052590,-1279084691,-1279151598,-1279168008,-1279225720,-1279247655,-1279366252,-1279453091,-1279509631,-1279534533,-1279607277,-1279945089,-1280040110,-1280047202,-1280072370,-1280114557,-1280114221,-1280114372,-1280319233,-1280336062,-1280331304,-1280325877,-1280352021,-1280235471,-1280321788,-1280321850,-1280321817,-1280386944,-1280386907)

-- ���� API
select * from doc_egais.log_action_support l
where l.chdata like '%3047902%' OR l.chdata like '%2185907%'

with op as (
select op.ID_OP 
from whs.operation op where op.id_op in (-1231230991,-1236961492,-1239371404,-1239369680,-1240234111,-1240472154,-1241467378,-1243553859,-1243553638,-1244559958,-1244703783,-1252339721,-1252575582,-1252575582,-1265570652,-1265609565,-1265609438,-1267060343,-1267060374,-1268219368,-1268308083,-1268283271,-1268283283,-1268333548,-1269187846,-1269187831,-1269480434,-1270387338,-1270478432,-1270512246,-1270524969,-1271262784,-1271269371,-1271398726,-1271494558,-1271494639,-1272111795,-1272243127,-1272328186,-1272533699,-1272604250,-1272604235,-1272653578,-1273459270,-1273458887,-1273575073,-1273568614,-1273577356,-1273665129,-1273698565,-1273711555,-1273698653,-1273711566,-1273851985,-1273852019,-1274437821,-1274470745,-1274471890,-1274616327,-1274617646,-1274616934,-1274707543,-1274737900,-1274782684,-1274780463,-1274780473,-1274837006,-1274836935,-1275125756,-1275395694,-1275439909,-1275559192,-1275561764,-1275579603,-1275665289,-1275777822,-1275837376,-1275876874,-1275869526,-1275895822,-1275895850,-1276015754,-1276016468,-1276010920,-1276029402,-1276071935,-1276254850,-1276242349,-1276635304,-1276659541,-1276704118,-1276708940,-1276712647,-1276778492,-1276780062,-1276820616,-1276886889,-1276893047,-1276933956,-1276952108,-1277021718,-1277092001,-1277154404,-1277092014,-1277156332,-1277394788,-1277284796,-1277284779,-1277697655,-1277850060,-1277866767,-1277922235,-1277941352,-1277963724,-1277968146,-1277968219,-1277968586,-1277968497,-1278001710,-1278001240,-1278001848,-1278006206,-1278033554,-1278017118,-1278065822,-1278071632,-1278096815,-1278122626,-1278281814,-1278605339,-1278807171,-1278821361,-1278983425,-1279022252,-1279029281,-1279031318,-1279049954,-1279082862,-1279149612,-1279167039,-1279224468,-1279244249,-1279363246,-1279446230,-1279506808,-1279526221,-1279594616,-1279944943,-1280037163,-1280046860,-1280069726,-1280114090,-1280113324,-1280113446,-1280317748,-1280331195,-1280325883,-1280321220,-1280342547,-1280235466,-1280321786,-1280321846,-1280321813,-1280386941,-1280386905,-1280464853,-1280431274,-1280455545,-1280501514,-1250960349,-1249760367,-1251863780,-1253424332,-1254255739,-1254224587,-1252947836,-1254357191,-1254504179,-1255233462,-1252000396,-1253098975,-1249839718,-1253220678,-1252897537,-1254837754,-1252268625,-1253151969,-1254293654,-1251516894,-1254885046,-1250933111,-1251169450,-1251639871,-1253092833,-1252581012,-1251508913,-1252737612,-1253201874,-1255386931,-1251229522,-1253645822,-1256466787,-1253669735,-1269004029,-1253044728,-1254363925,-1256220432,-1237864667,-1250580583,-1252760488,-1232425811,-1250700009,-1254618653,-1254492538,-1250938156,-1250903197,-1253153734,-1250936584,-1251508892,-1253948015,-1255898271,-1256433113,-1250707362,-1252018161,-1252668843,-1253192074,-1254285079,-1268634624,-1249822577,-1253802516,-1254222198,-1255585074,-1256286236,-1250963215,-1250580560,-1249193343,-1250963320,-1250515031,-1249766701,-1252018246,-1254222200,-1254879550,-1251206767,-1250963208,-1251539374,-1254287641,-1249839529,-1249866482,-1255493872,-1251649655,-1280454490,-1252512136,-1280441228,-1280449354)
)
, logs as (
select * from doc_egais.log_action_support l
join op on op.id_op is not null
where l.chdata like ('%'||op.id_op|| '%')
)
select * from logs

select * from doc_egais.log_action_type




, cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment"
, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment"
, pp.tasknumber
, pp.taskdate
, pp.id_transfer_task
, pp.perenos_status as "������ ��������"
, pp.V as "�������"
, pp.excl as "� �����������"
from perenos pp
left join whs.document d on d.id_document = pp.id_document
left join doc_egais.send_doc_egais_tbl ww on ww.id_send_base = pp.id_op
left join whs.docreference df on df.id_doc_master = ww.id_document
--  left join whs.document wd
--   on wd.id_document = ww.id_document
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
--left join doc_egais.TICKET_DOC_HEADER_TBL yy on yy.id_document= ww.id_ticket
left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
    
    
    
with s1 as ( select wh.code, op.id_top, op.opnumber, stt.id_send_type,stt.name as base_name,
st.id_send,st.add_date,st.last_work_date,st.send_date, st.id_send_base, st.id_send_status, 
st.id_document, st.id_doctype, st.description, cast (tdr.comments as varchar(4000)) as comments_ticket2, 
cast (tdo.operation_comment as varchar(4000)) as operation_comment_ticket2, td1.id_document as id_document_ticket1, 
cast (tdr1.comments as varchar(4000)) as comments_ticket1, cast (tdo1.operation_comment as varchar(4000)) as operation_comment_ticket1 
from doc_egais.send_doc_egais_tbl st 
join doc_egais.send_doc_type_egais_tbl stt on stt.id_send_type = st.id_send_type 
join whs.operation op on op.id_op = st.id_send_base 
join whs.warehouse wh on wh.id_ws=op.ID_WSI 
left join doc_egais.ticket_doc_header_tbl  td on td.id_document = st.id_ticket 
left join doc_egais.ticket_doc_result_tbl  tdr on td.id_ticket_doc_result=tdr.id_ticket_doc_result 
left join doc_egais.ticket_doc_opresult_tbl  tdo on td.id_ticket_doc_opresult = tdo.id_ticket_doc_opresult 
left join doc_egais.ticket_doc_header_tbl  td1 on td1.id_document = st.id_ticket1 
left join doc_egais.ticket_doc_result_tbl  tdr1 on td1.id_ticket_doc_result=tdr1.id_ticket_doc_result 
left join doc_egais.ticket_doc_opresult_tbl  tdo1 on td1.id_ticket_doc_opresult =  tdo1.id_ticket_doc_opresult  
where st.id_send_base =-1265610627 ),
comments1 as (
select s1.id_document
, cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) as O_Comment
from s1 left join whs.docreference df on df.id_doc_master = s1.id_document 
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
join doc_egais.ticket_doc_opresult_tbl t0 on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
)
, comments2 as
(
select s1.id_document
, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) D_Comment 
from s1 left join whs.docreference df on df.id_doc_master = s1.id_document 
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
join doc_egais.ticket_doc_result_tbl t1 on t1.id_ticket_doc_result = th.id_ticket_doc_result
)
select distinct s1.*, c1.O_Comment, c2.D_Comment from s1 
left join comments1 c1 on c1.id_document = s1.id_document
left join comments2 c2 on c2.id_document = s1.id_document


select  *
--cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) as O_Comment
--, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) D_Comment 
from whs.docreference df  
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
left join doc_egais.ticket_doc_opresult_tbl t0 on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
--left join doc_egais.ticket_doc_result_tbl t1 on t1.id_ticket_doc_result = th.id_ticket_doc_result
where df.id_doc_master = 284831332    




select d.* from 
whs.operation op
join whs.doc_op dop on dop.id_op = op.id_op
join whs.document d on d.id_document = dop.id_document
where op.id_op = -1260319900

select d2.* from whs.document d
join whs.docreference dr on dr.id_doc_master = d.id_document
join whs.document d2 on d2.id_document = dr.id_doc_depend
where d.id_document = 456165743


select doc483.id_document as d483document,doc483.isdeleted as d483deleted,d481.id_document,d481.isdeleted from whs.doc_op do
join whs.document d481 on d481.id_document = do.id_document and d481.id_doctype=481
left join whs.docreference docr on docr.id_doc_master=d481.id_document
join whs.document doc483 on doc483.id_document= docr.id_doc_depend and doc483.id_doctype=483
where do.id_op=-1260319900


select wdc.identity from whs.opreference opr
                            join whs.operation op on op.id_op = opr.id_opref and op.ID_TOP=169
                            join whs.doc_op do on do.id_op=op.ID_OP
                            join whs.document d on d.id_document=do.id_document and d.id_doctype=481 and (d.isdeleted=0 or d.isdeleted is null)
                            join doc_egais.waybill_doc_header_tbl wdc on wdc.id_document=d.id_document
                            where opr.id_op = 
                            
                            
select doc.id_document, doc.docnumber, doc.docdate, ca_oo.id_contr as consignee, ca_post.id_contr as shipper
                        , ca_post.fullname from whs.doc_op do join whs.operation op on do.id_op = op.id_op join whs.document doc on doc.id_document = do.id_document
                        and doc.id_doctype = 481 join whs.warehouse wrh on wrh.id_ws = op.id_wsi join whs.contractor ca_oo on ca_oo.id_contr = wrh.id_controwner
                        join whs.contractor ca_post on ca_post.id_contr = op.id_contr where do.id_op =-1260319900
shipper 91188
consignee 857709                        
                        
select distinct  doc.id_document, doc.docnumber, doc.docdate, doc.isdeleted, c_ka.code as code_ka  ,ka.kpp as kpp2 
,ka.code  ,ool_ka.*, op.id_op, op.opnumber, op.opdate, op.opsum, op.typeop, sde.id_send_status, sde.id_document as id_document_sde 
, sde.id_doctype as id_doctype_sde, op.id_contr, do_ka.code as FSRARID_SHIPPER, do_oo.code as FSRARID_CONSIGNEE, op.opguid 
,dev.wb_reg_id 
from whs.document doc 
join doc_egais.waybill_doc_header_tbl wh on wh.id_document = doc.id_document 
join doc_egais.organization_tbl do_oo on do_oo.id_organization = wh.id_consignee join onsi_egais.organization_tbl oo on oo.code = do_oo.code 
join onsi_egais.org_kpp_link_tbl ool_oo on ool_oo.id_organization = oo.id_organization 
join whs.contractor c_oo on c_oo.inn = oo.inn 
                          and c_oo.kpp = oo.kpp and c_oo.id_contr = 857709 
join whs.group_contr gr_oo on gr_oo.id_grcontr = c_oo.id_grcontr and 
                          gr_oo.fullname like '���� ��%' 
join doc_egais.organization_tbl do_ka on do_ka.id_organization = wh.id_shipper 
join onsi_egais.organization_tbl ka on ka.code = do_ka.code 
join onsi_egais.org_kpp_link_tbl ool_ka on ool_ka.id_organization = ka.id_organization 
join whs.contractor c_ka on c_ka.inn = ka.inn 
                          and c_ka.id_contr = 91188 
left join whs.doc_op do on do.id_document = doc.id_document
left join whs.operation op on op.id_op = do.id_op 
left join doc_egais.send_doc_egais_tbl sde on sde.id_send_base = op.id_op
left join whs.docreference dref on dref.id_doc_master = doc.id_document 
left join whs.DOCUMENT doc483 on doc483.id_document = dref.id_doc_depend and doc483.id_doctype = 483 
join whs.docfileset dfs483 ON dfs483.id_document = doc483.id_document and doc483.id_document is not null 
left join whs.docfile df483 ON df483.id_dfs = dfs483.id_Dfs 
left join doc_Egais.Wbinformbreg_Doc_Header_Tbl dev on dev.id_document = doc483.id_document 
where (op.typeop <> 20 or op.id_op is null) and doc.docnumber = '456165743' and doc.id_doctype = 481                        


select * from doc_egais.waybill_doc_header_tbl where id_document = 456165743
661245019 - 661245019
668445010 - 668445016
shipper 141540437
consignee 351347198

select * from whs.contractor c_oo where c_oo.id_contr in (91188)

select * from doc_egais.organization_tbl o where o.id_organization = 141540437

update whs.operation set opdate = '' where opguid = hextoraw ('');
update whs.
commit;


select op.ID_TOP, op.ID_OP,op.OPDATE, ad.NAME, mo.* from whs.operation op
left join whs.op_moreinfo mo  on op.ID_OP = mo.id_op
join whs.addition ad on ad.ID_ADD = mo.id_add
where op.id_op in ('-1280703679','-1280704214','-1280704889','-1280705136')
order by mo.lastdate

select * from whs.addition ad where ad.ID_ADD = 667


select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1083718397



select * 
from doc_egais.send_doc_egais_tbl sd
join whs.operation op on op.id_op = sd.id_send_base 
where id_contr = 1158193 and id_top = 169
order by id_send_status;

select * from whs.contractor c where c.id_contr = 1158193



select d.id_doctype, dt.name, r.* --count(distinct id_document)
  from retail.registr_tbl r
  join whs.document d on d.id_document = r.id_document
  join whs.doctype dt on dt.id_doctype = d.id_doctype
where r.wscode = '610430'
   and r.id_document in (493352596,491771337,489511061,487909727,486857409,483270463,481711213,478353499,475575962,473149450,470696280,469948400,468605340,467400944,466285917,466285916,
463486629,463461246,461099769,459961238,457726385,457115980,455959335,453950421,452736055,452323090,451435376,451217567,448144513,447732847,446631237,444853326,
443683647,443498193,441826241,440660578,439506484,439082571,438284052,437352760,436292048,435843391,434672691,433544863,432198095,430396130,429235211,428168598,
427143152,426457384,424835391,423558999,423011299,421432340,421229033,419487434,416993813,416486817,414798741,413791112,412841133,411842740,410574811,410044055,
408526234,407550369,406340620,404018039) and r.move_type = 'P'

left join retail.registr_tbl rm on rm.reg_id_b = tc.reg_id_b and rm.move_type = 'M'

select * from doc_egais.send_doc_egais_tbl s where s.id_send_base in (-1177307753
,-1186892487
,-1175802204
)
-- ����� ����
select * from doc_egais.waybill_doc_header_tbl where id_document = 269744139
select * from doc_egais.waybill_doc_header_tbl wb where wb.identity = '1D0D74502F3B11E69477F8B1A0A0891E'

--�������� ��������
select opr.id_op as "�����", op.* from whs.opreference opr
join whs.operation op on op.ID_OP = opr.id_opref
where opr.id_op in (-1132039557
,-1184369138
,-1184408389
,-1184402316
,-1185561545
) -- �������� ��������

-- ���������� ������ �� � ��������
select sum (oa.QUANTITY) from whs.op_art oa
where oa.ID_OP = -1314344246
group by oa.ID_OP

-- �� � ��������
select oa.id_op, oa.id_art, a.code, a.name, oa.QUANTITY from whs.op_art oa
join whs.article a on a.id_art = oa.id_art
where oa.ID_OP in (-1444831540)


-- ���������� ������ �� � ��������
select sum (oa.QUANTITY) from whs.op_art oa
where oa.ID_OP = -1314344246
group by oa.ID_OP


-- ���������� ������ �� � ����
select p.full_name, p.capacity as "�����", p.alc_volume as "��������", wc.quantity as "���-�� � ����", p.alc_code as "��� �����"
--, a.CODE "��������� ��� �� ��", a.NAME "�������� ��������� �� ��"
 from 
whs.doc_op do
join doc_egais.waybill_doc_content_tbl wc on wc.id_document = do.id_document
join doc_egais.product_tbl p on p.id_product = wc.id_product
--join whs.article_kiscontr_link al on al.code_egais = p.alc_code
--join whs.article a on a.ID_ART = al.id_article
where do.id_op = -1444831540
order by p.alc_code

select * from whs.redistribution_task_detail_tbl rtd 
join whs.article a on a.ID_ART = rtd.id_art
where rtd.id_task = 34283

-- ���������� �� � ��������
select count (oa.ID_ART) from whs.op_art oa
where oa.ID_OP = -1314344246
group by oa.ID_OP

-- ���������� �� � ��������
select sum (oa.QUANTITY) from whs.op_art oa
where oa.ID_OP = -1314344246
group by oa.ID_OP


select s.last_work_date, s.id_send_status, op.*, s.* from whs.operation op 
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
where op.ID_OP in (-1315336550
,-1309033733
,-1330147126
)

select d.*, s.*, wh.* from whs.warehouse wh
join doc_egais.send_doc_egais_tbl s on s.ws_guid = wh.guid
join whs.document d on d.id_document = s.id_document
where wh.name = '������'
--and s.send_date >= '01.01.2017'
and s.id_send_status not in (11,12,41,61)


-- ��� ���� ���������� � ������� ���
select s.id_doctype,max(s.id_document)/*max(s.id_send)*/  from doc_egais.send_doc_egais_tbl s
--join whs.document d on d.id_document = s.id_document
where s.id_send_status = 8 --and d.docdate >= '01.01.2017'
group by s.id_doctype

select * from doc_egais.send_doc_egais_tbl where id_document in (496990102
,494972807
,496991486
,456057056
)

select * from whs.document d where d.id_document in (496750361
,485526556
,496712029
,207003756
,496749711
,496750815
,496696691
,496749295
,485566481
)
select * from whs.doctype dt where dt.id_doctype in (485
,507
,506
,484
,505
,514
,504
,482
,481
)

482	496750361
507	485526556
505	496712029
485	207003756
504	496749711
481	496750815
484	496696691
514	496749295
506	485566481



select * from doc_egais.transferts_doc_content_tbl t
join doc_egais.REPLYFORMB_DOC_HEADER_TBL re on re.reg_id = t.reg_id_b
join acan.analyticopart_tbl an on an.id_analyticopart = re.id_analyticopart
where t.id_document = 328346244
and t.alc_code in ('0378116000001244547','0037626000001233432','0036195000001238583','0032751000001248318','0037129000001235508','0036389000001234236','0035472000001237512')

select * from doc_egais.wbinformbreg_doc_content_tbl co where co.reg_id_b = 'FB-000000047598171'

--��������� �� ��������
select * from acan.analyticopart_tbl ana 
left join doc_egais.REPLYFORMB_DOC_HEADER_TBL re on re.id_analyticopart = ana.id_analyticopart
left join doc_egais.transferts_doc_content_tbl t on t.reg_id_b = re.reg_id
where ana.id_op = -982064709
and t.alc_code in ('0378116000001244547','0037626000001233432','0036195000001238583','0032751000001248318','0037129000001235508','0036389000001234236','0035472000001237512')


-- ������ �� ���. 483 �� id_op
SELECT art.code, art.id_art, wc.quantity, co.*, p.*, wc.* ,doc.id_document, 'file://///Esb-egais-01/egais/' || to_char(df.lastdate, 'dd-mm-yyyy') || '/' || df.filename
from whs.doc_op do 
join whs.docreference dref on dref.id_doc_master = do.id_document
JOIN whs.DOCUMENT doc on doc.id_document = dref.id_doc_depend
join doc_egais.wbinformbreg_doc_content_tbl co on co.id_document = doc.id_document
left join whs.document doc2 on doc2.id_document = dref.id_doc_master and doc2.id_doctype = 481
left join doc_egais.waybill_doc_content_tbl wc on wc.id_document = doc2.id_document and wc.id_position = co.id_position
left join doc_egais.product_tbl p on p.id_product = wc.id_product
left join whs.article_kiscontr_link al on al.code_egais = p.alc_code
join whs.article art on art.ID_ART = al.id_article
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE
do.id_op IN (-982064709) --id_op
and doc.id_doctype = 483
and p.alc_code in ('0378116000001244547','0037626000001233432','0036195000001238583','0032751000001248318','0037129000001235508','0036389000001234236','0035472000001237512')
order by doc.id_document desc

select * from whs.op_art oa 
where oa.ID_OP = -982064709
and oa.ID_ART in (120815,524860)


-- ������� �� ��
select op.id_op, ad.NAME, om.* from whs.operation op
left join whs.op_moreinfo om on om.id_op = op.ID_OP and om.id_add = 660
join whs.addition ad on ad.ID_ADD = om.id_add
where op.id_op in (-1328061678
,-1328113225
,-1330969833
,-1331982001
,-1330963086
,-1331974358
,-1330998398
,-1332206723
,-1330715328
,-1331940770
,-1332156108
,-1331960041
,-1332009564
,-1331983564
,-1331948491
,-1331918604
)

-- �������� � ������ �� � ��������
select opr.id_op, d.*, d3.*, do.*, op.*  from whs.opreference opr
join whs.operation op on op.ID_OP = opr.id_opref
left join whs.doc_op do on do.id_op = op.id_op
join whs.document d on d.id_document = do.id_document and d.id_doctype in (481,483)
left join whs.docreference dref on dref.id_doc_master = d.id_document
join whs.document d3 on d3.id_document = dref.id_doc_depend and d3.id_doctype = 483
where opr.id_op in (-1139524553
,-1146691079
,-1174841348
,-1133124605
,-1095477629
)

select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1136158031


select * from whs.operation op
--where op.opnumber in ('740656A1218/1', '784351��1201', '483633A1254/1', '777885TA0201')
where op.ID_OP = -1136363529

select * from doc_egais.send_doc_egais_tbl s where s.id_send_base in (-1175861275)(-1326182576
,-1324804359
,-1321377694
,-1332062658
)


-- ������ �������� � �� �������
begin
  doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 14113);
  doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 30482);
  doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 29901);
  doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 30266);
end;
14113
30482
29901
30266

select p.alc_code, r.quantity, r.*, p.* from doc_egais.replyrestshop_doc_content_tbl r 
left join doc_egais.product_tbl p on p.id_product = r.id_product
where r.id_document = 500653735
and alc_code in ()


select 
rt.ID_OP base
, rt.id_transfer_task_type btype
, rt.tasknumber bnumber
, rt.taskdate bdate
, s.add_date
, s.id_send_status
, s.id_document
, s.id_doctype
, s.last_work_date
, w.id_ws
,w.code
,w.lg1
,'transfer' as nature
,s.id_send_type 
, rt.*
from doc_egais.send_doc_egais_tbl s 
left join whs.warehouse w on w.guid=s.ws_guid 
left join doc_egais.reg_transfer_task_tbl rt on rt.id_transfer_task = s.id_send_base 
where s.id_send_base=-1139524553





-- ������� ������
with dat as (
select 
'483638' as mm_code -- ��� ��
,to_date ('01.01.2016') as date_start  -- ���� ��������� ������� ��������
,to_date (sysdate) as date_end  -- ���� ��������� ������� ��������
from dual
)
, prihod as (
-- �������� �� ���������� �� �����. ��������� ��������
select  distinct top.ID_TOP, top.FULLNAME, op.id_op, op.TYPEOP, op.opnumber, op.OPDATE, op.OPSUM, sdt.id_send_status--, omi.vbool as "������ �� ��"--, a.NAME, am.vstring
from whs.operation op
join whs.op_art oa on oa.ID_OP = op.id_op
join whs.article a on a.ID_ART = oa.ID_ART
join whs.art_moreinfo am on am.id_art = a.id_art
join whs.addition adi on adi.ID_ADD = am.id_add
join whs.op_moreinfo omi on omi.id_op = op.ID_OP
join whs.warehouse wh on wh.id_ws = op.ID_WSI
left join doc_egais.send_doc_egais_tbl sdt on sdt.id_send_base = op.ID_OP
join whs.typeop top on top.ID_TOP = op.ID_TOP
where wh.code = (select mm_code from dat)--(select distinct mm_code from rashod)
and op.OPDATE between trunc ((select date_start from dat),'DD') and trunc ((select date_end from dat),'DD')--to_date (sysdate)
and am.vstring not like '000' -- ���������� ��������������� ����
and adi.name like '���_���'
and /*sdt.id_send_status = 11--*/(sdt.id_send_status in (1,2,3,4,5,6,7,8,9,10) or sdt.id_send_status is null)
-- ������� �������� ������� �� �� ��� �� ����. ������
and (omi.id_add = 660 and (omi.vbool = 0 OR omi.vbool is null) and op.id_top = 1 
     OR op.id_top in (142,17,15,58,106)
     )
)
select * from prihod

select * from whs.operation where opnumber = '00000000201' and id_top = 15 and opdate >= '24.01.2017'
select * from doc_egais.send_doc_egais_tbl where id_send_base = -1348388602


select oa.id_art, sum (oa.QUANTITY)
from whs.op_art oa
where oa.ID_OP in (-1348388602
)
group by oa.ID_ART


select op.id_op, s.* from
whs.op_art oa
join whs.operation op on op.id_op = oa.id_op
join whs.warehouse wh on wh.id_ws = op.ID_WSI
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
where 
wh.code = '483638'
and oa.ID_ART in ('598871','428190','448070','413926','565605','433248','428696','591528','272515','579445','543084','613566','334137','432310','448582','274449','433247','421791','438839','570656','563635','437833','374449','376256','112717','157772','372127','274451','311743','374551','609661','614479','329267','673140','422554')


-- ������� 483
select * from doc_egais.wbinformbreg_doc_content_tbl wb
where wb.id_document = 500618776


doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>, p_id_send_type =>, p_id_document => ,p_description => );
select 'doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>'|| t.id_send_base ||',p_id_send_type =>'|| t.id_send_type ||', p_description => ''�� ������������ ���'');' as procedur  
select *  
from doc_egais.send_doc_egais_tbl t 
where t.id_send_base in (-1093663831
,-1093661794
,-1110424114
,-1108327287
,-1106541960
,-1104399495
,-1101942245
,-1100927572
,-1100010073
,-1097957006
,-1095862799
,-1093718074
,-1091949920
,-1089749507
,-1087629012
,-1085641092
,-1083582568
,-1081454411
,-1079327539
,-1077549071
,-1075351399
,-1073338564
,-1071051334
,-1065083380
,-1063459853
,-1061168150
,-1059022648
,-1052897572
,-1050833679
,-1097897757
,-1095724510
,-1092758012
)

begin
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1110424114,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1108327287,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1106541960,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1104399495,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1101942245,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1100927572,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1100010073,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1097957006,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1097897757,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1095862799,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1095724510,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1093718074,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1093663831,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1093661794,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1092758012,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1091949920,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1089749507,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1087629012,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1085641092,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1083582568,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1081454411,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1079327539,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1077549071,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1075351399,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1073338564,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1071051334,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1065083380,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1063459853,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1061168150,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1059022648,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1052897572,p_id_send_type =>1, p_description => '�� ������������ ���');
doc_egais.support_api.set_agreement_omu_status(p_id_send_base =>-1050833679,p_id_send_type =>1, p_description => '�� ������������ ���');
end;

select * from whs.doctype

select * from doc_egais.send_doc_egais_history_tbl sh where sh.id_send_base = -1095477629
ORDER BY ROWID 

select * from doc_egais.send_doc_type_egais_tbl

--�������� ������ �������� �� ���� ���������� ��
select wh.id_ws--, enwh.id_ws as idws_enable--wh.* ,DS.DATE_START date_open, DS.DATE_END date_close
from whs.warehouse wh
join WHS.DIVISION DIV on div.code = wh.code
JOIN ONSI_OUT.DIVISION_STORAGE_VW DS ON DIV.ID_DIV = DS.ID_DIV
LEFT JOIN WHS.STORAGE_TBL W ON W.ID_WS=DS.ID_WS
LEFT JOIN WHS.DIV_STATE  DS ON DS.ID_DIV=DIV.ID_DIV AND DS.ID_COND=11
left join doc_Egais.Reg_Transfer_Task_Enablews_Tbl enwh on enwh.id_ws = wh.id_ws --����������� � �������� ��
where wh.lg1 in (101,201)
--wh.code = '550028'
and ((DS.DATE_END >= (sysdate - 5)/* and DS.DATE_END <= (sysdate + 30)*/) OR DS.DATE_END is null)  and (DS.DATE_START < sysdate and DS.DATE_START is not null)


select * from whs.article a where a.code = '9787300001'
0150320000001186819 ����� ������� �� 40% 0,5� (������) :20	9787300001  22N00001543ZQO5BJER37ZK61111044845832HCSEKFIUAJ60A3CFYIIKIDJRHLFGR3H

select r2.move_type, d.id_doctype, count (d.id_document) from 
retail.registr_tbl r2
join whs.document d on d.id_document = r2.id_document
group by r2.move_type, d.id_doctype

-- ����� �������� � ����������� �� �� ����������� ��
select distinct  op.id_op, op.OPNUMBER, op.OPDATE, op.OPSUM, c.name, c.fullname
from whs.op_art oa
join whs.article a on a.ID_ART = oa.ID_ART
join whs.operation op on op.ID_OP = oa.ID_OP
join whs.warehouse wh on wh.id_ws = op.ID_WSI
join whs.contractor c on c.id_contr = op.ID_CONTR
where a.CODE in ('1000126030', '1000193849')
and op.ID_TOP = 15
--and c.name like '�����%'
and op.OPDATE > '20.01.2017'

select * from dba_users where username like '%ZAYCE_AA%';
select * from ROLE_ROLE_PRIVS R where R.ROLE like 'EGAIS%'
select * from ROLE_SYS_PRIVS R where R.ROLE like 'EGAIS%'
select * from user_sys_privs -- �� �������� ������������
select * from user_role_privs


with cod as
(
select r.id_art as art, r.fquant as faq from whs.rest r
where r.id_ws = 8861 and  r.fquant <> 0
)
summ as
(
select a.CODE, sum (r.fquant) from whs.rest r
join whs.article a on a.id_art= cod.art 
group by (a.CODE)

select a.code, sum (r.fquant) from whs.rest r
join whs.article a on a.id_art= r.id_art 
where r.id_ws = 8861 and  r.fquant <> 0
group by a.code


select a.code, sum (r.fquant) from whs.rest r
join whs.article a on a.id_art= r.id_art
join whs.art_moreinfo am on am.id_art = r.id_art
join whs.addition adi on adi.ID_ADD = am.id_add 
where r.id_ws = 8861 and  r.fquant <> 0 and am.vstring not like '000' -- ���������� ��������������� ����
and adi.name like '���_���'  
group by a.code

select a.code, r.* from whs.rest r
join whs.article a on a.ID_ART = r.id_art
where r.id_ws = 8861


/*
with op as (*/
select
wh.code, op.ID_OP, op.OPNUMBER, op.opdate
, (select max (ald.date_start) -- ����� ����� ��������
from whs.alc_license_division ald
join whs.division d on d.id_div=ald.id_div
join whs.contractor cc on cc.id_contr=d.id_contr
join whs.alc_license_state als on als.id_alc_license_state=ald.id_alc_license_state
where 
trim (cc.code )=wh.code
and als.state_name = '�����'
group by cc.code, d.name, als.state_name, als.is_deleted) as lic_end_date
, (-- ���� �� � �������� ������������� ��������
select distinct  aat.licensing  
from whs.article a
left join whs.op_art oa on oa.id_art = a.id_art
left join whs.operation ope on ope.id_op = oa.id_op
left join whs.art_moreinfo am on am.id_art=a.id_art
left join whs.addition addi on addi.id_add = am.id_add
left join whs.alc_art_type aat on aat.alc_art_code = am.vstring
where 
addi.name = '���_���' 
and ope.ID_OP = op.ID_OP
and aat.licensing=1 -- 0 ��� 1 
group by ope.id_op, aat.licensing) as licensing_buhlo
from
whs.operation op
join whs.warehouse wh on wh.id_ws = op.id_wsi
where op.id_op in (-1083720696
,-1143494524
,-1147394690
,-1157866789
,-1172770274
,-1173445845
,-1221821958
,-1221712952
,-1221775034
,-1222813711
,-1222813675
,-1222642130
,-1222871796
,-1222732666
,-1222721244
,-1223073277
,-1223073268
,-1222880733
,-1222880728
,-1223878035
,-1234986129
,-1234983704
,-1234892897
,-1234908428
,-1234983337
,-1234895564
,-1234907659
,-1236384295
,-1236384279
,-1236346852
,-1234872204
,-1237070170
,-1276860358
,-1281511073
,-1281449093
,-1281448638
,-1281448499
,-1281448452
,-1281492038
,-1281492026
,-1281524334
,-1281524323
,-1281366043
,-1281366022
,-1281632970
,-1281588162
,-1282736369
,-1282780374
,-1282779545
,-1282778843
,-1282596857
,-1282596703
,-1282612702
,-1282612689
,-1283671935
,-1283597688
,-1283597651
,-1283640612
,-1283717905
,-1283685718
,-1283766839
,-1283766563
,-1283915809
,-1284849464
,-1285020345
,-1285953212
,-1285953176
,-1285938984
,-1285946712
,-1285946707
,-1286004872
,-1286035010
,-1285995913
,-1285995903
,-1286079264
,-1286169580
,-1286169494
,-1286154902
,-1287226678
,-1288111440
,-1288539678
,-1288539652
,-1289268934
,-1289268911
,-1289209263
,-1290237368
,-1289442396
,-1290568668
,-1288137690
,-1288262303
,-1288262295
,-1289288339
,-1291587322
,-1280244281
,-1261077958
,-1294677992
,-1306773513
,-1317057259
,-1317023307
,-1290243239
,-1306937448
,-1306864212
,-1317057381
,-1317057351
,-1317018971
,-1309293341
,-1306752423
,-1314987424
,-1308932493
,-1174798425
,-1170785299
,-1330709087
,-1330732580
,-1330756997
,-1332003597
,-1306874641
,-1305867535
,-1306993980
,-1306977935
,-1317076478
,-1317057285
,-1317027498
,-1317023268
,-1334387184
,-1339545972
,-1339448025
,-1339426450
,-1339545932
,-1339545981
,-1340715481
,-1340554756
,-1340662206
,-1340969950
,-1340796697
,-1340662300
,-1340620605
,-1340609501
,-1342004681
,-1341917447
,-1341878371
,-1341798176
,-1341753060
,-1341729412
,-1341729389
,-1341620894
,-1341735998
,-1341706514
,-1341693956
,-1341587659
,-1342191488
,-1342191231
,-1342136303
,-1341536073
,-1342004802
,-1341891130
,-1341536131
,-1341917496
,-1341621309
,-1341621345
,-1342958221
,-1343078614
,-1343037350
,-1342655601
,-1344103306
,-1344087247
,-1344103315
,-1344103298
,-1344087127
,-1330817257
,-1338365036
,-1338365029
,-1174840671
)
/*)
, lic as (
)*/


select * from whs.doctype d where d.id_doctype = 491--d.id_document = 453118970

select * from whs.document d where d.id_document = 462340873

select ac.*, p.*, art.*--a.oo_code, ac.id_document, sum (ac.quantity) as quantity 
from
doc_egais.actchrgonshop_doc_content_tbl   ac
join doc_egais.product_tbl p on p.id_product = ac.id_product
join whs.article art on art.ID_ART = ac.id_art --�� ������������
where ac.id_document = 462340873
-- group by a.oo_code, ac.id_document

select * from doc_egais.send_doc_egais_tbl s where s.id_document = 462340873




select op.opnumber "����� ��������", op.opdate "����", op.opsum "�����", r2.art_code "��� ������", a.name,r2.alc_code "��� �����",r2.reg_id_b "� �� �2", r2.move_type, r2.quantity "���-�� �� �2", 
d.id_doctype "���", op.id_op, d.id_document "d482", d.id_send_status "������ ��.", d.id_ticket, de.id_send "���� ��������", de.id_doctype "���", de.id_document "d504", 
de.id_send_status "������ ��������", de.id_ticket, tdo1.operation_comment "����� ��������", tdo.operation_comment "����� ��������" 
from whs.operation op
join doc_egais.send_doc_egais_tbl d on d.id_send_base = op.id_op --and op.id_top = 10
left join doc_Egais.Reg_Transfer_Task_Tbl p on d.id_send_base = p.id_op
left join doc_egais.ticket_doc_header_tbl  td1 on td1.id_document = d.id_ticket
left join doc_egais.ticket_doc_result_tbl  tdr1 on td1.id_ticket_doc_result=tdr1.id_ticket_doc_result
left join doc_egais.ticket_doc_opresult_tbl  tdo1 on td1.id_ticket_doc_opresult = tdo1.id_ticket_doc_opresult
join doc_egais.send_doc_egais_tbl de on de.id_send_base = p.id_transfer_task
join retail.registr_tbl r2 on r2.id_document = de.id_document
left join whs.article a on a.code = r2.art_code
left join doc_egais.ticket_doc_header_tbl  td on td.id_document = de.id_ticket
left join doc_egais.ticket_doc_result_tbl  tdr on td.id_ticket_doc_result=tdr.id_ticket_doc_result
left join doc_egais.ticket_doc_opresult_tbl  tdo on td.id_ticket_doc_opresult = tdo.id_ticket_doc_opresult
where op.opnumber = '236111A2571'
and op.ID_TOP in (1,17)

select * from doc_egais.send_doc_egais_tbl s where s.id_send_base in (-1185561545
,-1184369138
,-1132039557
)



--��������� �������� � �2 
select * from
retail.registr_tbl r2
where r2.wscode = '300020'
and r2.art_code in ('1000105243','1000133574','3128997101','1000120669','1000105238','3001070011','9409612297','1000105240','1000113762','1000105244','1000072748')
and r2.move_type = 'P'

--300020
--in ('9639630304','1000136414','1000171278','1019999493','1000105224','1000105238','3122250023','1000113762','1000105244','1000133574','1000136738','1524300052','3001070015','1000105240','1000105252','3128998901','3001200010','1000105243','3001070011','1013280009','1000159338','1000159339','1000105251')

--300103
--in ('1000105243','1000133574','3128997101','1000120669','1000105238','3001070011','9409612297','1000105240','1000113762','1000105244','1000072748')

--��������� ���. �����
select * from whs.article_kiscontr_link al
join whs.article a on a.ID_ART = al.id_article
where a.CODE in ('9639630304','1000136414','1000171278','1019999493','1000105224','1000105238','3122250023','1000113762','1000105244','1000133574','1000136738','1524300052','3001070015','1000105240','1000105252','3128998901','3001200010','1000105243','3001070011','1013280009','1000159338','1000159339','1000105251')

select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1183512520
begin
  doc_egais.support_api.delete_waybill_from_send(p_id_send => 5819510
                                                ,p_description => '����� � ������� ����������');
  doc_egais.support_api.delete_waybill_from_send(p_id_send => 5820189
                                                ,p_description => '����� � ������� ����������');
  doc_egais.support_api.delete_waybill_from_send(p_id_send => 5996451
                                                ,p_description => '����� � ������� ����������');                                                
end;

select * from whs.redistribution_oplink_tbl
select * from whs.REDISTRIBUTION_TASK_TBL
select * from whs.REDISTRIBUTION_TASK_DETAIL_TBL

-- ����������� id_op ��������
select 
wh.code as "��� ��"
, wh.name as "�������� ��"
, c.code as "��� ��"
, c.name as "�������� ��"
, t.FULLNAME as "��� ��������"
, op.OPNUMBER as "����� ��������"
, op.OPDATE as "���� ��������"
, op.OPSUM as "����� ��������"
, s.id_send_status as "������ �����"
, ss.name as "������ �����"
, op.* -- ��� ������ �� ��������
from whs.operation op 
join whs.typeop t on t.ID_TOP = op.ID_TOP
join whs.warehouse wh on wh.id_ws = nvl (op.ID_WSI, op.id_wso)
join whs.contractor c on c.id_contr = op.ID_CONTR
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
left join doc_egais.send_doc_status_egais_tbl ss on ss.id_send_status = s.id_send_status
where 
--op.ID_OP = -1250095693
    op.OPNUMBER = '230218D3033' -- ����� ��������
and op.OPDATE = '01.11.2016' -- ���� ��������


-- �������� �� ��������� �������� ���
select
op.id_op, op.OPNUMBER, op.OPDATE, op.OPSUM, op.ID_TOP, s.id_send_status as op_status, r.*
from whs.operation op
join whs.warehouse wh on wh.id_ws = op.ID_WSI
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
left join doc_Egais.Reg_Transfer_Task_Tbl r on r.id_op = op.id_op
where op.id_top = 17
and op.OPSUM < 0
and op.opdate >= '27.08.2016' and op.OPDATE < '29.09.2016'
and wh.code = '720217'
--and s.id_send_status = 11


select * from whs.operation op where op.id_op in (-1132039557, -1184369138, -1185561545)
(-1132039557
,-1184369138
,-1184408389
,-1184402316
,-1185561545
)
�������                            �������
-1132039557  -1132039111
-1184369138  -1184368874
-1185561545  -1185561003
select * from whs.opreference o where o.id_opref = -1153631344

--�������� ��������
select opr.id_op as "�����", op.* from whs.opreference opr
join whs.operation op on op.ID_OP = opr.id_opref
where opr.id_op in (-1185561545,-1184369138,-1132039557) -- �������� ��������

select * from doc_egais.send_doc_egais_tbl s where s.id_send_base in (-1185561003,-1184368874,-1132039111)



select * from doc_egais.waybill_doc_header_tbl w where w.id_document = 454770441
                                                                       454815152
                                                                         454815170
select * from doc_egais.wbinformbreg_doc_header_tbl wb where wb.id_document = 528335354--wb.id_wb = '5DA5F76CBB9F11E6BEAFF8B1A0A0AD67'
select * from whs.document where id_document = 
454770441
- 528335354


select * from whs.operation op where op.opguid = hextoraw ('47D57713836D52CDE053AC900C0AFE20')

select * from retail.registr_tbl


select * from acan.ANALYTIC_TBL
where id_analytic in ('58556155','56236527','56236532','56236533','56236534','56236535','56236536','56236537','56236538','56236539','56236540','56236541','56236542','56236543','56236544','56236545','56236546','56236547','56236548','56236549','56236550','56236551','56236552','56236553','56236554','56236555','56236556','56441912','56441913','56441914','56441915','56441916','56441918','56441919','56441921','56441923','56441925','56441926','56441927','56441929','56441930','56441932','56441933','56441935','56441937','56441938','56441939','56441940','56441941','56441942','56441943','56441944','56441945','56441946','56441947','56693540','56693938','56693956','57264874','56693542','56693970','56693990','56694006','56694023','56694046','56694058','56694073','58641809','58641811','58641812','58641813','58641815','58641816','58641818','58641820','58641821','58641823','58641825','58641826','58641827','57891982','57891983','57891984','57891985','57891986','57891987','57891988','58983016','58983018','58983019','58983027','58983028','58983029','58983030','58983031','58987012','58987013','58987014','58987016','58987017','58987022','58987023','58987027','58987028','58987032','58987036','58987044','58987055','58987063','58987078','58987084','58987090','58987093','58987101','58987106','58987107','58987109','58987111','58987115','58987121','58987124','58987127','58987129','58987134','58987138','58987149','58987152','58987153','58987155','58987160','58987163','58987169','58987171','58987172','58987177','58987179','58987182','58987187','58987188','58987190','56693528','56693919','56693940','56693966','56693976')
and id_art in ('658813','443915','551518','523834','378282','421790','551554','506995','671457','115342','433249','621609','609262','433248','549914','671456','671827','589297','272513','507636','507641','112746','508991','572739','358244','466138','552832','571167','671456','551518','664922','614479','575663','571171','536563','675280','675284','683640','683641','591886','559194','650041','671823','551519','603939','566275','377462','658813','563446','498781','344978','683803','609262','681529','443913','415906','329266','535181','378283','670788','675280','551557','551526','549914','551521','240182','460633','551521','563446','675284','591886','339830','358244','571172','645189','603200','509811','517403','507745','545679','620628','450513','540188','561840','482799','488584','671456','603199','517235','607865','614479','459013','592402','671456','607866','551518','551550','673140','621609','378282','551521','551545','675285','179339','670788','650917','659053','451495','671456','563446','274449','551522','563444','566277','575663','551549','243323','591886','344979','121877','675280','566275','358244','507638','436456','158701','309435','502660','621608','425468','193469','675291','507641','515309','378294','515312','515965','675057','527941','375514','507825','527432','566277','447091','233755')

-- ��������, ��� ���-�� �� � �������� > ��
with  op_prihod as (
select 
(select count (*) from whs.op_art oa where oa.ID_OP = op.ID_OP) as "���������� �� � ��������"
, (select count (*) from doc_egais.waybill_doc_content_tbl wbc where wbc.id_document = wbh.id_document) as "���-�� �� � ����"
, d.id_document
, d.id_doctype
, d.isdeleted
, s.id_send_status
, op.* from whs.operation op
join whs.doc_op do on do.id_op = op.id_op
-- ��������, �������� � ������� ���
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
join whs.docreference dr on dr.id_doc_depend = s.id_document
join doc_egais.waybill_doc_header_tbl wbh on wbh.id_document = dr.id_doc_master
join whs.document d on d.id_document = wbh.id_document
where op.OPDATE >= '01.01.2017'
and (select count (*) from doc_egais.waybill_doc_content_tbl wbc where wbc.id_document = wbh.id_document) < (select count (*) from whs.op_art oa where oa.ID_OP = op.ID_OP)
)
, op_rashod as (
select 
(select count (*) from whs.op_art oa where oa.ID_OP = op.ID_OP) as "���������� �� � ��������"
, (select count (*) from doc_egais.waybill_doc_content_tbl wbc where wbc.id_document = wbh.id_document) as "���-�� �� � ����"
, d.id_document
, d.id_doctype
, d.isdeleted
, s.id_send_status
, op.* from whs.operation op
-- ��������, �������� � ������� ���
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
join doc_egais.waybill_doc_header_tbl wbh on wbh.id_document = s.id_document
join whs.document d on d.id_document = wbh.id_document
where op.OPDATE >= '01.01.2017'
and (select count (*) from doc_egais.waybill_doc_content_tbl wbc where wbc.id_document = wbh.id_document) < (select count (*) from whs.op_art oa where oa.ID_OP = op.ID_OP)
)
--union

select * from whs.warehouse wh where wh.guid = '6A1AC03319DC11E2BBFE5EF3FCE0557F'--wh.code = '644708'

select wh.code, wh.name, s.* from doc_egais.send_doc_egais_tbl s
join whs.warehouse wh on wh.guid = s.ws_guid
where s.id_send_base in (2604269)
and s.id_send_type = 6;

select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1373004463

select distinct wbc.id_position, a.CODE, a.NAME, wbc.quantity, p.full_name, p.alc_code from doc_egais.waybill_doc_content_tbl wbc
join doc_egais.product_tbl p on p.id_product = wbc.id_product
left join whs.article_kiscontr_link al on al.code_egais = p.alc_code
left join whs.article a on a.ID_ART = al.id_article
where wbc.id_document = 532322509
order by wbc.id_position

--������� �������
select op1.ID_OP, op1.OPNUMBER, op1.OPDATE, op1.OPSUM, top.FULLNAME, op17.* from whs.operation op1
join whs.opreference opr on opr.id_opref = op1.ID_OP
join whs.operation op17 on op17.ID_OP = opr.id_op --and op17.ID_TOP = 17
join whs.typeop top on top.ID_TOP = op17.ID_TOP
where op1.ID_OP = -1369667001


select
r.*
  from retail.registr_tbl r
where 1 = 1
  and r.wscode = '182325'
-- and 
   -- (r.art_code in ()
    -- or
   --  r.alc_code in ()
--   )
order by 1;

-- ��������� �������, ���������� �� �����
with params as(
select 
--'9717500041' as tp_code, -- ��� ��
wh.code as oo_code
, wh.id_ws
from whs.warehouse wh
where --wh.lg1 in (101,201)--
wh.code = '360101' -- ��� ��'483638'--
)
, tz as ( -- ��������� ���������� ������ �� ������ �������� � �� �� �����
select max (doc.id_document) as id_doc, p.id_ws, p.oo_code--, doc.docdate
from params p
join doc_egais.document_tbl dtb ON dtb.id_ws = p.id_ws
join whs.document doc on dtb.id_document = doc.id_document 
where doc.id_doctype = 511
group by p.id_ws, p.oo_code--, doc.docdate
)
, egais as ( --������� � �� �� �����
select distinct
       rc.quantity qeg
       ,pt.alc_code
       ,tz.id_ws
       ,tz.oo_code
   from tz
   join doc_egais.replyrestshop_doc_content_tbl rc on rc.id_document = tz.id_doc --�� ������ ����� ��
   left join doc_egais.product_tbl pt on rc.id_product = pt.id_product
)
select tz.oo_code as "��� ��", d.lastdate as "���� �2�����", egais.alc_code as "���. ���", egais.qeg as "���-��" from tz
left join egais on egais.id_ws = tz.id_ws
left join whs.document d on d.id_document = tz.id_doc




with rest_vw_ia as ( -- ������� �2 � art_code
select 
vw.wscode
, vw.alc_code as alc_code
, vw.rest_type
--, vw.art_code as art_code
, sum (vw.quantity) as quantity
from RETAIL.Registr_Rest_Vw vw 
where  vw.wscode = '360101'
--and vw.rest_type in ('1','2','5')
group by vw.wscode, vw.rest_type, vw.alc_code--, vw.art_code
order by vw.wscode, vw.alc_code, vw.rest_type

select a.code_egais, ar.CODE  from whs.article_kiscontr_link a 
left join whs.article ar on ar.ID_ART = a.id_article
where a.code_egais = '0116125000001955513'


select * from retail.nsi_link_vw l
where l.alc_code = '0116125000001955513'


select
r.*
  from retail.registr_tbl r
where 1=1
and r.wscode = '360101'
and 
   (r.art_code in ('9799901315')
    or
    r.alc_code in ('0116125000001955513')
  )
order by 1;

-- ������� �2 vw.rest_type in ('1','2','5')
select 
vw.wscode
, vw.alc_code as alc_code
--, vw.rest_type
--, vw.art_code as art_code
, sum (vw.quantity) as quantity
from RETAIL.Registr_Rest_Vw vw 
where  vw.wscode = '182325'
and vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code--, vw.art_code
order by vw.wscode, vw.alc_code


-- ������� �2 vw.rest_type in ('3','4')
select 
vw.wscode
, vw.alc_code as alc_code
--, vw.rest_type
--, vw.art_code as art_code
, sum (vw.quantity) as quantity
from RETAIL.Registr_Rest_Vw vw 
where  vw.wscode = '182325'
and vw.rest_type in ('3','4')
group by vw.wscode, vw.alc_code--, vw.art_code
order by vw.wscode, vw.alc_code

)
, rest_vw as ( -- ������� �2 ��� art_code
select 
vw.wscode
, vw.alc_code as alc_code
, sum (vw.quantity) as quantity
from rest_vw_ia vw
group by vw.wscode, vw.alc_code
)
, rest_vw_ia_34 as ( -- ������� �2 � art_code ��������� �������
select 
vw.wscode
, vw.alc_code as alc_code
, vw.art_code as art_code
, sum (vw.quantity) as quantity
from egais e
left join RETAIL.Registr_Rest_Vw vw on vw.wscode = e.oo_code and vw.alc_code = e.alc_code
where vw.rest_type in ('3','4')
group by vw.wscode, vw.alc_code, vw.art_code
)
, rest_vw_34 as ( -- ������� �2 ��� art_code - ��������� �������
select 
vw.wscode
, vw.alc_code as alc_code
, sum (vw.quantity) as quantity
from rest_vw_ia_34 vw
group by vw.wscode, vw.alc_code
)

select s.id_send_status, op.* from whs.operation op 
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
where op.OPNUMBER in ('310011A2806/1 ', '310011A1728')
and op.ID_TOP = 1

select * from doc_egais.product_tbl where alc_code like '%030000309398%'

--��� �2 ���������
select
vw.wscode
, vw.*
/*, vw.alc_code as alc_code
, vw.art_code as art_code
, vw.rest_type
, sum (vw.quantity) as quantity*/
from RETAIL.Registr_Rest_Vw vw
where vw.wscode = '610202'--vw.rest_type in ('1','2','5')
group by vw.wscode, vw.rest_type, vw.alc_code, vw.art_code


-- ��� ������� ���������������� � ��
with pr as (
select rtb.wscode, rtb.alc_code/*, rtb.rest_type*/, sum (rtb.quantity) as quantity from retail.registr_tbl rtb
where rtb.wscode = '610202'
and rtb.reg_id_b is not null
and rtb.rest_type in (1,2,5)
and rtb.move_type = 'P'
group by rtb.wscode, rtb.alc_code--, rtb.rest_type 
)
, ras as (
select rtb.wscode, rtb.alc_code/*, rtb.rest_type*/, sum (rtb.quantity) as quantity from retail.registr_tbl rtb
where rtb.wscode = '610202'
and rtb.reg_id_b is not null
and rtb.rest_type in (1,2,5)
and rtb.move_type = 'M'
group by rtb.wscode, rtb.alc_code--, rtb.rest_type 
)
, rest as (
select
vw.wscode
, vw.alc_code as alc_code
, vw.art_code as art_code
, sum (vw.quantity) as quantity
from RETAIL.Registr_Rest_Vw vw
where vw.wscode = '610202' and vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code, vw.art_code
)
select rest.*,
case 
  when rest.quantity <= (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) then rest.quantity
    else (nvl (pr.quantity, 0) - nvl (ras.quantity, 0))
    end as "�������� ����������������"
from rest
left join pr on pr.wscode = rest.wscode and pr.alc_code = rest.alc_code
left join ras on ras.wscode = rest.wscode and ras.alc_code = rest.alc_code
where rest.quantity > 0

-- ������� �������� � ���� �� �� ����� ��������� ����
select *
from whs.warehouse wh
join doc_egais.send_doc_egais_tbl s on s.ws_guid = wh.guid
where
/*s.id_doctype in (484,506,514,481,485,482,507)
and */(
(wh.name = '502654' and s.send_date >= trunc (to_date ('16.12.2016'),'DDD'))
OR (wh.name = '502463' and s.send_date >= trunc (to_date ('16.12.2016'),'DDD'))
OR (wh.name = '504431' and s.send_date >= trunc (to_date ('03.11.2015'),'DDD'))
OR (wh.name = '502707' and s.send_date >= trunc (to_date ('30.12.2015'),'DDD'))
OR (wh.name = '502380' and s.send_date >= trunc (to_date ('27.10.2015'),'DDD'))
OR (wh.name = '770184' and s.send_date >= trunc (to_date ('26.07.2016'),'DDD'))
)


select * from doc_egais.document_tbl
select * from whs.doctype

select * from doc_egais.send_doc_egais_tbl s where s.id_doctype = 507



select * from whs.document doc where doc.id_doctype = 482 and doc.lastdate < '25.03.2017' 
order by doc.id_document DESC FETCH FIRST 20 ROWS ONLY

��� � whs.document, ��� � doc_egais.send_doc_egais_tbl 470	E_ACTINV	��� ��������������
+ - 522	E_AINVRGRD	��� ������������� �����������
+ - 509	E_ARECAPR2	��� ��������� �� �2
+ + 484	E_CHARGEON	��� � ���������� �� ������ �����
+ + 506	E_CHRGONSH	��� � ���������� �� ������ �� �����
+ - 472	E_CNFTCKT	������������� ���� ����������� � ���
+ - 518	E_CREPIWB	������������� ������ ���������� ����
+ + 514	E_QBARCODE	������ PDF417 �� ����� � ������ ���
+ - 515	E_RBARCODE	����� �� ������ PDF417 �� ����� � ������ ���
+ - 517	E_RREPEAL	������ �� ������ ���������� ���������
+ + 481	E_WAYBILL	��� �����
+ + 482	E_WBACT	��� ����������� � ���
+ + 485	E_WRITEOFF	��� � �������� ������ �����
+ + 507	E_WRTOFFSH	��� � �������� ������ �� �����


-- �������� ��
select * from whs.document doc 
left join whs.docreference dre on dre.id_doc_master = doc.id_document
left join whs.document d on d.id_doctype = dre.id_doc_depend
--join whs.doctype dt on dt.id_doctype = d.id_doctype
where
doc.id_doctype = 482 and doc.docdate < '25.03.2017' 
--dre.id_doc_master = 576063678
--and d.id_doctype = 480
order by doc.id_document DESC FETCH FIRST 40 ROWS ONLY

-- ���� ���������, ������� ��� � �������
-- ������� �������� � ���� �� �� ����� ��������� ����
-- ������� �������� � ���� �� �� ����� ��������� ����
select *
from whs.document doc
join doc_egais.document_tbl de on de.id_document = doc.id_document
join whs.warehouse wh on wh.id_ws = de.id_ws
where
/*doc.id_doctype in (484,506,514,481,485,482,507)
and*/(
(wh.name = '502654' and doc.docdate >= trunc (to_date ('16.12.2016'),'DDD'))
OR (wh.name = '502463' and doc.docdate >= trunc (to_date ('16.12.2016'),'DDD'))
OR (wh.name = '504431' and doc.docdate >= trunc (to_date ('03.11.2015'),'DDD'))
OR (wh.name = '502707' and doc.docdate >= trunc (to_date ('30.12.2015'),'DDD'))
OR (wh.name = '502380' and doc.docdate >= trunc (to_date ('27.10.2015'),'DDD'))
OR (wh.name = '770184' and doc.docdate >= trunc (to_date ('26.07.2016'),'DDD'))
)

select * from doc_egais.send_doc_egais_tbl s 
where s.id_send_base = 566764961

select * from whs.document where id_document = 566764961


select  distinct top.ID_TOP, top.FULLNAME, op.id_op, op.TYPEOP, op.opnumber, op.OPDATE, op.OPSUM, sdt.id_send_status--, omi.vbool as "������ �� ��"--, a.NAME, am.vstring
from whs.operation op
join whs.op_art oa on oa.ID_OP = op.id_op
join whs.article a on a.ID_ART = oa.ID_ART
join whs.art_moreinfo am on am.id_art = a.id_art
join whs.addition adi on adi.ID_ADD = am.id_add
join whs.op_moreinfo omi on omi.id_op = op.ID_OP
join whs.warehouse wh on wh.id_ws = op.ID_WSI
left join doc_egais.send_doc_egais_tbl sdt on sdt.id_send_base = op.ID_OP
join whs.typeop top on top.ID_TOP = op.ID_TOP
where wh.code = (select mm_code from dat)--(select distinct mm_code from rashod)
and op.OPDATE between trunc ((select date_start from dat),'DD') and trunc ((select date_end from dat),'DD')--to_date (sysdate)
and am.vstring not like '000' -- ���������� ��������������� ����
and adi.name like '���_���'
and sdt.id_send_status = 11--(sdt.id_send_status in (1,2,3,4,5,6,7,8,9,10) or sdt.id_send_status is null)
-- ������� �������� ������� �� �� ��� �� ����. ������
and (omi.id_add = 660 and omi.vbool = 1 and op.id_top = 1 
     OR op.id_top in (142,17,15,58,106)
     )
     
     
select * from whs.operation o where o.OPNUMBER in ('483638A1073' ,'483638A1076/8')--'730109A2171/4' 
-1109469494
-1106353594

select * from doc_egais.send_doc_egais_history_tbl sh where sh.id_send_base = -1434332827


select wh.code, wh.name, wh.id_controwner,
(SELECT DS.DATE_END
FROM WHS.DIVISION DIV
JOIN ONSI_OUT.DIVISION_STORAGE_VW DS ON DIV.ID_DIV = DS.ID_DIV
LEFT JOIN WHS.STORAGE_TBL W ON W.ID_WS=DS.ID_WS
LEFT JOIN WHS.DIV_STATE  DS ON DS.ID_DIV=DIV.ID_DIV AND DS.ID_COND=11
WHERE w.code in (wh.code)
  ) as "���� �������� ��",
(SELECT 'file://///Esb-egais-01/egais/' || to_char(df.lastdate, 'dd-mm-yyyy') || '/' || df.filename
FROM whs.DOCUMENT doc
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE
doc.id_document in (s.id_document) ) as "����",
s.* from doc_egais.send_doc_egais_tbl s 
left join whs.warehouse wh on wh.guid = s.ws_guid
where s.id_send_base in (-1432118109
,-1431831907
,-1434155280
,-1433004890
,-1434570208
)
where s.id_send in (13173484
,13171477
,13171535
,13167429
,13167468
,13164909
,13175667
,13174300)
--��, ��� ����,��������
(13025320
,13025818
,13025857
,13026183
,13026918
,13027554
,13027845
,13028053
,13027775
,13025186
,13026477
,13025304
,13027508
,13027597
)

select wdc.identity , op.*, d.*
from whs.opreference opr 
join whs.operation op on op.id_op = opr.id_op and op.ID_TOP=169 
join whs.doc_op do on do.id_op=op.ID_OP 
join whs.document d on d.id_document=do.id_document and d.id_doctype=481 --and (d.isdeleted=0 or d.isdeleted is null) 
left join doc_egais.waybill_doc_header_tbl wdc on wdc.id_document=d.id_document 
where opr.id_opref = -1484576496


-- ����� ������� ��� ��������
with op as( 
select op.id_op as dochka 
, op.OPNUMBER as op_kp 
, op.id_top as idtop_kp 
, wh.code as ka1_kp 
, c.code as ka2_kp 
, op2.id_op as roditel 
, op2.OPNUMBER as op_rpm 
, op2.id_top as idtop_rpm 
, wh2.code as ka1_rpm 
, c2.code as ka2_rpm 
, opr.reftype 
from whs.opreference opr 
join whs.reftype rt on rt.code = opr.reftype 
join whs.operation op on opr.id_opref = op.id_op 
join whs.warehouse wh on wh.id_ws = nvl (op.ID_WSI, op.ID_WSO) 
join whs.contractor c on c.id_contr = op.ID_CONTR 
join whs.operation op2 on opr.id_op = op2.ID_OP 
join whs.warehouse wh2 on wh2.id_ws = nvl (op2.ID_WSI, op2.ID_WSO) 
join whs.contractor c2 on c2.id_contr = op2.ID_CONTR where opr.id_opREF = -1129008156  
) , d481 as (  
select op.roditel
, doc.id_document
, doc.docnumber
, doc.docdate
, dh.actdate
, doc.id_doctype
, doc.isdeleted
, wbh.identity 
from op op 
join whs.doc_op do ON do.id_op = op.roditel 
join whs.document doc ON doc.id_document = do.id_document 
left join doc_egais.waybill_doc_header_tbl wbh on wbh.id_document = doc.id_document 
join whs.document_history dh ON dh.id_document = doc.id_document and dh.action = 'I' 
where doc.id_doctype = 481 and (doc.isdeleted = 0 OR doc.isdeleted is null) 
) , d483 as ( 
SELECT 
d481.id_document
, doc2.id_document as d483_id
, doc2.docnumber
, doc2.docdate
, doc2.id_doctype
, doc2.isdeleted
, fbh.wb_reg_id    
from d481    
join whs.docreference dref on dref.id_doc_master = d481.id_document     
JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend     
left join doc_egais.wbinformbreg_doc_header_tbl fbh on fbh.id_document = doc2.id_document        
WHERE       doc2.id_doctype = 483 and (doc2.isdeleted = 0 OR doc2.isdeleted is null) 
) 
select op.dochka 
, op.op_kp 
, op.idtop_kp 
, op.ka1_kp 
, op.ka2_kp 
, op.roditel 
, op.op_rpm 
, op.idtop_rpm 
, op.ka1_rpm 
, op.ka2_rpm 
, op.reftype 
, d481.id_document as d481_ID 
, d481.docnumber as d481_number 
, d481.docdate as d481_docdate 
, d481.actdate as d481_create 
, d481.id_doctype as d481_iddoctype 
, d481.isdeleted as d481_isdel 
, d481.identity as d481_identity 
, d483.d483_id 
, d483.docnumber as d483_number 
, d483.docdate as d483_docdate 
, d483.id_doctype as d483_iddoctype 
, d483.isdeleted as d483_isdel 
, d483.wb_reg_id as d483_wbregid 
from op 
left join d481 on d481.roditel = op.roditel 
left join d483 on d483.id_document = d481.id_document


with op as( select op.id_op as dochka, op.OPNUMBER as op_kp, op.id_top as idtop_kp, wh.code as ka1_kp, c.code as ka2_kp, op2.id_op as roditel, op2.OPNUMBER as op_rpm, op2.id_top as idtop_rpm, wh2.code as ka1_rpm, c2.code as ka2_rpm, opr.reftype from whs.opreference opr join whs.reftype rt on rt.code = opr.reftype join whs.operation op on opr.id_opref = op.id_op join whs.warehouse wh on wh.id_ws = nvl (op.ID_WSI, op.ID_WSO) join whs.contractor c on c.id_contr = op.ID_CONTR join whs.operation op2 on opr.id_op = op2.ID_OP join whs.warehouse wh2 on wh2.id_ws = nvl (op2.ID_WSI, op2.ID_WSO) join whs.contractor c2 on c2.id_contr = op2.ID_CONTR where opr.id_opREF = -1189307289  ) , d481 as (  select op.roditel, doc.id_document, doc.docnumber, doc.docdate, dh.actdate, doc.id_doctype, doc.isdeleted, wbh.identity from op op join whs.doc_op do ON do.id_op = op.roditel join whs.document doc ON doc.id_document = do.id_document left join doc_egais.waybill_doc_header_tbl wbh on wbh.id_document = doc.id_document join whs.document_history dh ON dh.id_document = doc.id_document and dh.action = 'I' where doc.id_doctype = 481 and (doc.isdeleted = 0 OR doc.isdeleted is null) ) , d483 as ( SELECT d481.id_document, doc2.id_document as d483_id, doc2.docnumber, doc2.docdate, doc2.id_doctype, doc2.isdeleted, fbh.wb_reg_id    from d481    join whs.docreference dref on dref.id_doc_master = d481.id_document     JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend     left join doc_egais.wbinformbreg_doc_header_tbl fbh on fbh.id_document = doc2.id_document        WHERE       doc2.id_doctype = 483 and (doc2.isdeleted = 0 OR doc2.isdeleted is null) ) select op.dochka , op.op_kp , op.idtop_kp , op.ka1_kp , op.ka2_kp , op.roditel , op.op_rpm , op.idtop_rpm , op.ka1_rpm , op.ka2_rpm , op.reftype , d481.id_document as d481_ID , d481.docnumber as d481_number , d481.docdate as d481_docdate , d481.actdate as d481_create , d481.id_doctype as d481_iddoctype , d481.isdeleted as d481_isdel , d481.identity as d481_identity , d483.d483_id , d483.docnumber as d483_number , d483.docdate as d483_docdate , d483.id_doctype as d483_iddoctype , d483.isdeleted as d483_isdel , d483.wb_reg_id as d483_wbregid from op left join d481 on d481.roditel = op.roditel left join d483 on d483.id_document = d481.id_document
with op as( select op.id_op as dochka, op.OPNUMBER as op_kp, op.id_top as idtop_kp, wh.code as ka1_kp, c.code as ka2_kp, op2.id_op as roditel, op2.OPNUMBER as op_rpm, op2.id_top as idtop_rpm, wh2.code as ka1_rpm, c2.code as ka2_rpm, opr.reftype from whs.opreference opr join whs.reftype rt on rt.code = opr.reftype join whs.operation op on opr.id_opref = op.id_op join whs.warehouse wh on wh.id_ws = nvl (op.ID_WSI, op.ID_WSO) join whs.contractor c on c.id_contr = op.ID_CONTR join whs.operation op2 on opr.id_op = op2.ID_OP join whs.warehouse wh2 on wh2.id_ws = nvl (op2.ID_WSI, op2.ID_WSO) join whs.contractor c2 on c2.id_contr = op2.ID_CONTR where opr.id_opREF = -1348171660  ) , d481 as (  select op.roditel, doc.id_document, doc.docnumber, doc.docdate, dh.actdate, doc.id_doctype, doc.isdeleted, wbh.identity from op op join whs.doc_op do ON do.id_op = op.roditel join whs.document doc ON doc.id_document = do.id_document left join doc_egais.waybill_doc_header_tbl wbh on wbh.id_document = doc.id_document join whs.document_history dh ON dh.id_document = doc.id_document and dh.action = 'I' where doc.id_doctype = 481 and (doc.isdeleted = 0 OR doc.isdeleted is null) ) , d483 as ( SELECT d481.id_document, doc2.id_document as d483_id, doc2.docnumber, doc2.docdate, doc2.id_doctype, doc2.isdeleted, fbh.wb_reg_id    from d481    join whs.docreference dref on dref.id_doc_master = d481.id_document     JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend     left join doc_egais.wbinformbreg_doc_header_tbl fbh on fbh.id_document = doc2.id_document        WHERE       doc2.id_doctype = 483 and (doc2.isdeleted = 0 OR doc2.isdeleted is null) ) select op.dochka , op.op_kp , op.idtop_kp , op.ka1_kp , op.ka2_kp , op.roditel , op.op_rpm , op.idtop_rpm , op.ka1_rpm , op.ka2_rpm , op.reftype , d481.id_document as d481_ID , d481.docnumber as d481_number , d481.docdate as d481_docdate , d481.actdate as d481_create , d481.id_doctype as d481_iddoctype , d481.isdeleted as d481_isdel , d481.identity as d481_identity , d483.d483_id , d483.docnumber as d483_number , d483.docdate as d483_docdate , d483.id_doctype as d483_iddoctype , d483.isdeleted as d483_isdel , d483.wb_reg_id as d483_wbregid from op left join d481 on d481.roditel = op.roditel left join d483 on d483.id_document = d481.id_document

select opr.id_opref as "�������", op.ID_OP, op.ID_TOP, op.OPDATE, s.id_send_status, s.* from 
whs.opreference opr
join whs.operation op on op.ID_OP = opr.id_op and op.ID_TOP = 169
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.id_op
where opr.id_opref in (-1393808762)

select * from doc_egais.send_doc_egais_tbl where id_send_base = -1129008179

select op.id_op, c.name as KA, op.OPNUMBER, op.OPSUM, op.OPDATE, wh.code, wh.name as MM, s.id_send_status from whs.operation op
join whs.warehouse wh on wh.id_ws = nvl(op.ID_WSI, op.ID_WSO)
join whs.contractor c on c.id_contr = op.ID_CONTR
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
where op.ID_OP in (-1322164802)
(-1415427556, -972731287)

select * from acan.analyticopart_tbl at 
join whs.operation op on op.ID_OP = at.id_op
where at.id_analytic = 61495882 and op.OPNUMBER = '230086A3273'

select * from acan.analyticopart_tbl at 
join whs.operation op on op.opguid = at.opguid
where at.id_analytic = 61495882;

select * from whs.article a where a.ID_ART = 112957

     
select * from whs.operation op
join whs.warehouse wh on wh.id_ws = op.ID_WSI
left join whs.op_moreinfo omi on omi.id_op = op.ID_OP and omi.id_add = 660
where op.id_top = 1 and op.OPDATE >= trunc (to_date('25.03.2017'), 'DDD') and op.OPDATE < trunc (to_date('29.03.2017'), 'DDD')
--and op.OPGUID = hextoraw ('4B82E3350AE75D2DE053AC780B0AE857')
and (omi.vbool = 0 OR omi.vbool is null)
--and ((omi.id_add = 660 and (omi.vbool = 0 OR omi.vbool is null)) OR omi.id_add is null)
and wh.lg1 = 101 
and op.OPNUMBER like '%A%'    




select
      sd3.id_document,
      (SELECT 'file://///Esb-egais-01/egais/' || to_char(df.lastdate, 'dd-mm-yyyy') || '/' || df.filename
FROM whs.DOCUMENT doc
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE
doc.id_document in (sd3.id_document) ) as "����",
      btar.id_document AS "�� ����",
     -- doc.docguid AS "���� ����",
      '��������',
      bac.id_action, 
      sta.name,
     -- bac.id_type_action, --5: �������� �����, 6: ������� �� ������� �������
     sd3.id_send_status STATUS,
      '�������',
      sd3.id_send,
      sd3.id_send_base AS "�� ���.", 
      rt.tasknumber NUM, 
      rt.taskdate  AS "DATEO",
      rt.id_transfer_task_base AS "TYPE",
      ws3.code,
      ws3.fullname AS "WS",
      sd3.add_date AS "DATEA", 
      sd3.id_document IDDOC, 
      sd3.id_send_status STATUS, 
      sd3.description AS "DESC", 
      coalesce(sd3.ticket_date, sd3.send_date, sd3.last_work_date) As DATEL,
      sd3.id_ticket AS "TD1",
      dtb.reply_id
from acan.BB_TARGET_TBL btar
join acan.bb_task_tbl btas ON btas.id_target = btar.id_target
join acan.BB_ACTION_TBL bac ON bac.id_task = btas.id_task
join whs.document doc ON doc.id_document = btar.id_document
left join acan.BB_RESULT_TBL brs On brs.id_action = bac.id_action    
join acan.bb_status_action_vw sta ON sta.id_status = bac.id_status                                   
--�������� ���� "������� ������� ��2 � ��1
left join doc_egais.reg_transfer_task_tbl rt ON rt.id_op = bac.id_action 
                                                and bac.id_type_action = 6 
                                                and rt.id_transfer_task_base = 9
     left join doc_Egais.Send_Doc_Egais_Tbl sd3 ON sd3.id_send_base = rt.id_transfer_task and sd3.id_send_type = 6
     left join whs.storage_tbl ws3 ON ws3.id_ws = rt.id_ws
     left join doc_Egais.document_tbl dtb ON dtb.id_document = sd3.id_Document
where
     btar.id_document in (577417485)
     and bac.id_type_action in (6)  
     --and bac.id_action = 1541540  
     and sta.name != '���������� � �������'  
     and sd3.id_send_status != 11
     and dtb.reply_id is null
order by 4 desc

select * from whs.operation where opnumber = '560197TORRA6498'

select *
from doc_egais.send_doc_egais_tbl s
join whs.warehouse wh on wh.guid = s.ws_guid
where wh.code = '563383'
and s.add_date >= '01.03.2017'

select distinct wh.code, wh.fullname as "�������� ��", op.ID_OP, op.ID_TOP
, top.FULLNAME, op.OPNUMBER, op.OPDATE, op.opsum
, s.id_send_status 
, a.CODE as "��� ��"
, a.NAME as "������������ ��"
, oa.QUANTITY as "���-�� ��"
, oa.OPSUM as "����� �� ��"
from whs.operation op
join whs.warehouse wh on wh.id_ws = nvl (op.ID_WSI, op.ID_WSO)
join whs.typeop top on top.ID_TOP = op.ID_TOP
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
join whs.op_art oa on oa.ID_OP = op.ID_OP
join whs.article a on a.ID_ART = oa.ID_ART
where op.OPNUMBER like 'REC_%'
and wh.code = '182325'
and (s.id_send is null OR s.id_send_status <> 11)


begin
    doc_egais.support_api.revise_clear_producer(p_id_document => 556926416--�� ����
                                               ,p_id_op => ''--�� �������� (������ ������� ��������������)
                                               ,p_id_task => 0000000000604189--�� ������� (������ ������� ��������)
                                               ,p_description => '�� �������� ������ 25980');
 end;
 
 
select distinct op.ID_OP from doc_egais.send_doc_egais_tbl s
join whs.operation op on op.ID_OP = s.id_send_base
where s.add_date >= trunc(to_date('28.03.2017'), 'DDD')


-- ���� ��� > 1.5
select
oa.ID_OP, op.ID_TOP, op.OPNUMBER, op.OPDATE, op.OPSUM, s.id_send_status, s.add_date,
count (distinct oa.ID_ART) as "���-�� �� ��� grater 1,5 �"
from whs.op_art oa
join whs.article a on a.ID_ART = oa.ID_ART
join whs.art_moreinfo am on am.id_art = a.ID_ART
join whs.addition ad on ad.ID_ADD = am.id_add
join whs.operation op on op.ID_OP = oa.ID_OP
join doc_egais.send_doc_egais_tbl s on  s.id_send_base = oa.ID_OP
where
oa.id_op in (select distinct op.ID_OP from doc_egais.send_doc_egais_tbl s
join whs.operation op on op.ID_OP = s.id_send_base
where s.add_date >= trunc(to_date('28.03.2017'), 'DDD')
and op.OPDATE < trunc(to_date('01.01.2017'), 'DDD')
)
and a.CAPACITY > '1,5'
and am.id_add = 93 and (am.vstring = '����������� �������' OR am.vstring = '���')
group by oa.ID_OP, op.ID_TOP, op.OPNUMBER, op.OPDATE, op.OPSUM, s.id_send_status, s.add_date

select * from whs.operation op where op.OPNUMBER like '���0841142'
and op.ID_TOP in (1,17,15)
select * from whs.typeop
select * from whs.warehouse wh where wh.id_ws = 5896
select * from whs.contractor where id_contr = 99165

-- ���� �� �� �� ���������� ����������� � �����
select distinct wh.code from whs.warehouse wh
join doc_egais.send_doc_egais_tbl s on s.ws_guid = wh.guid
where wh.code in ('')
and s.id_send_status in (1,2,3,4,5,6,7,8,9,10)

-- ��������� ��
select * from whs.doc_op dop
join doc_egais.waybill_doc_header_tbl whe on whe.id_document = dop.id_document
join doc_egais.organization_tbl o on o.id_organization = whe.id_consignee
where dop.id_op = -1484576496



-- ���������� �������� �����
select * from doc_egais.send_doc_egais_tbl s
join whs.warehouse w on w.guid = s.ws_guid
where s.add_date >= '30.05.2017'
and w.code = '353094'
and s.id_doctype = 504

select * from doc_egais.transferts_doc_content_tbl ts
where ts.reg_id_b in ('FB-000000245375612', 'FB-000000275011294')

select * from doc_egais.transferts_doc_header_tbl

select * from whs.document d where d.id_document = 658199663


-- ��� �� � 11 ������� �� ��
select * from doc_egais.send_doc_egais_tbl s
join whs.warehouse w on w.guid = s.ws_guid
where w.code = '777865'
and s.id_send_status in (1,2,3,4,5,6,7,8,9,10)

select * from whs.doc_op dop
join whs.document d on d.id_document = dop.id_document
where dop.id_op in (-1322164802)



select
      --distinct sd3.id_send, sd3.id_document
      btar.id_document AS "�� ����",
     -- doc.docguid AS "���� ����",
      '��������',
      bac.id_action, 
      sta.name,
     -- bac.id_type_action, --5: �������� �����, 6: ������� �� ������� �������
     sd3.id_send_status STATUS, sd3.id_send_substatus SSTATUS,
      '�������',
      sd3.id_send,
      sd3.id_send_base AS "�� ���.", 
      rt.tasknumber NUM, 
      rt.taskdate  AS "DATEO",
      rt.id_transfer_task_base AS "TYPE",
      ws3.code,
      ws3.fullname AS "WS",
      sd3.add_date AS "DATEA", 
      sd3.id_document IDDOC, 
      sd3.id_send_status STATUS, 
      sd3.description AS "DESC", 
      coalesce(sd3.ticket_date, sd3.send_date, sd3.last_work_date) As DATEL,
      sd3.id_ticket AS "TD1",
      dtb.reply_id, dtb.lastdate
from acan.BB_TARGET_TBL btar
join acan.bb_task_tbl btas ON btas.id_target = btar.id_target
join acan.BB_ACTION_TBL bac ON bac.id_task = btas.id_task
join whs.document doc ON doc.id_document = btar.id_document
left join acan.BB_RESULT_TBL brs On brs.id_action = bac.id_action    
join acan.bb_status_action_vw sta ON sta.id_status = bac.id_status                                   
--�������� ���� "������� ������� ��2 � ��1
left join doc_egais.reg_transfer_task_tbl rt ON rt.id_op = bac.id_action 
                                                and bac.id_type_action = 6 
                                                and rt.id_transfer_task_base = 9
     left join doc_Egais.Send_Doc_Egais_Tbl sd3 ON sd3.id_send_base = rt.id_transfer_task and sd3.id_send_type = 6
     left join whs.storage_tbl ws3 ON ws3.id_ws = rt.id_ws
     left join doc_Egais.document_tbl dtb ON dtb.id_document = sd3.id_Document
where
     btar.id_document in (659536545)
     and bac.id_type_action in (6)  
    -- and bac.id_action in (1662472)--, 1648457) 
     --and sta.name not in ('���������� � �������', '���������')
    and sd3.id_send_status != 11
    -- and dtb.reply_id is null 
    and sd3.id_send is not null
order by 4 desc;    



select w.code, doc.* from doc_egais.document_tbl doc 
join whs.warehouse w on w.id_ws = doc.id_ws
where doc.id_document in (653660505)

select * from doc_egais.send_doc_egais_tbl s 
join whs.warehouse w on w.guid = s.ws_guid
where s.id_document = 653660505

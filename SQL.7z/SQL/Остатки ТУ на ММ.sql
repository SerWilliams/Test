--������� �� �� ��
select distinct a.name, a.CODE as art_code, r.fquant, r.mn, r.id_art--, aat.*--, max (mn) as ri
from rest r
join article a on a.ID_ART = r.id_art
join art_moreinfo am on am.id_art = r.id_art
join addition adi on adi.ID_ADD = am.id_add
JOIN alc_art_type aat on aat.alc_art_code = am.vstring
where 
r.id_ws = 0
and am.vstring not like '000'
and adi.name like '���_���'
--and a.code = '1000102401'
and r.mn = (select max (r2.mn)
from rest r2
where 
r2.id_ws = r.id_ws
and r2.id_art = r.id_art
group by r2.id_art)
and r.fquant > 0
and aat.licensing = '1'

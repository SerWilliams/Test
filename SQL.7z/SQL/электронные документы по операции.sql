select
op.ID_OP
,op.OPNUMBER
,op.OPDATE
,op.OPSUM
,d481.id_document "481 id"
,d481.isdeleted   "�������"
,d483.id_document "483 id"
,d483.isdeleted   "�������"
,d482.id_document "482 id"
,d482.isdeleted   "�������"
from whs.operation op
join whs.doc_op dop on dop.id_op = op.ID_OP
join whs.document d481 on d481.id_document = dop.id_document and d481.id_doctype = 481
join whs.docreference dr1 on dr1.id_doc_master = d481.id_document
join whs.document d482 on d482.id_document = dr1.id_doc_depend and d482.id_doctype = 482
join whs.docreference dr2 on dr2.id_doc_master = d481.id_document
join whs.document d483 on d483.id_document = dr2.id_doc_depend and d483.id_doctype = 483
where op.ID_OP = -1674472049

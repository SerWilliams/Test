-- ������������� �������� � �������� ��
select distinct
       doc.id_document
       , ws.fullname
       , dhed.rests_date
       , pr.full_name
       , pr.alc_code
       ,ns.art_code
       ,a.id_art
       , dscon.quantity
     --  , m.vstring
      ,aat.licensing
      ,a.CODE
      -- ,aat.type_name
     --  ,ad.ID_ADD
     ---  ,m.id_art
from whs.document doc
left join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
left join whs.warehouse ws on ws.id_ws = dtb.id_ws
left join doc_egais.replyrests_doc_header_tbl dhed ON dhed.id_Document = dtb.id_document
left join doc_Egais.Replyrestshop_Doc_Content_Tbl dscon ON dscon.id_document = dtb.id_document
left join doc_egais.product_tbl pr ON pr.id_product = dscon.id_product
left join retail.nsi_link_vw ns on pr.alc_code= ns.alc_code
left join whs.article a on a.code= ns.art_code
left join whs.art_moreinfo m on m.id_art= a.id_art
left join whs.addition ad on ad.id_add = m.id_add
LEFT JOIN whs.alc_art_type aat on aat.alc_art_code = m.vstring
WHERE
doc.id_document= 660816970 -- and pr.alc_code= '0015835000001951700'  
--and a.code is null
--= 558477805 --and pr.alc_code= '0015835000001951700'  
--and aat.licensing = '1' --�������������
and (aat.licensing = '0'/* OR aat.licensing is null*/) -- ���������������




-- ������������� �������� � �������� ������
select distinct
       doc.id_document
       , ws.fullname
       , dhed.rests_date
       , pr.full_name
       , pr.alc_code
       ,ns.art_code
       ,a.id_art
       , dscon.quantity
     --  , m.vstring
       ,aat.licensing
       ,a.CODE
      -- ,aat.type_name
     --  ,ad.ID_ADD
     ---  ,m.id_art
from whs.document doc
left join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
left join whs.warehouse ws on ws.id_ws = dtb.id_ws
left join doc_egais.replyrests_doc_header_tbl dhed ON dhed.id_Document = dtb.id_document
--left join doc_Egais.Replyrestshop_Doc_Content_Tbl dscon ON dscon.id_document = dtb.id_document
left join doc_egais.replyrests_doc_rest_tbl dscon ON dscon.id_document = dtb.id_document
left join doc_egais.product_tbl pr ON pr.id_product = dscon.id_product
left join retail.nsi_link_vw ns on pr.alc_code= ns.alc_code
left join whs.article a on a.code= ns.art_code
left join whs.art_moreinfo m on m.id_art= a.id_art
left join whs.addition ad on ad.id_add = m.id_add
LEFT JOIN whs.alc_art_type aat on aat.alc_art_code = m.vstring
WHERE
doc.id_document= 660816950 -- and pr.alc_code= '0015835000001951700'  
--and a.code is null
--= 558477805 --and pr.alc_code= '0015835000001951700'  
--and aat.licensing = '1' --�������������
and (aat.licensing = '0'/* OR aat.licensing = null*/) -- ���������������


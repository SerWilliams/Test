select distinct
 /*+ materialize
  leading(sdt op top war ka)
  index(sdt SEND_DOC_STTP_IDX)
  index(op p_operation) use_nl(op) 
  index(top P_TYPEOP) use_nl(top)
  use_nl(op war) use_nl(op ka)*/
sdt.add_date
,sdt.last_work_date   as last_work_date
,ka.id_contr          as ka_id            
,ka.code              as ka_code
,ka.name              as ka_name
,op.ID_OP             as id_op
,op.OPNUMBER          as opnumber
,op.OPDATE            as opdate
,op.OPSUM             as opsum
,war.fullname         as oo_fullname
,war.code             as oo_code
,op.id_top            as id_top
,top.fullname         as top_fullname
,sdt.id_Send_status   as id_send_status
,sdt.id_document      as id_document
,sdt.id_doctype       as id_doctype
,sdt.id_ticket        as id_ticket
,sdt.id_ticket1       as id_ticket1
,sdt.description      as status_description
from whs.operation op
join whs.op_art oa on oa.ID_OP = op.id_op
join whs.article a on a.ID_ART = oa.ID_ART
join whs.art_moreinfo am on am.id_art = a.id_art
join whs.addition adi on adi.ID_ADD = am.id_add
join whs.op_moreinfo omi on omi.id_op = op.ID_OP
join whs.typeop top on top.ID_TOP = op.ID_TOP
join whs.warehouse war on war.id_ws=nvl(op.id_wsi,op.id_wso)
left join whs.contractor ka on ka.id_contr = op.ID_CONTR
left join doc_egais.send_doc_egais_tbl sdt on sdt.id_send_base = op.ID_OP
where war.lg1 = 601-- ��--(select mm_code from dat)--'372672'
and op.OPDATE between trunc (to_date ('01.01.2016'),'DDD') and trunc (to_date (sysdate),'DDD')--to_date (sysdate)
and am.vstring not like '000' -- ���������� ��������������� ����
and adi.name like '���_���'
and (sdt.id_send_status <> 11 
          or (sdt.id_send_status is null and op.opsum <> 0))

--���� �������� ��
SELECT w.code "��� ��", div.CODE "��� �������������", div.NAME "�������� �������������", DS.DATE_START "���� ��������", DS.DATE_END "���� ��������"
FROM WHS.DIVISION DIV
JOIN ONSI_OUT.DIVISION_STORAGE_VW DS ON DIV.ID_DIV = DS.ID_DIV
LEFT JOIN WHS.STORAGE_TBL W ON W.ID_WS=DS.ID_WS
LEFT JOIN WHS.DIV_STATE  DS ON DS.ID_DIV=DIV.ID_DIV AND DS.ID_COND=11
WHERE w.name =  '��������'--w.code='990101'

select c.phones, w.code, w.name from whs.contractor c
join whs.warehouse w on w.id_controwner = c.id_contr
where c.delivaddress like '%��������� %���������%'
and w.lg1 = 201


-- ������ ��������
select distinct
t.id_ws, wh.name, t.tasknumber, t.taskdate, t.id_transfer_task_base, tb.basename, st.id_send_status
, cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment"
, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment"
, case when enwh.id_ws is not null then '���������' else '���������' end as "�� � �������� ���������" 
, case when ex.id_send_base is not null then '��������' else '�� ��������' end as "�������� �� ��������" 
, st.id_document
from doc_egais.reg_TRANSFER_TASK_TBL t
join whs.warehouse wh on wh.id_ws = t.id_ws
join doc_Egais.Reg_Transfer_Task_Base_Tbl tb on tb.id_transfer_task_base = t.id_transfer_task_base
left join doc_egais.send_doc_egais_tbl st on st.id_send_base = t.id_transfer_task
left join doc_Egais.Reg_Transfer_Task_Enablews_Tbl enwh on enwh.id_ws = t.id_ws --����������� � �������� ��
left join doc_egais.exclude_send_data_tbl ex on ex.id_send_base = t.id_transfer_task -- ������� ����������
left join whs.document d on d.id_document = st.id_document
left join whs.docreference df on df.id_doc_master = st.id_document
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
where --wh.code in ('778038','777929','363653','353097','703063','343337','508918','740684','777758','778005','153360','668545','784558','610449','353037','363597','363590','070048','780139','350081','770109','230463','230601','360151','580039','080003','992303','520112','520088','230554','230041','340007')
      wh.id_ws in (1860,4637,17,30472,15625,82916,5335,10386,17700,79425,7838,82611,83407,8834,29246)
and t.id_transfer_task_base in (5,6)
order by t.id_ws, t.taskdate, t.id_transfer_task_base

select * from whs.warehouse w where w.id_ws in (8834), 29246)

-- ������ �������� �������� � �������
select distinct qt.name
, doc.id_Doctype
, dtb.id_ws
, w.name
, doc.username
, doc.*
, dtb.* 
from whs.document doc
join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
join whs.warehouse w on dtb.id_ws=w.id_ws
left join doc_egais.query_doc_header_tbl qh on dtb.id_document=qh.id_document
left join doc_egais.query_type_tbl qt on qh.id_query_type=qt.id_query_type --and qh.id_query_type=7
where
     doc.id_Doctype in  (/*473,*/ 479, 511) --479 ����� 473 ������
     and w.id_ws in   (6723,7118,11111,77388,14936,7370,3198,5555,1301,29043,5352,12030,17591,18086,12454,13175,6969,12320,13637,15999,4343,3737,10629,3751,29643,645,6925,11915,18642,4010,11233,15139,10735,4996,5225,2707,5312,16512,16871,8861,15356,854,6044,11084,16291,14897,15810,18698,29661,30183,30147,11041,30220,12038,14943) -- id_ws ��������
     and dtb.lastdate > trunc(sysdate)-0.5
     --and doc.username in (/*'NAG_M_A', */'ZAYCE_AA')
     order by dtb.id_ws, doc.id_Doctype, doc.id_document, qt.name

--����� �� ����� �������� �� �������
select w.id_ws, w.fullname, q.id_document, d.fsrar_id,
      (select rrs.id_document
         from whs.docreference rf
         join doc_egais.replyrestshop_doc_header_tbl rrs on rrs.id_document = rf.id_doc_depend
        where rf.id_doc_master = q.id_document) id_rest,
      (select rrs.restdate
         from whs.docreference rf
         join doc_egais.replyrestshop_doc_header_tbl rrs on rrs.id_document = rf.id_doc_depend
        where rf.id_doc_master = q.id_document)
 from doc_egais.query_doc_header_tbl q
 join doc_egais.document_tbl d on d.id_document = q.id_document
 join whs.warehouse w on w.id_ws = d.id_ws
where q.id_query_type = 8
  and d.lastdate >= to_date('10.11.2016 15:55:00','dd.mm.yyyy hh24:mi:ss') 
  and w.id_ws in (9845,2935,81864,539,7791,1860,4637,17,30472,8090,15936,83474,5616,15099,15625,80891,82916,2983,3149,5335,10386,17700,79425,79473,7838,17048,80856,82611,83407,8834,29246,2495);

 
-- ����� �� ������ �������� �� ������
select /*+ leading(q, d, w)
           index(q QUERY_DOC_HEADER_QTYPE_IDX)
           index(d DOCUMENT_PK) use_nl(d)
           index(w P_WAREHOUSE) use_nl(w)*/
w.id_ws, w.fullname, q.id_document, d.fsrar_id,
      (select rr.id_document
         from whs.docreference rf
         join doc_egais.replyrests_doc_header_tbl rr on rr.id_document = rf.id_doc_depend
        where rf.id_doc_master = q.id_document) id_rest,
      (select rr.rests_date
         from whs.docreference rf
         join doc_egais.replyrests_doc_header_tbl rr on rr.id_document = rf.id_doc_depend
        where rf.id_doc_master = q.id_document)
 from doc_egais.query_doc_header_tbl q
 join doc_egais.document_tbl d on d.id_document = q.id_document
 join whs.warehouse w on w.id_ws = d.id_ws
where q.id_query_type = 7
  and d.lastdate >= to_date('10.11.2016 15:55:00','dd.mm.yyyy hh24:mi:ss')
  --and d.lastdate < to_date('28.06.2016 17:00:00','dd.mm.yyyy hh24:mi:ss')
  and w.id_ws in (8834)--(9845,2935,81864,539,7791,1860,4637,17,30472,8090,15936,83474,5616,15099,15625,80891,82916,2983,3149,5335,10386,17700,79425,79473,7838,17048,80856,82611,83407,8834,29246,2495);--(/*select id_ws from doc_egais.transfer_shop_idws_tbl*/17336)  


--������� �������� �� �� � ������� ��
begin
doc_egais.support_api.queue_rests_1ws(p_id_ws => 6723);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 6723);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 7118);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 7118);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 11111);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 11111);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 77388);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 77388);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 14936);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 14936);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 7370);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 7370);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 3198);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 3198);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 5555);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 5555);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 1301);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 1301);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 29043);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 29043);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 5352);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 5352);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 12030);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 12030);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 17591);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 17591);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 18086);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 18086);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 12454);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 12454);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 13175);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 13175);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 6969);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 6969);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 12320);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 12320);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 13637);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 13637);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 15999);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 15999);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 4343);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 4343);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 3737);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 3737);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 10629);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 10629);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 3751);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 3751);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 29643);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 29643);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 645);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 645);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 6925);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 6925);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 11915);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 11915);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 18642);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 18642);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 4010);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 4010);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 11233);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 11233);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 15139);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 15139);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 10735);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 10735);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 4996);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 4996);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 5225);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 5225);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 2707);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 2707);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 5312);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 5312);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 16512);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 16512);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 16871);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 16871);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 8861);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 8861);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 15356);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 15356);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 854);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 854);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 6044);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 6044);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 11084);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 11084);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 16291);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 16291);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 14897);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 14897);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 15810);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 15810);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 18698);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 18698);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 29661);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 29661);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 30183);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 30183);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 30147);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 30147);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 11041);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 11041);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 30220);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 30220);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 12038);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 12038);
doc_egais.support_api.queue_rests_1ws(p_id_ws => 14943);
doc_egais.support_api.queue_rests_ts_1ws(p_id_ws => 14943);
end;


 --������� � ����������� ������ �� �������� �� ������ ���-�� ������ � ������� �������� �
select
       doc.id_document
       , ws.fullname
       , dhed.rests_date
       , pr.full_name
       , pr.alc_code
       , dcon.quantity
       , dcon.reg_id_a
       , dcon.reg_id_b
from whs.document doc
left join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
left join whs.warehouse ws on ws.id_ws = dtb.id_ws
left join doc_egais.replyrests_doc_header_tbl dhed ON dhed.id_Document = dtb.id_document
left join doc_egais.replyrests_doc_rest_tbl dcon ON dcon.id_document = dtb.id_document
left join doc_egais.product_tbl pr ON pr.id_product = dcon.id_product
WHERE
doc.id_document = 425729113

























select * from whs.document where id_document = 425731593


-- ������
select * from  doc_egais.wbinformbreg_doc_content_tbl wbd
where reg_id_b = 'FB-000000109074901' 

select * from whs.docreference dref --on wbd.id_document=dref.id_doc_depend
where id_doc_depend in (198515287,198524384)

select * from whs.document d --on dref.id_doc_master=d.id_document
where id_document = 197986425
198524384

/
select c.name, w2.lg1, w.fullname, o.* from whs.operation o
join whs.warehouse w on w.id_ws = nvl (o.id_wso, o.id_wsi)
join whs.contractor c on c.id_contr = o.id_contr
join whs.warehouse w2 on w2.id_controwner = o.id_contr
where o.opguid in (hextoraw ('BFA3A468606F11E696F8F8B1A0A00290'),
hextoraw ('3A6D70188C7D0973E053A2840B0AAC91'),
hextoraw ('3A66397FCB4C1234E053A2840B0A4881'),
hextoraw ('3A6818D4D387123FE053A2840B0A46F0'),
hextoraw ('3A680C365ABA1AD4E053A2840B0A2A59'),
hextoraw ('3A6D57AD74070979E053A2840B0AAB6D'),
hextoraw ('3A7A6817F9252E65E053A2840B0A327B'),
hextoraw ('3A7A756AA4F52E6BE053A2840B0A3C8F'),
hextoraw ('3A79423B0D7A0981E053A2840B0A1A67'),
hextoraw ('3A7DA17B75E17B0FE053A2840B0A93F1'),
hextoraw ('3A6DA15BE8C007EFE053A2840B0A064E'),
hextoraw ('3A6D6CCBFB5A0876E053A2840B0AB9CB'),
hextoraw ('3A6DA15BE87F07EFE053A2840B0A064E'),
hextoraw ('3A6712001FC12EA4E053A2840B0AC5B8'),
hextoraw ('3A7D4B3D66D55585E053A2840B0AC8F2'),
hextoraw ('3A6616608BC32EC4E053A2840B0A2DF5'),
hextoraw ('3A6D57AD73EF0979E053A2840B0AAB6D'),
hextoraw ('3A6712001FAE2EA4E053A2840B0AC5B8'),
hextoraw ('3A651D5E9E4F2EB4E053A2840B0A0965'),
hextoraw ('3A6DA15BE8C407EFE053A2840B0A064E'),
hextoraw ('3A6D57AD73FA0979E053A2840B0AAB6D'),
hextoraw ('3A6D7ECED9680810E053A2840B0AF09B'),
hextoraw ('3A6D8CAD27D307EAE053A2840B0AFDB2'),
hextoraw ('3A68C0C131A21224E053A2840B0A0626'),
hextoraw ('3A6DA15BE8BE07EFE053A2840B0A064E'),
hextoraw ('3A6DA15BE8C207EFE053A2840B0A064E'),
hextoraw ('3A65518CAC2D2EB8E053A2840B0A90DC'),
hextoraw ('3A688C48EA611228E053A2840B0A8D7E'),
hextoraw ('3A7B55D893972E67E053A2840B0AB68C'),
hextoraw ('3A68C0C1319A1224E053A2840B0A0626'),
hextoraw ('3A6D8CAD27E907EAE053A2840B0AFDB2'),
hextoraw ('3A7D4B3D66DA5585E053A2840B0AC8F2'),
hextoraw ('3A7D4B3D66DC5585E053A2840B0AC8F2'),
hextoraw ('3A6DA15BE88A07EFE053A2840B0A064E'),
hextoraw ('3A7A6817F9312E65E053A2840B0A327B'),
hextoraw ('3A7B55D893C82E67E053A2840B0AB68C'),
hextoraw ('3A6D6CCBFB460876E053A2840B0AB9CB'),
hextoraw ('3A6D7212637F09ADE053A2840B0A5890'),
hextoraw ('3A688C48EA4E1228E053A2840B0A8D7E'),
hextoraw ('3A68C0C131AB1224E053A2840B0A0626'),
hextoraw ('3A6D70188CBF0973E053A2840B0AAC91'),
hextoraw ('3A6DD7CC72DC0823E053A2840B0AC168'),
hextoraw ('3A6D6CCBFB6D0876E053A2840B0AB9CB'),
hextoraw ('3A68C0C131AF1224E053A2840B0A0626'),
hextoraw ('3A6D7ECED9480810E053A2840B0AF09B'),
hextoraw ('3A6712001FD52EA4E053A2840B0AC5B8'),
hextoraw ('3A6616608BD02EC4E053A2840B0A2DF5'),
hextoraw ('3A6DC1A202C008C3E053A2840B0A3179'),
hextoraw ('3A65C57F4CA92EC0E053A2840B0A196E'),
hextoraw ('3A6D74E3964608F0E053A2840B0A4044'),
hextoraw ('3A7AC2FD8F8C0866E053A2840B0A3F03'),
hextoraw ('3A7DA3858A275587E053A2840B0AF547'),
hextoraw ('3A6D7212638309ADE053A2840B0A5890'),
hextoraw ('3A6DC1A2026D08C3E053A2840B0A3179'),
hextoraw ('3A6DC1A2028808C3E053A2840B0A3179'),
hextoraw ('3A68C0C1318E1224E053A2840B0A0626'),
hextoraw ('3A7A756AA4C42E6BE053A2840B0A3C8F'),
hextoraw ('3A6D70188CBB0973E053A2840B0AAC91'),
hextoraw ('3A6DC1A2028A08C3E053A2840B0A3179'),
hextoraw ('3A6DC1A2028E08C3E053A2840B0A3179'),
hextoraw ('3A68C0C131BB1224E053A2840B0A0626'),
hextoraw ('3A688C48EA4B1228E053A2840B0A8D7E'),
hextoraw ('3A6D85F9935C0872E053A2840B0A9A09'),
hextoraw ('3A6D8CAD27F107EAE053A2840B0AFDB2'),
hextoraw ('3A6712001FC72EA4E053A2840B0AC5B8'),
hextoraw ('3A7A756AA4DC2E6BE053A2840B0A3C8F'),
hextoraw ('3A6D8A783B0D087EE053A2840B0A5872'),
hextoraw ('3A6DA15BE8B907EFE053A2840B0A064E'),
hextoraw ('3A6D7212637609ADE053A2840B0A5890'),
hextoraw ('3A68C0C1316B1224E053A2840B0A0626'),
hextoraw ('3A6712001F932EA4E053A2840B0AC5B8'),
hextoraw ('3A93238BD70362CFE053A2840B0A9DC7'),
hextoraw ('3A80AFA02D1E2CF1E053A2840B0A7C5C'),
hextoraw ('3A930D12E85F61E0E053A2840B0AC39E'),
hextoraw ('3A9109732E490452E053A2840B0A8F90'),
hextoraw ('3A6D8A783B72087EE053A2840B0A5872'),
hextoraw ('3A93969222E161E8E053A2840B0A4E7D'),
hextoraw ('3A90DDD73A095121E053A2840B0A9F82'),
hextoraw ('3A95AFA243F423E6E053A2840B0AB03D'),
hextoraw ('3A6D8A783B74087EE053A2840B0A5872'),
hextoraw ('3A93238BD75662CFE053A2840B0A9DC7'),
hextoraw ('3A93969222F561E8E053A2840B0A4E7D'),
hextoraw ('3A7EFEFF0CCC2CF9E053A2840B0AEE63'),
hextoraw ('3A8F4C38B4DB045AE053A2840B0A5C90'),
hextoraw ('3A8F4E83A82E046BE053A2840B0A7F55'),
hextoraw ('3A8F40FE6DA9043EE053A2840B0AFA21'),
hextoraw ('3A8D9BC6CD382D34E053A2840B0A8B6C'),
hextoraw ('3A930D12E87861E0E053A2840B0AC39E'),
hextoraw ('3A9549250A8F5C22E053A2840B0A6765'),
hextoraw ('3A8D7104F14C5DF8E053A2840B0A971B'),
hextoraw ('3A95839E6BAD23EEE053A2840B0A9173'),
hextoraw ('3A8F326F5A9A0436E053A2840B0A8F13'),
hextoraw ('3A6D8A783B6F087EE053A2840B0A5872'),
hextoraw ('3A9316C93184620DE053A2840B0ADA79'),
hextoraw ('3A8F315E3380044CE053A2840B0A1130'),
hextoraw ('3A7F0C99D0C42D15E053A2840B0A2C7F'),
hextoraw ('3A8F4E83A826046BE053A2840B0A7F55'),
hextoraw ('3A93969222F761E8E053A2840B0A4E7D'),
hextoraw ('3A6D76EA28C5091CE053A2840B0A8B94'),
hextoraw ('3A95937AFD9B23EAE053A2840B0ADE2A'),
hextoraw ('3A8127D70446103CE053A2840B0A7D00'),
hextoraw ('3A8F315E3375044CE053A2840B0A1130'),
hextoraw ('3A9192C6D26B2D1DE053A2840B0A2347'),
hextoraw ('3A6DC1A2032508C3E053A2840B0A3179'),
hextoraw ('3A8D9BC6CD122D34E053A2840B0A8B6C'),
hextoraw ('3A80EC3536D1103AE053A2840B0AA034'),
hextoraw ('3A932D3B79A861FBE053A2840B0A1264'),
hextoraw ('3A93238BD72262CFE053A2840B0A9DC7'),
hextoraw ('3A93238BD73762CFE053A2840B0A9DC7'),
hextoraw ('3A8F40FE6D98043EE053A2840B0AFA21'),
hextoraw ('3A930D12E85B61E0E053A2840B0AC39E'),
hextoraw ('3A9192C6D2672D1DE053A2840B0A2347'),
hextoraw ('3A9319846B0161DCE053A2840B0A6FC5'),
hextoraw ('3A80B4BECC292D21E053A2840B0ADF86'),
hextoraw ('3A93161E8C5F5C2AE053A2840B0AB1DF'),
hextoraw ('3A8F4E83A828046BE053A2840B0A7F55'),
hextoraw ('3A8F4FCF84C1043AE053A2840B0A23E4'),
hextoraw ('3A8D9BC6CCF92D34E053A2840B0A8B6C'),
hextoraw ('3A9319846AFF61DCE053A2840B0A6FC5'),
hextoraw ('3A8F4FCF84EF043AE053A2840B0A23E4'),
hextoraw ('3A8F4FCF84BF043AE053A2840B0A23E4'),
hextoraw ('3A8D9BC6CCF52D34E053A2840B0A8B6C'),
hextoraw ('3A80AFA02D1C2CF1E053A2840B0A7C5C'),
hextoraw ('3A68C0C131F91224E053A2840B0A0626'),
hextoraw ('3A6D8A783B66087EE053A2840B0A5872'),
hextoraw ('3AA1E7A6034F37C3E053A2840B0AF84A'),
hextoraw ('3AA1D634786337B3E053A2840B0A31E8'),
hextoraw ('3A9F5E80C21737C7E053A2840B0AF913'),
hextoraw ('3AA1BC7D6AD01778E053A2840B0A92EF'),
hextoraw ('3AA1B74061E437BFE053A2840B0A7EE0'),
hextoraw ('3A9D9514AC8837CBE053A2840B0ABDBC'),
hextoraw ('3A9D9DEC2AE837D7E053A2840B0A6E73'),
hextoraw ('3AA1D634787737B3E053A2840B0A31E8'),
hextoraw ('3A9D9DEC2AE637D7E053A2840B0A6E73'),
hextoraw ('3AA1E7A6037037C3E053A2840B0AF84A'),
hextoraw ('3AA1E7A6037237C3E053A2840B0AF84A'),
hextoraw ('3A9D9DEC2AE137D7E053A2840B0A6E73'),
hextoraw ('3AA1BFD9C9FE1776E053A2840B0A7028'),
hextoraw ('3AA1D634785437B3E053A2840B0A31E8'),
hextoraw ('3AB83644662946C6E053A2840B0AEA66'),
hextoraw ('3AB8BB3B94CF4789E053A2840B0A2784'),
hextoraw ('3AB616817B4B64FCE053A2840B0AC98E'),
hextoraw ('3AB7FEDA1DAD651CE053A2840B0A887D'),
hextoraw ('3AB7EC29AAD646A7E053A2840B0AC35B'),
hextoraw ('3AB616817B3864FCE053A2840B0AC98E'),
hextoraw ('3AB6B513CF886518E053A2840B0A05F0'),
hextoraw ('3AB84E7C7E2A479FE053A2840B0AB104'),
hextoraw ('3AB63F143B8C6520E053A2840B0A4F3D'),
hextoraw ('3AB834BE82152BCCE053A2840B0A53BC'),
hextoraw ('3AB58E7406C246BBE053A2840B0AB2D3'),
hextoraw ('3AB83644662546C6E053A2840B0AEA66'),
hextoraw ('3AB83644662746C6E053A2840B0AEA66'),
hextoraw ('3AB83644663746C6E053A2840B0AEA66'),
hextoraw ('3AB83644663B46C6E053A2840B0AEA66'),
hextoraw ('3AB5D074767D6522E053A2840B0AF2D9'),
hextoraw ('3AB8BB3B94E24789E053A2840B0A2784'),
hextoraw ('3AB834BE81FE2BCCE053A2840B0A53BC'),
hextoraw ('3AB7FEDA1DBD651CE053A2840B0A887D'),
hextoraw ('3AB649335CFD6510E053A2840B0A12AB'),
hextoraw ('3AB84E7C7E24479FE053A2840B0AB104'),
hextoraw ('3AB616817B4764FCE053A2840B0AC98E'),
hextoraw ('3AB63F143B796520E053A2840B0A4F3D'),
hextoraw ('3ABA3E4991577A0CE053A2840B0A9F52'),
hextoraw ('3AB7ED74A38246CEE053A2840B0A4D90'),
hextoraw ('3AB616817B4964FCE053A2840B0AC98E'),
hextoraw ('3AB7FEDA1DAF651CE053A2840B0A887D'),
hextoraw ('3AB84E7C7E21479FE053A2840B0AB104'),
hextoraw ('3B2EEA2F761B1A77E053A2840B0AF3D7'),
hextoraw ('3B34E943DA597A46E053A2840B0A9330'),
hextoraw ('571A90606EB511E62D8B0025901E64D2'),
hextoraw ('3B48F93BA62C4CBEE053A2840B0A1D6B'),
hextoraw ('3B588A49770729C6E053A2840B0AC30C'),
hextoraw ('3B4A7623985D0AF8E053A2840B0AB887'),
hextoraw ('3B5AFDB111AF32CFE053A2840B0A4BFD'),
hextoraw ('3B48D8D096B408A2E053A2840B0AEF22'),
hextoraw ('3B567D29C3E407F1E053A2840B0A6794'),
hextoraw ('3B34B57B0E74058CE053A2840B0ADED7'),
hextoraw ('3B4A7623985F0AF8E053A2840B0AB887'),
hextoraw ('3B48F361EF1807B1E053A2840B0AFDE1'),
hextoraw ('3B490F23E9BD0883E053A2840B0A52BE'),
hextoraw ('3B588A49771429C6E053A2840B0AC30C'),
hextoraw ('3B588A49771629C6E053A2840B0AC30C'),
hextoraw ('3B48F361EF2807B1E053A2840B0AFDE1'),
hextoraw ('3B4AB6EDDCC30B25E053A2840B0AB494'),
hextoraw ('3B48DEEA24590710E053A2840B0AFB15'),
hextoraw ('3B48DEEA24610710E053A2840B0AFB15'),
hextoraw ('3B4AB6EDDCDC0B25E053A2840B0AB494'),
hextoraw ('3B48F361EF3E07B1E053A2840B0AFDE1'),
hextoraw ('3B48F93BA6284CBEE053A2840B0A1D6B'),
hextoraw ('3B4A762398590AF8E053A2840B0AB887'),
hextoraw ('3B4ADAE8AE7D0B21E053A2840B0AF5B7'),
hextoraw ('3B48F361EF4007B1E053A2840B0AFDE1'),
hextoraw ('3B46FE4746A24CF1E053A2840B0A9290'),
hextoraw ('3B490BB60A0F07D1E053A2840B0A61E5'),
hextoraw ('3B588A49771229C6E053A2840B0AC30C'),
hextoraw ('3B5B1BB51BA632B7E053A2840B0AF834'),
hextoraw ('3B46FE4746A04CF1E053A2840B0A9290'),
hextoraw ('3B567D29C3D007F1E053A2840B0A6794'),
hextoraw ('3B5AFDB111B232CFE053A2840B0A4BFD'),
hextoraw ('3B5B0099E0A032C1E053A2840B0A6AB4'),
hextoraw ('3B58744B1EB8759AE053A2840B0A78A9'),
hextoraw ('3B4ADAE8AE680B21E053A2840B0AF5B7'),
hextoraw ('3B49C40238DE07CDE053A2840B0A7CCB'),
hextoraw ('3B48B7B7447307ABE053A2840B0A5380'),
hextoraw ('3B4AADE5E6020AFAE053A2840B0A524E'),
hextoraw ('3B34ACD629230568E053A2840B0A29DB'),
hextoraw ('3B482CFE53964CF9E053A2840B0AF913'),
hextoraw ('3B34B57B0E70058CE053A2840B0ADED7'),
hextoraw ('3B3358C27C7E05B2E053A2840B0A783E'),
hextoraw ('3B5912C647CA29BEE053A2840B0A08A8'),
hextoraw ('3B48D07B2C8D08B1E053A2840B0A9D4C'),
hextoraw ('3B4ADAE8AE8A0B21E053A2840B0AF5B7'),
hextoraw ('3B4A6B3174A30B23E053A2840B0A3241'),
hextoraw ('3B34ACD629250568E053A2840B0A29DB'),
hextoraw ('3B227CC493112D55E053A2840B0AF1F5'),
hextoraw ('3B20B546A8BF4A65E053A2840B0AF0DF'),
hextoraw ('3B20B546A8D64A65E053A2840B0AF0DF'),
hextoraw ('3B34ACD629300568E053A2840B0A29DB'),
hextoraw ('3B58744B1EA4759AE053A2840B0A78A9'),
hextoraw ('3B46FE4746C34CF1E053A2840B0A9290'),
hextoraw ('3B20B546A8D34A65E053A2840B0AF0DF'),
hextoraw ('3B20B546A8AD4A65E053A2840B0AF0DF'),
hextoraw ('3B567D29C3A807F1E053A2840B0A6794'),
hextoraw ('3B4A6B3174970B23E053A2840B0A3241'),
hextoraw ('3B48F93BA6214CBEE053A2840B0A1D6B'),
hextoraw ('3B48F93BA62E4CBEE053A2840B0A1D6B'),
hextoraw ('3B588A49770E29C6E053A2840B0AC30C'),
hextoraw ('3B48F361EF4407B1E053A2840B0AFDE1'),
hextoraw ('3B48F361EFD807B1E053A2840B0AFDE1'),
hextoraw ('3B6E1116EED924DAE053A2840B0A5AA0'),
hextoraw ('3B6F6147CB0E24D4E053A2840B0A68AE'),
hextoraw ('3B5F5C1F9B956983E053A2840B0A1A92'),
hextoraw ('3B567D29C47607F1E053A2840B0A6794'),
hextoraw ('3B490F23E9E40883E053A2840B0A52BE'),
hextoraw ('3B48F361EF8C07B1E053A2840B0AFDE1'),
hextoraw ('3B5AFDB111DD32CFE053A2840B0A4BFD'),
hextoraw ('3B5F38A782E86997E053A2840B0A0528'),
hextoraw ('3B48CF7733380744E053A2840B0A21B7'),
hextoraw ('3B490BB60A2807D1E053A2840B0A61E5'),
hextoraw ('3B6C883689901C52E053A2840B0AC03F'),
hextoraw ('3B4A7623987F0AF8E053A2840B0AB887'),
hextoraw ('3B490BB60A2B07D1E053A2840B0A61E5'),
hextoraw ('3B4A7623987D0AF8E053A2840B0AB887'),
hextoraw ('3B5F38A782F66997E053A2840B0A0528'),
hextoraw ('3B48F93BA64C4CBEE053A2840B0A1D6B'),
hextoraw ('3B4A6B3174DE0B23E053A2840B0A3241'),
hextoraw ('3B48F361EF6C07B1E053A2840B0AFDE1'),
hextoraw ('3B5F38A782F26997E053A2840B0A0528'),
hextoraw ('3B567D29C49407F1E053A2840B0A6794'),
hextoraw ('3B5F5C1F9BC16983E053A2840B0A1A92'),
hextoraw ('3B59E3AB162E29C2E053A2840B0A3AB7'),
hextoraw ('3B490F23E9F00883E053A2840B0A52BE'),
hextoraw ('3B48F361EF7607B1E053A2840B0AFDE1'),
hextoraw ('3B59E3AB163229C2E053A2840B0A3AB7'),
hextoraw ('3B6EB235A28124D8E053A2840B0AB2EB'),
hextoraw ('3B4A762398670AF8E053A2840B0AB887'),
hextoraw ('3B4ADAE8AEA30B21E053A2840B0AF5B7'),
hextoraw ('3B48F93BA64A4CBEE053A2840B0A1D6B'),
hextoraw ('3B6E434444D324EEE053A2840B0AC69F'),
hextoraw ('3B490F23E9E60883E053A2840B0A52BE'),
hextoraw ('3B4A7623986B0AF8E053A2840B0AB887'),
hextoraw ('3B48CF77333A0744E053A2840B0A21B7'),
hextoraw ('3B6CFBD5CC721C5AE053A2840B0AF36A'),
hextoraw ('3B5F08AD7E636967E053A2840B0AD02A'),
hextoraw ('3B48F361EFDA07B1E053A2840B0AFDE1'),
hextoraw ('3B48F93BA6354CBEE053A2840B0A1D6B'),
hextoraw ('3B4AB6EDDD4B0B25E053A2840B0AB494'),
hextoraw ('3B48DEEA24770710E053A2840B0AFB15'),
hextoraw ('3BD13E0F865D30F7E053A2840B0AB586'),
hextoraw ('3BBBB74CBF283368E053A2840B0AEA90'),
hextoraw ('3BD17078CE3533DAE053A2840B0A1278'),
hextoraw ('3BBB2A488E453277E053A2840B0ACBC2'),
hextoraw ('3BD14CE03BA53240E053A2840B0AE92E'),
hextoraw ('3BD14C64CE05339FE053A2840B0A8D1E'),
hextoraw ('3BBB6C68A20A3360E053A2840B0A8F65'),
hextoraw ('3BD144F4E41C32C6E053A2840B0A1DDE'),
hextoraw ('3BD144DA60A5329CE053A2840B0A1C9B'),
hextoraw ('3BD13F789BBD31FCE053A2840B0A945F'),
hextoraw ('3BE347A98CED6FD4E053A2840B0A9A29'),
hextoraw ('67D2605A74EA11E6CCB0002590E49BAC'),
hextoraw ('3BE58C18C1027A45E053A2840B0A83DE'),
hextoraw ('3BE57A477F207A7BE053A2840B0AE49A'),
hextoraw ('3BE93C8DE5623A12E053A2840B0A6030'),
hextoraw ('3BE5D8FDA7FE7A00E053A2840B0A883C'),
hextoraw ('3BBB6C68A27A3360E053A2840B0A8F65'),
hextoraw ('3BE92083D4BA3A0EE053A2840B0AFDCF'),
hextoraw ('3BE5AC0F2F337A11E053A2840B0A4A17'),
hextoraw ('3BE58260795C7A7FE053A2840B0ABD95'),
hextoraw ('3BE5770E1DBA7A25E053A2840B0A4CE2'),
hextoraw ('3BBBB74CBFF33368E053A2840B0AEA90'),
hextoraw ('3BBB6C68A2763360E053A2840B0A8F65'),
hextoraw ('3BE5CF5EE34C7A37E053A2840B0A9646'),
hextoraw ('3BC29A571F8A325BE053A2840B0AC8EF'),
hextoraw ('3BE5AC0F2F3B7A11E053A2840B0A4A17'),
hextoraw ('3BE93C8DE5603A12E053A2840B0A6030'),
hextoraw ('3BF7EA29328C69CAE053A2840B0A8B1A'),
hextoraw ('3BF7AF7A6A61694FE053A2840B0AAF3E'),
hextoraw ('3BEFABF376B4497EE053A2840B0ABC6A'),
hextoraw ('3BEA53F07EE2391DE053A2840B0A8E35'),
hextoraw ('3BF80928C48F4965E053A2840B0A9598'),
hextoraw ('3BD14C64CEFF339FE053A2840B0A8D1E'),
hextoraw ('3BFA9415D65E7B26E053A2840B0A5D93'),
hextoraw ('3C00303EC9453B9DE053A2840B0AE77B'),
hextoraw ('3C0F0CB622B2157CE053A2840B0AEA02'),
hextoraw ('3C23B495701640CFE053A2840B0A378A'),
hextoraw ('3C208FADD83A07EBE053A2840B0A28E5'),
hextoraw ('3C25A9BA3DE150DEE053A2840B0A6EFB'),
hextoraw ('0BBCEA2E80C011E61DBC0025901D212A'))
/

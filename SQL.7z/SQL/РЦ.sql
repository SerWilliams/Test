﻿--------для проверки ролей----------------------------------------------
select * from DBA_tab_PRIVS where grantee = 'EGAIS_RW'; --нет прав

select * from acan.cnb_art_tbl;

------------------------------------------------------------------------ 
select * from DBA_tab_PRIVS where grantee ='SUPPORT_DS'; --нет прав

 select * from whs.operation ww
join whs.op_art qq on qq.id_op = ww.id_op
  join whs.article tt on tt.id_art = qq.id_art
  join doc_egais.send_doc_egais_tbl yy on yy.id_send_base = ww.id_op
where ww.opdate > '01.07.2016'
and ww.id_top = 1
--and  ww.opnumber like 'Тул%'
and id_send_base <> 11
and ww.status like  'f';

select * from whs.opstatus
 
 
 --Просмотр имеющихся прав:

select dtp.grantee "Роль",dtp.owner "Создатель",dtp.table_name "Таблица",dtp.privilege "Привилегии" from dba_tab_privs dtp
where dtp.grantee in 'SUPPORT_DS' -- для просмотра таблиц, на которые ест ьправа на чтение у известной роли
and dtp.privilege in ('UPDATE','DELETE','INSERT','EXECUTE')

select * from acan.cnb_header_tbl

update acan.constant_tbl c set c.vnumber = 0 where c.name = 'cnb_enabled';
commit;

update acan.cnb_header_tbl h set h.isactive = 0 where h.isactive = 1;
commit;

select * from whs.warehouse
where id_ws = 3952

----
begina
doc_egais.job_waybillact_3_to_1
end;

----Местные приходы ГМ----------------------------------------------------------
with agg as
(select  /*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/
   st.id_send_status
  ,count(*) cnt
    from doc_egais.send_doc_egais_tbl ss
    join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status
    join whs.operation o on o.id_op = ss.id_send_base
    join whs.contractor c2 on c2.id_contr = o.id_contr
    left join whs.document wd on wd.id_document = ss.id_document
    left join doc_egais.ticket_doc_header_tbl th on th.id_document = ss.id_ticket
    left join doc_egais.ticket_doc_opresult_tbl t0 on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
   left join doc_egais.ticket_doc_result_tbl t1 on t1.id_ticket_doc_result = th.id_ticket_doc_result
    join whs.warehouse w on w.id_ws = o.id_wsi
                        and w.lg1  in (201/*гм*/)
     join whs.typeop tt on tt.id_top = o.id_top
                      and upper(tt.fullname) like upper('Приход%Местный')
  where o.opdate between date '2016-04-01' and date '2016-06-30'
     and ss.id_send_type = 1
     and ss.id_send_status <> 11
     and ss.id_send_status <> 12
    group by st.id_send_status)
select st.name
      ,st.code
      ,a.cnt
  from agg                                 a
      ,doc_egais.send_doc_status_egais_tbl st
where a.id_send_status(+) = st.id_send_status
--------------------------------------------------------------------------------
----Местные приходы ММ----------------------------------------------------------
with agg as
(select  /*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/
   st.id_send_status
  ,count(*) cnt
    from doc_egais.send_doc_egais_tbl ss
    join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status
    join whs.operation o on o.id_op = ss.id_send_base
    join whs.contractor c2 on c2.id_contr = o.id_contr
    left join whs.document wd on wd.id_document = ss.id_document
    left join doc_egais.ticket_doc_header_tbl th on th.id_document = ss.id_ticket
    left join doc_egais.ticket_doc_opresult_tbl t0 on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
    left join doc_egais.ticket_doc_result_tbl t1 on t1.id_ticket_doc_result = th.id_ticket_doc_result
    join whs.warehouse w on w.id_ws = o.id_wsi
                        and w.lg1  in (101/*мм*/)
     join whs.typeop tt on tt.id_top = o.id_top
                      and upper(tt.fullname) like upper('Приход%Местный')
-- where o.opdate >= date '2016-01-01' 
  where o.opdate between date '2016-07-01' and date '2016-09-26'
     and ss.id_send_type = 1
     and ss.id_send_status <> 11
     and ss.id_send_status <> 12
    group by st.id_send_status)
select st.name
      ,st.code
      ,a.cnt
  from agg                                 a
      ,doc_egais.send_doc_status_egais_tbl st
where a.id_send_status(+) = st.id_send_status

 
 
 select * from doc_egais.send_doc_status_egais_tbl
-----------------Приходы ММ/ГМ-------------------------------
select
w.lg1,
st.id_send_status,
ss.id_send_base
     case when  o.opdate between  date '2016-01-01' and date '2016-03-31' then 'Первый квартал' 
   when   o.opdate between date '2016-04-01' and date '2016-06-30'    then 'Второй квартал' 
    when   o.opdate between date '2016-07-01' and date '2016-10-01' then 'Третий квартал' end "Квартал"
  from doc_egais.send_doc_egais_tbl ss
  join doc_egais.send_doc_status_egais_tbl st
    on st.id_send_status = ss.id_send_status
  join whs.operation o
    on o.ID_OP = ss.id_send_base
  join whs.contractor c2
    on c2.id_contr = o.ID_CONTR
  left join whs.docreference df
    on df.id_doc_master = ss.id_document
  left join whs.document wd
    on wd.id_document = ss.id_document
  left join doc_egais.ticket_doc_header_tbl th
    on th.id_document = nvl(ss.id_ticket, df.id_doc_depend)
  left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
  left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
  join whs.warehouse w
    on w.id_ws = o.ID_WSI
and w.lg1  in (101,201)
     join whs.typeop tt on tt.id_top = o.id_top
                      and upper(tt.fullname) like upper('Приход%Местный') 
 where  o.opdate >=  date '2016-01-01'
   and ss.id_send_type = 1
and ss.id_send_status <> 11   
and ss.id_send_status <> 12  



-----------------------------местные приходы--------------2291 секунд-------------------------------------    
select w.lg1, ss.id_send_status, count(1), 
case
             when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1й квартал'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2й квартал'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3й квартал'
             end time_queue
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st  on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.warehouse w  on w.id_ws = o.ID_WSI and w.lg1  in (101,201)
join whs.typeop tt on tt.id_top = o.id_top and upper(tt.fullname) like upper('Приход%Местный') 
where  o.opdate >= '01.04.2016'
---o.OPDATE between  '01.07.2016' and '25.07.2016'
and ss.id_send_type = 1
and ss.id_send_status <> 11   
and ss.id_send_status <> 12 
group by case
             when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1й квартал'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2й квартал'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3й квартал'
             end, w.lg1, st.Name, ss.id_send_status;
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
------------для просмотра очереди-----------------------------------------------
--------------------------------------------------------------------------------
select *
--st.id_send_status--, --count (opnumber)
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.warehouse w on w.id_ws = o.ID_WSI and w.lg1 = 601
join whs.typeop tt on tt.ID_TOP = o.ID_TOP --and UPPER(tt.FULLNAME) like UPPER('Рас%')
where o.OPDATE between  '01.07.2016' and '28.09.2016'
and ss.id_send_type in (1)
--and o.id_top in (473)
--and  w.fullname like ('%Сеть РЦ∙РЦ∙РЦ Тюмень%')
and st.id_send_status in (3,9,1,7,10)
Group by  st.id_send_status
Order by 1,2;

select * from doc_egais.send_doc_status_egais_tbl



------------------------межсклады-------6256 сек------------------------------
select o.id_top, st.Name, ss.id_send_status, count (opnumber),
case
             when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1й квартал'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2й квартал'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3й квартал'
             end "Квартал"
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st  on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.typeop tt on tt.ID_TOP = o.ID_TOP
where   o.opdate >= '01.07.2016'
--o.OPDATE between  '01.07.2016' and '25.07.2016'
and o.id_top in (477,473)
and ss.id_send_status in (3,9,1,7,10,41)
Group by case
             when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1й квартал'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2й квартал'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3й квартал'
             end, o.id_top, st.Name,  ss.id_send_status;
----------===========            
             select * from whs.typeop
             where id_top = 477
-------------------------------------------------------
select o.id_top, o.id_op, st.Name, ss.id_send_status, count (opnumber)
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st  on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.typeop tt on tt.ID_TOP = o.ID_TOP
where   o.opdate >= '01.07.2016'
---o.OPDATE between  '01.07.2016' and '25.07.2016'
and o.id_top in (477,473)
and ss.id_send_status in (3,9,1,7,10,41)
Group by  o.id_top, st.Name, o.id_op, ss.id_send_status;



select * from whs.typeop
where id_top = 477
-------------------------------------------------------------------------
---------Для расходов----------------------------------------------------------------
select st.name,st.id_send_status,count(ss.id_send_base)"Итог",
case when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1й квартал'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2й квартал'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3й квартал'
             end "Квартал"
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.warehouse w on w.id_ws = o.ID_WSo and w.lg1 = 601
join whs.typeop tt on tt.ID_TOP = o.ID_TOP 
where o.OPDATE >= '01.07.2016' 
and o.id_top = 169
and ss.id_send_status <> 11
and ss.id_send_status <> 12
and ss.id_send_status <> 4
and ss.id_send_status <> 8
Group by  case when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1й квартал'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2й квартал'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3й квартал'
             end,
st.id_send_status, st.name;


---------------------------------------------------------------------------------------------------

select ee.id_send_status, ee.id_send_base    
from doc_egais.send_doc_egais_tbl ee
join whs.operation oo on oo.id_op = ee.id_send_base
join whs.warehouse w on w.id_ws = nvl(oo.ID_WSI,oo.id_wso) and w.lg1 = 601
where oo.opdate >= '01.01.2016'
and oo.id_top = 169 -- выставить тип операции

group by ee.id_send_status
--and ee.id_send_status in (3) -- выставить статус


select 'OPNUMBER'||';'||'OPDATE'||';'||'CODE'||';'||'LG1' from dual;
with t as(
select op.ID_OP, op.opnumber, op.opdate,  cc.fullname as cname,cc.code, w1.lg1,
w.fullname as wname, oa.id_art, max(oa.QUANTITY) as op_quant, sum(aop.quantity) as an_quant from whs.operation op
left join whs.contractor cc on cc.id_contr=op.id_contr
left join whs.warehouse w on w.id_ws=op.id_wso
left join whs.warehouse w1 on  trim(w1.code) = trim(cc.code)
left join whs.op_art oa on oa.ID_OP = op.ID_OP
left join acan.analyticopart_tbl aop on op.opguid=aop.opguid and oa.ID_ART=aop.id_art
where --trim(op.opnumber) = '560186A1129' 
 --and
op.id_top = 169
and op.opdate between '01.07.2016' and '27.07.2016'
and  substr(op.opnumber,7,1)  like 'A'
group by op.ID_OP, oa.id_art, op.opnumber, cc.fullname, w.fullname, op.opdate, cc.code, w1.lg1
), a as(
select
t.opnumber,
t.opdate,
t.code,
t.lg1
from t
group by t.opnumber, t.opdate, t.code, t.lg1
having sum(t.op_quant) <> sum(nvl(t.an_quant,0))
)
select opnumber||';'||opdate||';'|| trim(code)||';'|| lg1
from a;




select /*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/ tt.FULLNAME, st.id_send_status, st.name, 
--w.code "W_O_Code", 
w.fullname "W_O_fullname", 
o.OPDATE, o.OPNUMBER,
wd.docnumber, wd.docdate, c2.code, c2.name, c2.inn, c2.kpp, ss.description,
cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment", 
cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment", ss.last_work_date, 
o.ID_TOP, o.ID_OP from doc_egais.send_doc_egais_tbl ss join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status 
join whs.operation o on o.ID_OP = ss.id_send_base join whs.contractor c2 on c2.id_contr = o.ID_CONTR 
left join whs.docreference df on df.id_doc_master = ss.id_document
left join whs.document wd on wd.id_document = ss.id_document
left join doc_egais.ticket_doc_header_tbl th on th.id_document = nvl(ss.id_ticket, df.id_doc_depend) 
left join doc_egais.ticket_doc_opresult_tbl t0 on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult 
left join doc_egais.ticket_doc_result_tbl t1 on t1.id_ticket_doc_result = th.id_ticket_doc_result 
join whs.warehouse w on w.id_ws = o.ID_WSI and w.lg1 in (101,201)
join whs.typeop tt on tt.id_top = o.id_top and upper(tt.fullname) like upper('Приход%Местный') where o.OPDATE >= '01.01.2016' and ss.id_send_type = 1 
and ss.id_send_status <> 11 and w.fullname like 'Сеть МД%' order by o.opdate
-----------------------

----Выборка проблемных операций без агрегаций
----Выборка проблемных операций без агрегаций (колличество)
SELECT  ws2.lg1, sdt2.id_send_status, count (sdt.id_send_base)
FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sdt1 on sdt1.id_send_status =sdt.id_send_status 
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1
left join whs.docreference df ON df.id_doc_master = sdt2.id_document
left join DOC_EGAIS.Ticket_Doc_Header_Tbl tk ON Tk.Id_Document = Df.Id_Doc_Depend
left join DOC_EGAIS.Ticket_Doc_Result_Tbl tor ON Tor.Id_Ticket_Doc_Result = Tk.Id_Ticket_Doc_Result
JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate between  '01.04.2016' and '30.06.2016'-- and op.opdate < to_date(sysdate-2)
-->= '20.05.2016' and op.opdate < to_date(sysdate-2)
and ws.lg1=601
and op.id_top = 169
and ws2.lg1 in (101)
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top   in (1,17,634,635)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is null)
group by  ws2.lg1, sdt1.name, sdt2.id_send_status;

-----------------------------в разрезе операций---------------------------
---------------Выборка проблемных операций без агрегаций
SELECT sdt2.id_send_status, count (op.id_op)
FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sdt1 on sdt1.id_send_status =sdt.id_send_status 
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1
--left join whs.docreference df ON df.id_doc_master = sdt2.id_document
JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate >= '01.07.2016'
--between  '01.07.2016' and '25.07.2016'-- and op.opdate < to_date(sysdate-2)
-->= '20.05.2016' and op.opdate < to_date(sysdate-2)
and ws.lg1=601
and op.id_top = 169
--and ws2.lg1 in (101)
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top  in (1)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is  null)
and sdt2.id_send_status is not null
group by sdt2.id_send_status


select *
  from acan.analytic_service_monitor_tbl sm
where --sm.alarm_status = 1
--and 
 sm.CHECK_DATE between  sysdate-1/24 and sysdate
order by sm.check_date desc
         ,sm.name_format
         ,sm.request_type; 
         
         
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------Корп.Приходы------------------------------------------------
SELECT ws2.lg1, sdt2.id_send_status, count (op2.id_op) "Итог",
case when  op.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1й квартал'
             when op.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2й квартал'
               when op.opdate between to_date('01.07.2016') and to_date('30.09.2016') then '3й квартал'
             when op.opdate between to_date('01.10.2016') and to_date('31.12.2016') then '4й квартал'
             end "Квартал"
  FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sdt1 on sdt1.id_send_status =sdt.id_send_status 
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1
left join whs.docreference df ON df.id_doc_master = sdt2.id_document
left join DOC_EGAIS.Ticket_Doc_Header_Tbl tk ON Tk.Id_Document = Df.Id_Doc_Depend
left join DOC_EGAIS.Ticket_Doc_Result_Tbl tor ON Tor.Id_Ticket_Doc_Result = Tk.Id_Ticket_Doc_Result
JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate  between '01.01.2016' and trunc(sysdate-1)
and ws.lg1=601
and op.id_top = 169
and ws2.lg1 in (101,201)
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top   in (1)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is  null)
and sdt2.id_send_status is not null
and sdt2.id_send_status <> 8
group by case when  op.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1й квартал'
             when op.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2й квартал'
             when op.opdate between to_date('01.07.2016') and to_date('30.09.2016') then '3й квартал'
             when op.opdate between to_date('01.10.2016') and to_date('31.12.2016') then '4й квартал'
             end,
ws2.lg1, sdt1.name, sdt2.id_send_status;



SELECT DISTINCT  
--GA.FULLNAME "Группа по виду",
AKL.CODE_EGAIS "Кол-во кодов ЕГАИС", A.NAME "Наименование", a.code,
count(A.CODE)  "Код товара"  
FROM WHS.ARTICLE_KISCONTR_LINK AKL 
JOIN WHS.ARTICLE A   ON A.ID_ART=AKL.ID_ARTICLE 
JOIN WHS.LINK_ART_ALC_TYPE M1 ON M1.ID_ART=A.ID_ART AND SYSDATE BETWEEN  M1.BEGIN_DATE AND NVL(M1.END_DATE, SYSDATE+1) 
JOIN WHS.ALC_ART_TYPE A1 ON M1.ID_ALC_ART_TYPE=A1.ID_ALC_ART_TYPE AND A1.DECLARING=1 
JOIN WHS.GROUP_ART GA   ON A.ID_GROUP=GA.ID_GROUPART 
WHERE AKL.CODE_EGAIS<>'0'  
AND AKL.CODE_EGAIS IS NOT NULL 
having count(A.CODE)>1
group by --GA.FULLNAME, 
AKL.CODE_EGAIS, A.NAME, a.code

LEFT JOIN ONSI_EGAIS.ALC_PROD_PROV_LINK_vw APPL ON AKL.ID_ARTICLE_KISCONTR_LINK=APPL.ID_ARTICLE_KISCONTR_LINK

SELECT AKL.CODE_EGAIS, K.INN, K.KPP, A.ID_ART, A.CODE, A.NAME,
K.NAME, APPL.ID_ARTICLE_KISCONTR_LINK as "Есть связь с товаром ЕГАИС"
FROM WHS.ARTICLE_KISCONTR_LINK AKL
JOIN WHS.ARTICLE A   ON A.ID_ART=AKL.ID_ARTICLE
JOIN WHS.KISCONTR K ON K.ID_KISCONTR=AKL.ID_KISCONTR
LEFT JOIN ONSI_EGAIS.ALC_PROD_PROV_LINK_vw APPL ON AKL.ID_ARTICLE_KISCONTR_LINK=APPL.ID_ARTICLE_KISCONTR_LINK --order by 3;
WHERE --a.code in ('1000136583')
--a.id_art in (179159) 
--and
AKL.CODE_EGAIS IS NOT NULL 
and AKL.CODE_EGAIS ='177219000002322080'



-----------для поиска товаров----------------
with  code as (
SELECT DISTINCT 
/*GA.FULLNAME "Группа по виду", A.CODE "Код товара", A.NAME "Наименование",*/
AKL.CODE_EGAIS--,  --count (DISTINCT (A.CODE))
FROM WHS.ARTICLE_KISCONTR_LINK AKL
  JOIN WHS.ARTICLE A   ON A.ID_ART=AKL.ID_ARTICLE
  JOIN WHS.LINK_ART_ALC_TYPE M1 ON M1.ID_ART=A.ID_ART AND SYSDATE BETWEEN  M1.BEGIN_DATE AND NVL(M1.END_DATE, SYSDATE+1)
  JOIN WHS.ALC_ART_TYPE A1 ON M1.ID_ALC_ART_TYPE=A1.ID_ALC_ART_TYPE AND A1.DECLARING=1
  JOIN WHS.GROUP_ART GA   ON A.ID_GROUP=GA.ID_GROUPART
WHERE AKL.CODE_EGAIS<>'0' 
  AND AKL.CODE_EGAIS IS NOT NULL
  having count (DISTINCT A.CODE)>1
group by /*GA.FULLNAME,*/ AKL.CODE_EGAIS--, A.CODE, A.NAME;
)
SELECT distinct(ww.CODE_EGAIS), A.CODE, A.NAME
FROM code ww 
JOIN WHS.ARTICLE_KISCONTR_LINK AKL on akl.CODE_EGAIS = ww.CODE_EGAIS
JOIN WHS.ARTICLE A   ON A.ID_ART=AKL.ID_ARTICLE
order by  ww.CODE_EGAIS





SELECT DISTINCT  
GA.FULLNAME "Группа по виду",
A.CODE "Код товара", A.NAME "Наименование", 
count(AKL.CODE_EGAIS) "Кол-во кодов ЕГАИС" 
FROM WHS.ARTICLE_KISCONTR_LINK AKL 
JOIN WHS.ARTICLE A   ON A.ID_ART=AKL.ID_ARTICLE 
JOIN WHS.LINK_ART_ALC_TYPE M1 ON M1.ID_ART=A.ID_ART AND SYSDATE BETWEEN  M1.BEGIN_DATE AND NVL(M1.END_DATE, SYSDATE+1) 
JOIN WHS.ALC_ART_TYPE A1 ON M1.ID_ALC_ART_TYPE=A1.ID_ALC_ART_TYPE AND A1.DECLARING=1 
JOIN WHS.GROUP_ART GA   ON A.ID_GROUP=GA.ID_GROUPART 
WHERE AKL.CODE_EGAIS<>'0'  
AND AKL.CODE_EGAIS IS NOT NULL 
group by --GA.FULLNAME,
A.CODE, A.NAME




select * from WHS.ARTICLE_KISCONTR_LINK
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
with agg as
(select  /*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/
   st.id_send_status
  ,count(*) cnt
    from doc_egais.send_doc_egais_tbl ss
    join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status
    join whs.operation o on o.id_op = ss.id_send_base
    join whs.contractor c2 on c2.id_contr = o.id_contr
    left join whs.document wd on wd.id_document = ss.id_document
    left join doc_egais.ticket_doc_header_tbl th on th.id_document = ss.id_ticket
    left join doc_egais.ticket_doc_opresult_tbl t0 on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
    left join doc_egais.ticket_doc_result_tbl t1 on t1.id_ticket_doc_result = th.id_ticket_doc_result
    join whs.warehouse w on w.id_ws = o.id_wsi
                        and w.lg1  in (101,201)
     join whs.typeop tt on tt.id_top = o.id_top
                      and upper(tt.fullname) like upper('Приход') 
   where o.opdate >= date '2016-01-01'
     and ss.id_send_type = 1
    group by st.id_send_status)
select st.name
      ,st.code
      ,a.cnt
  from agg                                 a
      ,doc_egais.send_doc_status_egais_tbl st
where a.id_send_status(+) = st.id_send_status

-------------
with agg as
(select distinct ss.id_send_base
                 ,ss.id_send_status
                 ,count(*) cnt
    from doc_egais.send_doc_egais_tbl ss
    join whs.operation o on o.id_op = ss.id_send_base
                        and ss.id_send_type = 1
    join whs.typeop tt on o.id_top = tt.id_top
                      and o.typeop = tt.optype
                      and tt.fullname like '%Расход (продажа)?Магнит%'
    join whs.warehouse w on (w.id_ws = o.id_wsi or o.id_wso = w.id_ws)
                        and w.lg1 = 601
   where o.opdate >= to_date('01.05.2016', 'dd.mm.yyyy')
     and o.opsum <> 0
     and substr(o.opnumber, 7, 1) = 'A'
     and (ss.id_send_status is not null and o.opsum != 0 and o.opsum is not null)
   group by ss.id_send_status
            ,ss.id_send_base)
select 
       sta.name as "Статус"
      ,sum(a.cnt) as "Кол-во"
  from doc_egais.send_doc_status_egais_tbl sta
  left join agg a on a.id_send_status = sta.id_send_status
group by sta.name
order by sta.name;
----------------
--Выборка корп. приходных операций (статистика в разрезе  статуса)
with stat as
(select sdt2.id_send_status
        ,count(distinct op2.id_op) as cnt
    from doc_egais.send_doc_egais_tbl sdt
    join whs.operation op on op.id_op = sdt.id_send_base
                         and sdt.id_send_type = 1
    join whs.warehouse ws on op.id_wso = ws.id_ws
    join whs.opreference opr on opr.id_opref = op.id_op
                            and opr.reftype = 'E'
    join whs.operation op2 on op2.id_op = opr.id_op
    left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base
                                               and sdt.id_send_type = 1
    join whs.warehouse ws2 on ws2.id_ws = op2.id_wsi
   where op.opdate >= '11.05.2016'
     and op.opdate < to_date(sysdate)
     and ws.lg1 = 601
     and op.id_top = 169
     and substr(op.opnumber, 7, 1) like 'A'
     and sdt.id_send_status = 11
     and op.opsum <> 0
     and op2.id_top in (1, 17, 634, 635)
     and sdt2.id_send_status is not null
   group by sdt2.id_send_status
   order by sdt2.id_send_status asc)
select sds.id_send_status
      ,sds.name
      ,s.cnt
  from doc_egais.send_doc_status_egais_tbl sds
  left join stat s on s.id_send_status = sds.id_send_status
  order by sds.id_send_status;


-----------------------------------------------------------------------------------------------
select * from whs.op_moreinfo dd
join whs.addition gg on  dd.id_add = gg.id_add
where id_op = -1027406226
and gg.id_add = 660


select * from whs.addition gg
----------------------------------------------------------------------------------------------
--Выборка проблемных операций (статистика в разрезе статуса)
SELECT
op.id_operation,
  sdt2.id_send_status as "Код статуса",
  sds.name as "Наименование статуса",
  count(distinct sdt2.id_send_base) AS "Кол-во"
FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1

left join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sds ON Sds.Id_Send_Status = Sdt2.Id_Send_Status

JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate >= '01.01.2016' and op.opdate < to_date(sysdate-2)
and ws.lg1=601
and op.id_top = 169
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top   in (1,17,634,635)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is null)
GROUP BY sdt2.id_send_status, Sds.Name, sd.id_operation
ORDER BY sdt2.id_send_status asc;



-----------------------------------------------------------------------
--Выборка проблемных операций (статистика в разрезе дат и статуса)
SELECT

  op.opdate AS "Дата",
  sdt2.id_send_status as "Код статуса",
  sds.name as "Наименование статуса",
  count(distinct sdt2.id_send_base) AS "Кол-во"
FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1
left join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sds ON Sds.Id_Send_Status = Sdt2.Id_Send_Status
JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate >= '01.04.2016' and op.opdate < to_date(sysdate)
and ws.lg1=601
and op.id_top = 169
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top   in (1,17,634,635)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is null)
GROUP BY op.opdate, sdt2.id_send_status, Sds.Name
ORDER BY op.opdate asc, sdt2.id_send_status asc;
------------------------------------------------------------
--Выборка корп. приходных операций (статистика в разрезе дат и статуса)
SELECT
  sdt2.id_send_status as "Код статуса",
  sds.name as "Наименование статуса",
   count(distinct op2.id_op) AS "Кол-во"
FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1
left join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sds ON Sds.Id_Send_Status = Sdt2.Id_Send_Status
JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate >= '01.01.2016' and op.opdate < to_date(sysdate-2)
and ws.lg1=601
and op.id_top = 169
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top   in (1,17,634,635)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is null)
GROUP BY sdt2.id_send_status, Sds.Name
ORDER BY sdt2.id_send_status asc;
-----------------------------------------------------
--разбор
select *
from whs.doc_op do 
join whs.document doc ON doc.id_document = do.id_document
where 
  do.id_op = -1026679323;
--идем в Акт
select * from DOC_EGAIS.Waybillact_Doc_Header_Tbl wh
where 
  --wh.id_document = 207856939
  wh.wb_reg_id = 'TTN-0018469151';


select * from whs.doc_op do
where do.id_document = 207879712;

select * from DOC_EGAIS.Send_Doc_Egais_Tbl sd
where sd.id_document = 207879712;

select * from whs.docreference df
--join whs.document doc ON doc.id_document = df.id_doc_master
left join DOC_EGAIS.Ticket_Doc_Header_Tbl tk ON Tk.Id_Document = Df.Id_Doc_Depend
left join DOC_EGAIS.Ticket_Doc_Result_Tbl tor ON Tor.Id_Ticket_Doc_Result = Tk.Id_Ticket_Doc_Result
where
  df.id_doc_master = 207879712;

select * from whs.document where id_document = 207879712;

select * from whs.docreference df
join DOC_EGAIS.Wbinformbreg_Doc_Header_Tbl wh ON Wh.Id_Document = Df.Id_Doc_Depend
where Df.Id_Doc_Master =207006735
  
select * from doc_egais.document_tbl where id_document = 207006735

------------------------------------------------------------------------------
and not exists (select 1 from whs.doc_op do
join whs.document d on d.id_document = do.id_document
where do.id_op = op2.id_op
and d.id_doctype = 481
and nvl(d.isdeleted,0) = 0)
order by sdt.last_work_date

-----------------------------------
select opnumber, count(id_op)  from whs.operation
where opdate  in to_date('08.04.2016')
and substr(opnumber,7,1)  like 'A'
and id_top = 1 
group by opnumber
having count(id_op) >1

------------------------------------
----4 Поиск документов в БС по названию ОО и номеру документов
select 
oofr.name as "Имя файла на ОО"
,oofr.status as "Статус файла ОО"
,oofr.extracttime as "Время обработки"
,oofr.loadtime as "Время загрузки"
,'file://///Esb-egais-01/egais/' || to_char(df.lastdate, 'dd-mm-yyyy') || '/' || df.filename as "filename"
,doc.id_document
,doc.id_doctype
,dt.name as "Тип документа"
,doc.docnumber
,doc.docdate
,doc.docguid
,doc.lastdate
,dref.id_doc_master
,doc2.id_doctype as "master doctype"
,dref3.id_doc_depend
,doc3.id_doctype as "depend doctype"
,cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment" -- результат по тикету, если есть
,'file://///Esb-egais-01/egais/' || to_char(df3.lastdate, 'dd-mm-yyyy') || '/' || df3.filename as "filename depend"
,oofr3.name as "Имя файла на ОО"
,oofr3.status as "dref Статус файла"
,oofr3.extracttime as "dref Extracttime"
,oofr3.loadtime as "dref Loadtime"
,wh.id_document as "481 wh.id_document"
,dop.id_op as "Связанная Оп"
,oper.OPNUMBER
,oper.OPDATE
,c.name
from 
whs.document doc 
join whs.contractor c on c.name = c.name
join whs.group_contr gr on gr.id_grcontr = c.id_grcontr
join onsi_egais.organization_tbl oo on oo.inn = c.inn
                                   and oo.kpp = c.kpp
join doc_egais.organization_tbl do on do.code = oo.code
join doc_egais.waybill_doc_header_tbl wh on wh.id_consignee = do.id_organization 
                                        and wh.wb_number = doc.docnumber
join whs.docfileset dfs on dfs.id_document = doc.id_document -- поиск имени файла
join whs.docfile df on df.id_dfs = dfs.id_dfs
left join doc_egais.oo_filesregister_tbl oofr on oofr.fguid = df.filename -- данные по файлу по копии журнала регистарции файлов на ОО
join whs.doctype dt on dt.id_doctype = doc.id_doctype -- расшифровка типа документа
left join whs.doc_op dop on dop.id_document = doc.id_document -- связанная операция
left join whs.operation oper on oper.ID_OP = dop.id_op 
left join whs.docreference dref on dref.id_doc_depend = doc.id_document -- поиск родительских документов
left join whs.document doc2 on doc2.id_document = dref.id_doc_master -- тип родительских документов
left join whs.docreference dref3 on dref3.id_doc_master = doc.id_document -- поиск дочерних документов
left join whs.document doc3 on doc3.id_document = dref3.id_doc_depend -- тип дочерних документов
left join whs.docfileset dfs3 on dfs3.id_document = doc3.id_document -- поиск имени дочернего файла
left join whs.docfile df3 on df3.id_dfs = dfs3.id_dfs
-- Начало просмотр комментария по дочернему документу
left join doc_egais.send_doc_egais_tbl ss
          on ss.id_document = doc3.id_document
left join doc_egais.ticket_doc_header_tbl th
          on th.id_document = nvl(ss.id_ticket, doc3.id_document)
left join doc_egais.ticket_doc_result_tbl t1
          on t1.id_ticket_doc_result = th.id_ticket_doc_result
-- Конец просмотр комментария по дочернему документу
left join doc_egais.oo_filesregister_tbl oofr3 on oofr3.fguid = df3.filename -- данные по дочернему файлу по копии журнала регистарции файлов на ОО
where
doc.docdate > to_date('01.01.16') and
trim (doc.docnumber) = '146842'
and c.name = 'Кнайфф' -- По названию магазина
--and doc.id_doctype = 481
order by wh.id_document, doc.id_doctype, doc.docdate, doc.lastdate ASC
--------------------------------------------------------------------------
-------------------------------------------------------------------------------
-----------------------------------------------------------------------------
select /*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/
tt.FULLNAME,
st.id_send_status,
st.name,
--w.code "W_O_Code",
w.fullname "W_O_fullname",
to_char(o.OPDATE, 'DD.MM.YYYY HH24:Mi:SS'),
o.OPNUMBER,
wd.docnumber,
to_char(wd.docdate, 'DD.MM.YYYY HH24:Mi:SS'),
c2.code,
c2.name,
c2.inn,
c2.kpp,
ss.description,
cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment",
cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment",
to_char(ss.last_work_date, 'DD.MM.YYYY HH24:Mi:SS'),
o.ID_TOP,
o.ID_OP
  from doc_egais.send_doc_egais_tbl ss
  join doc_egais.send_doc_status_egais_tbl st
    on st.id_send_status = ss.id_send_status
  join whs.operation o
    on o.ID_OP = ss.id_send_base
  join whs.contractor c2
    on c2.id_contr = o.ID_CONTR
  left join whs.docreference df
    on df.id_doc_master = ss.id_document
  left join whs.document wd
    on wd.id_document = ss.id_document
  left join doc_egais.ticket_doc_header_tbl th
    on th.id_document = nvl(ss.id_ticket, df.id_doc_depend)
  left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
  left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
  join whs.warehouse w
    on w.id_ws = o.ID_WSI
   and w.lg1 = 101
  join whs.typeop tt
    on tt.ID_TOP = o.ID_TOP
   and UPPER(tt.FULLNAME) like UPPER('Приход')
where o.OPDATE >= '01.01.2016'
   and ss.id_send_type = 1
and ss.id_send_status <>11;

 
 select * from whs.operation
where id_op = -1026372082
select * from whs.typeop
where id_top = 1
select * from whs.opreference
  where id_op = -1026373307

---------------------------------------------------------------------------
   ---------------------------------------------------------------------------    
 
SELECT
  sdt2.id_send_status as "Код статуса",
  sds.name as "Наименование статуса",
  count(distinct sdt2.id_send_base) AS "Кол-во"
FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1
left join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sds ON Sds.Id_Send_Status = Sdt2.Id_Send_Status
JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate >= '01.04.2016' and op.opdate < to_date(sysdate-2)
and ws.lg1=601
and op.id_top = 169
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top   in (1,17,634,635)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is null)
GROUP BY sdt2.id_send_status, Sds.Name
ORDER BY sdt2.id_send_status asc;

--------------------------------------------------------------------------------
with list_art as (
                  select /*+ materialize */ distinct
                       a.CODE,  a.id_art,  a.NAME
                       from
                  whs.link_art_alc_type laatt
                      Join whs.alc_art_type aat on aat.id_alc_art_type = laatt.id_alc_art_type
                      join whs.article a on a.id_art = laatt.id_art                                           
                  where aat.declaring = '1'
                        AND laatt.begin_date <= sysdate
                        AND (laatt.end_date >= sysdate OR laatt.end_date is NULL)),
t as (select     op.ID_op,  op.opguid,  op.OPNUMBER,   op.OPDATE,    w.code wcode,   w.fullname as wname,  sum(oa.QUANTITY) as Tu_quant
      from whs.operation op
           join whs.warehouse w on w.id_ws=op.id_wso        
           join whs.op_art oa on oa.ID_OP = op.ID_OP
           join list_art la on la.id_art = oa.ID_ART
      where op.opdate >='10.04.2016'
            and op.opdate <=sysdate
            and op.id_top = 169
      group by
            op.ID_op,  op.opguid,  op.OPNUMBER, op.OPDATE,  w.code,  w.fullname
   )
      Select
           t.ID_op,    t.opguid,   t.opnumber,  t.opdate, t.wcode, t.wname,  t.Tu_quant,  sum(aop.quantity) au_quant,
           t.Tu_quant - sum(aop.quantity) as разность
     from t
           left join acan.analyticopart_tbl aop on aop.opguid = t.opguid
     where
           t.opnumber not like '%D%'
           and
           (aop.isdeleted <> '1' or aop.isdeleted is null)             
     Group by
           t.ID_op,  t.opguid, t.opnumber,  t.opdate,  t.wcode,  t.wname,  t.Tu_quant
     Having
            t.Tu_quant <> sum(aop.quantity) 
--------------------------------------------
-----------------------------------------------
--------------------------------------------
     with wart as (
select /*+ materialize */laat.id_art
from whs.LINK_ART_ALC_TYPE laat --on  = oa.id_art
join whs.alc_art_type aat on aat.id_alc_art_type = laat.id_alc_art_type and aat.declaring = 1
where laat.end_date is null or laat.end_date>=to_date('13.04.2016','dd.mm.yyyy')
Group by laat.id_art),
oo as (
select w.code,w.fullname,w.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID
from whs.operation o
join whs.warehouse w on w.id_ws = o.id_wso and w.lg1 = 601
where o.OPDATE between sysdate-2 and sysdate-1 and o.ID_TOP = 169
),
tu as (
select op.ID_OP,op.ID_ART,op.QUANTITY
from oo
join whs.op_art op on op.ID_OP = oo.ID_OP
join wart w2 on w2.id_art = op.ID_ART
where op.QUANTITY<>0),
au as
(select oo.id_op,oa.id_art,sum(oa.quantity) quantity
from oo
join acan.analyticopart_tbl oa on oa.opguid = oo.opguid
join acan.analytic_tbl a on a.id_analytic=oa.id_analytic and a.isdeleted = 0
join wart w2 on w2.id_art = oa.ID_ART
where oa.quantity<>0
Group by oo.id_op,oa.id_art)

select code,fullname,guid,OPDATE,OPNUMBER,ID_OP,OPGUID,ID_ART,sum(TU_qu) TU_qu,sum(AU_qu) AU_qu
from (
select o.code,o.fullname,o.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID,t.ID_ART,t.quantity TU_qu,0 AU_qu
from oo o
join tu t on t.id_op = o.ID_OP
union all
select o.code,o.fullname,o.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID,a.ID_ART,0 TU_qu,a.quantity AU_qu
from oo o
join au a on o.id_op = a.ID_OP)
Group by code,fullname,guid,OPDATE,OPNUMBER,ID_OP,OPGUID,ID_ART
Having (sum(TU_qu)-sum(AU_qu))<>0

--------------------------------------------------------------------------------
with wart as (
select /*+ materialize */laat.id_art
from whs.LINK_ART_ALC_TYPE laat --on  = oa.id_art
join whs.alc_art_type aat on aat.id_alc_art_type = laat.id_alc_art_type and aat.declaring = 1
where laat.end_date is null or laat.end_date>=to_date('13.04.2016','dd.mm.yyyy')
--where laat.id_art = 579915
Group by laat.id_art),
oo as (
select /*+ materialize */ w.code,w.fullname,w.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID
from whs.operation o
join whs.warehouse w on w.id_ws = o.id_wso and w.lg1 = 601
where o.OPDATE between sysdate-7 and sysdate-1 and o.ID_TOP = 169
--and o.ID_OP = -1007530533
),
tu as (
select /*+ index(op I_ARTWSTOPDATE)*/op.ID_OP,op.ID_ART,op.QUANTITY
from oo
join whs.op_art op on op.ID_OP = oo.ID_OP
join wart w2 on w2.id_art = op.ID_ART
where op.QUANTITY<>0
and op.OPDATE between sysdate-2 and sysdate-1
and op.ID_TOP = 169),
au as
(select /*+ materialize */ oo.id_op,oa.id_art,sum(oa.quantity) quantity
from oo
join acan.analyticopart_tbl oa on oa.opguid = oo.opguid
join acan.analytic_tbl a on a.id_analytic=oa.id_analytic and a.isdeleted = 0
join wart w2 on w2.id_art = oa.ID_ART
where oa.quantity<>0 and oa.typeop = 20
and oa.ISDELETED = '0'
--and oa.OPDATE between sysdate-7 and sysdate-1
Group by oo.id_op,oa.id_art)
--select * from au
-- Расхождение ТУ с АУ(есть в ТУ нет или отличается в АУ)
select code,fullname,guid,OPDATE,OPNUMBER,ID_OP,OPGUID,ID_ART,sum(TU_qu) TU_qu,sum(AU_qu) AU_qu
from (
select o.code,o.fullname,o.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID,t.ID_ART,t.quantity TU_qu,0 AU_qu
from oo o
join tu t on t.id_op = o.ID_OP
union all
select o.code,o.fullname,o.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID,a.ID_ART,0 TU_qu,a.quantity AU_qu
from oo o
join au a on o.id_op = a.ID_OP)
Group by code,fullname,guid,OPDATE,OPNUMBER,ID_OP,OPGUID,ID_ART
Having (sum(TU_qu)-sum(AU_qu))<>0
  
--------------------
-------------------------------------

--------------------------------------------------------------



   with wart as (
  select /*+ materialize */ distinct
                       laatt.id_art
                       from
                  whs.link_art_alc_type laatt
                      Join whs.alc_art_type aat on aat.id_alc_art_type = laatt.id_alc_art_type
                   where aat.declaring = '1'
                        AND laatt.begin_date <= sysdate
                        AND (laatt.end_date >= sysdate OR laatt.end_date is NULL)),
oo as (
         select /*+ materialize */ w.code,w.fullname,w.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID
         from whs.operation o
         join whs.warehouse w on w.id_ws = o.id_wso and w.lg1 = 601
         -- and o.opdate = trunc(sysdate-1)
       --  and o.opdate 
       --  and o.lastdate
        -- between to_date('29.05.2016 05:00:00','dd.mm.yyyy HH24:MI:SS') and  to_date('29.05.2016 09:00:00','dd.mm.yyyy HH24:MI:SS')
          and o.opdate between  '01.04.2016' and '30.04.2016'
       -- where o.opdate between sysdate-2 and sysdate-1
         and o.ID_TOP = 169
       --and  substr(o.opnumber,7,1)  like 'A'
),
tu as (
       select /*+ index(op I_ARTWSTOPDATE)*/op.ID_OP,op.ID_ART,op.QUANTITY
       from oo
            join whs.op_art op on op.ID_OP = oo.ID_OP
            join wart w2 on w2.id_art = op.ID_ART
            where op.QUANTITY<>0
            -- and op.opdate = trunc(sysdate-1)
           --  and op.lastdate
       --  between to_date('29.05.2016 05:00:00','dd.mm.yyyy HH24:MI:SS') and  to_date('29.05.2016 09:00:00','dd.mm.yyyy HH24:MI:SS')
          and op.opdate between   '01.04.2016' and '30.04.2016'
           -- and op.opdate between sysdate-2 and sysdate-1
            and op.ID_TOP = 169),
au as
(select /*+ materialize */ oo.id_op,oa.id_art,sum(oa.quantity) quantity
        from oo
             join acan.analyticopart_tbl oa on oa.opguid = oo.opguid
             join acan.analytic_tbl a on a.id_analytic=oa.id_analytic and a.isdeleted = 0
             join wart w2 on w2.id_art = oa.ID_ART
             where oa.quantity<>0 and oa.typeop = 20
             and oa.ISDELETED = '0'
             
            and oa.opdate between   '01.04.2016' and '30.04.2016'
            --  and oa.opdate between sysdate-2 and sysdate-1
          -- and oa.opdate = trunc(sysdate-1)
           -- and oa.lastdate
       --  between to_date('29.05.2016 05:00:00','dd.mm.yyyy HH24:MI:SS') and  to_date('29.05.2016 09:00:00','dd.mm.yyyy HH24:MI:SS')                       
            -- and oa.opdate between sysdate-7 and sysdate-4
                          Group by oo.id_op,oa.id_art)
Select code,fullname,guid,OPDATE,OPNUMBER,ID_OP,OPGUID,ID_ART,sum(TU_qu) TU_qu,sum(AU_qu) AU_qu
   from (
          select o.code,o.fullname,o.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID,t.ID_ART,t.quantity TU_qu,0 AU_qu
          from oo o
               join tu t on t.id_op = o.ID_OP
union all
          select o.code,o.fullname,o.guid,o.OPDATE,o.OPNUMBER,o.ID_OP,o.OPGUID,a.ID_ART,0 TU_qu,a.quantity AU_qu
          from oo o
              join au a on o.id_op = a.ID_OP)
Group by code,fullname,guid,OPDATE,OPNUMBER,ID_OP,OPGUID,ID_ART
Having (sum(TU_qu)-sum(AU_qu))<>0


----------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------
-----проверка от ММ-
with t as( 
select op.ID_OP, op.opnumber, op.opdate,  cc.fullname as cname,cc.code, w1.lg1,
w.fullname as wname, oa.id_art, max(oa.QUANTITY) as op_quant, sum(aop.quantity) as an_quant from whs.operation op 
left join whs.contractor cc on cc.id_contr=op.id_contr 
left join whs.warehouse w on w.id_ws=op.id_wso 
left join whs.warehouse w1 on  trim(w1.code) = trim(cc.code)
left join whs.op_art oa on oa.ID_OP = op.ID_OP 
left join acan.analyticopart_tbl aop on op.opguid=aop.opguid and oa.ID_ART=aop.id_art 
where --trim(op.opnumber) = '560186A1129' 
 --and 
op.id_top = 169

and op.opdate between '01.04.2016' and '10.05.2016'
--and op.opdate between sysdate-2 and sysdate-1
and  substr(op.opnumber,7,1)  like 'A'
group by op.ID_OP, oa.id_art, op.opnumber, cc.fullname, w.fullname, op.opdate, cc.code, w1.lg1
) 
select
t.opnumber,
t.opdate,
t.code,
t.lg1
from t 
group by t.opnumber, t.opdate, t.code, t.lg1
having sum(t.op_quant) <> sum(nvl(t.an_quant,0))



--------------------------------------------------------------------------------
----для групперовки по дате-----------------------------------------------------
select op.id_top, count (op.id_op)  from whs.operation op
where   substr(op.opnumber,7,1)  like 'A'
and op.id_top in (1,169)
and op.opdate >='01.01.2016'
group by op.id_top

--------------------------------------------------------------------------------------------
----------==========================-------------------- 
          with list_art as
(select /*+ materialize */
  distinct a.id_art
    from whs.link_art_alc_type laatt
    join whs.alc_art_type aat on aat.id_alc_art_type = laatt.id_alc_art_type
    join whs.article a on a.id_art = laatt.id_art
   where aat.declaring = '1'
     and laatt.begin_date <= sysdate
     and (laatt.end_date >= sysdate or laatt.end_date is null)),
sel as
(select distinct op.id_top as "ИД_тип_оп"
                  ,top.fullname as "Тип_оп"
                  ,op.opnumber as "Ном_оп"
                  ,op.opdate as "Дата_оп"
                  ,w.fullname as "МХ_оп"
                  ,op.opguid as "Гуид_оп"
                  ,doc_egais.sendqueue_api.status_egais_operation(op.id_op,
                                                                 op.opguid,
                                                                 op.opdate,
                                                                 op.id_top,
                                                                 op.typeop,
                                                                 op.status,
                                                                 op.id_contr,
                                                                 nvl(op.id_wsi, op.id_wso)) as "Ошибка"
    from whs.operation op
    join whs.op_art oa on oa.id_op = op.id_op
    join list_art a on a.id_art = oa.id_art
    join whs.warehouse w on w.id_ws = nvl(op.id_wsi, op.id_wso)
    join whs.typeop top on top.id_top = op.id_top
   where op.opdate >= to_date('05.05.2016')  and op.opdate <= sysdate
     and op.opsum <> 0
        
        --условия по типовым
     and (
           (w.lg1 = 601  and op.TYPEOP in (10,20,21) and op.id_top not in (558)))
         -- 
         --(w.lg1 in (101 and op.typeop in (10, 21) and op.ID_TOP not in (15, 58, 142)))
       --   (w.lg1 in (201) and op.typeop in (10, 21) and op.id_top not in (15, 58, 142)))
        --условие на отсутствие в очереди
     and not exists (select 1
            from doc_egais.send_doc_egais_tbl sd
           where sd.id_send_base = op.id_op
             and sd.id_send_type = 1))
select *
  from sel s
where s."Ошибка" is null;
-------------------------------------                     
           -----------------------------
           -------------------------------
                     
           with agg as(
select DISTINCT ss.id_send_base, ss.id_send_status,count(*) cnt
    from doc_egais.send_doc_egais_tbl ss
    join whs.operation o on o.id_op = ss.id_send_base and ss.id_send_type = 1
    join whs.typeop tt on o.id_top = tt.id_top and o.typeop = tt.optype and tt.fullname like '%Расход (продажа)∙Магнит%'
    join whs.warehouse w on (w.id_ws = o.id_wsi OR o.id_wso = w.id_ws) and w.lg1 = 601
   where o.opdate >= to_date('01.01.2016','dd.mm.yyyy') and o.OPSUM<>0 and substr(o.opnumber,7,1)='A' 
  -- and (ss.id_send_status != 11 and ss.id_send_status is not null and ss.id_send_status != 12 and ss.id_send_status != 41 and o.OPSUM != 0 and o.OPSUM is not null)
  --and 
    group by ss.id_send_status,ss.id_send_base)
select sta.id_send_status as "ID статуса",sta.name as "Статус",sum(a.cnt) as "Кол-во" --count(*) cntt
  from agg a
  full join doc_egais.SEND_DOC_STATUS_EGAIS_TBL sta on sta.id_send_status = a.id_send_status
  group by sta.name,sta.id_send_status--,a.id_send_base
   order by sta.id_send_status asc

           
     --------------------------------------------------      

---------------
----------------
----------------
           with list_art as
  (select /*+ materialize */
          distinct
          a.id_art
     from whs.link_art_alc_type l
     join whs.alc_art_type t on t.id_alc_art_type = l.id_alc_art_type
     join whs.article a on a.id_art = l.id_art
    where t.declaring = '1'
      and l.begin_date <= sysdate
      and nvl(l.end_date, sysdate) >= sysdate),
stat as
  (select /*+ materialize */
          distinct
          op.id_top as "ИД_тип_оп"
         ,top.fullname as "Тип_оп"
         ,op.opnumber as "Ном_оп"
         ,op.opdate as "Дата_оп"
         ,w.fullname as "МХ_оп"
         ,op.opguid as "Гуид_оп"
         ,doc_egais.sendqueue_api.status_egais_operation(op.id_op
                                                        ,op.opguid
                                                        ,op.opdate
                                                        ,op.id_top
                                                        ,op.typeop
                                                        ,op.status
                                                        ,op.id_contr
                                                        ,nvl(op.id_wsi, op.id_wso)) as "Ошибка"
     from whs.operation op
     join whs.op_art oa on oa.id_op = op.id_op
     join list_art a on a.id_art = oa.id_art
     join whs.warehouse w on w.id_ws = nvl(op.id_wsi, op.id_wso)
     join whs.typeop top on top.id_top = op.id_top
    where op.opdate >= to_date('10.05.2016')
      and op.opdate <= sysdate
      and op.opsum <> 0
      /* Условия по типовым */
      and ((w.lg1 = 601 and op.typeop in (10, 20, 21) and op.id_top not in (558)))
      /* ------------------ */
      and not exists (select 1
                        from doc_egais.send_doc_egais_tbl sd
                       where sd.id_send_base = op.id_op
                         and sd.id_send_type = 1))
select *
  from stat s
where s."Ошибка" is null;

-----------
------------
select * from acan.Analyticopart_tbl;
------------------------------------------------------
update acan.Analyticopart_tbl set isdeleted=1
where opguid in (hextoraw('2E044E7573AD9475E053AC740C0A5B4E'));
commit;


----------------------------------------------------

with stat as
(select sdt2.id_send_status
        ,count(distinct op2.id_op) as cnt
    from doc_egais.send_doc_egais_tbl sdt
    join whs.operation op on op.id_op = sdt.id_send_base
                         and sdt.id_send_type = 1
    join whs.warehouse ws on op.id_wso = ws.id_ws
    join whs.opreference opr on opr.id_opref = op.id_op
                            and opr.reftype = 'E'
    join whs.operation op2 on op2.id_op = opr.id_op
    left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base
                                               and sdt.id_send_type = 1
    join whs.warehouse ws2 on ws2.id_ws = op2.id_wsi
   where op.opdate >= '01.01.2016'
     and op.opdate < to_date(sysdate)
     and ws.lg1 = 601
     and op.id_top = 169
     and substr(op.opnumber, 7, 1) like 'A'
     and sdt.id_send_status = 11
     and op.opsum <> 0
     and op2.id_top in (1, 17, 634, 635)
     and sdt2.id_send_status is not null
   group by sdt2.id_send_status
   order by sdt2.id_send_status asc)
select sds.id_send_status
      ,sds.name
      ,s.cnt
  from doc_egais.send_doc_status_egais_tbl sds
  left join stat s on s.id_send_status = sds.id_send_status
  order by sds.id_send_status;

-----------------------------------------------

select /*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/ tt.FULLNAME, --o.opnumber,
--w.fullname,
st.id_send_status,st.name,count(*)
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.warehouse w on w.id_ws = o.ID_WSI and w.lg1 = 601
join whs.typeop tt on tt.ID_TOP = o.ID_TOP and UPPER(tt.FULLNAME) like UPPER('Приход%')
where o.OPDATE>='01.01.2016' and ss.id_send_type = 1
--and  w.fullname like ('%Сеть РЦ?РЦ?РЦ Астрахань%')
Group by tt.FULLNAME,st.id_send_status,st.name
Order by 1,2
--------------------------------------------------------------------------------  
--------------------------------------------------------------------------------
select * from doc_egais.send_doc_status_egais_tbl
--------------------------------------------------------------------------------
select * from whs.warehouse
where id_ws = 1
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

select ws.code,ws.fullname,to_char(cast(max(d.lastdate) as date),'dd.mm.yyyy HH24:MI:SS') from doc_egais.document_tbl dd  
join  whs.warehouse ws on ws.id_ws = dd.id_ws join whs.document d on  d.id_document = dd.id_document where d.lastdate>=to_date('20.06.2016 00:00:00','dd.mm.yyyy  hh24:mi:ss') 
-- проверяем с 01.01.16, для  снижения нагрузки запросом and d.origplace = 'R' -- R - Входящий, O -  Исходящий I - /*Внутренний(Внутренняя ТТН - при отгрузке с РЦ на ОО)*/ 
 Group by  ws.code,ws.fullname Order by 3
----------------------------

select ash.*--count(*)
--w.fullname, length(ash.request_body), ash.* 
  from acan.analytic_service_history_tbl ash
  join whs.warehouse w on w.code = ash.inf_sys
where ash.request_server_datetime > to_date('27.06.2016 16:08', 'dd.mm.yyyy hh24:mi')
   and ash.request_server_datetime < to_date('27.06.2016 16:15', 'dd.mm.yyyy hh24:mi')
   and ash.request_type = 2;
----------------------------------

  
  ---------------------
select * from whs.warehouse
where fullname like '%Сеть РЦ%'
------------------------------------------------------------------------------------
select qt.name,doc.*, dtb.* from whs.document doc
join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
join whs.warehouse w on dtb.id_ws=w.id_ws
left join doc_egais.query_doc_header_tbl qh on dtb.id_document=qh.id_document
left join doc_egais.query_type_tbl qt on qh.id_query_type=qt.id_query_type --and qh.id_query_type=7
where
     doc.id_Doctype = 479  --для проверки ответа тип "479"
     and w.fullname =  'Сеть РЦ∙РЦ∙РЦ Челябинск∙Сектора'
     and dtb.lastdate > trunc(sysdate)
-------------------------------------------------------------------------------------- 
select
       doc.id_document
       , ws.fullname
       , dhed.rests_date
       , pr.full_name
       , pr.alc_code
       , dcon.quantity
       , dcon.reg_id_a
       , dcon.reg_id_b
from whs.document doc
left join doc_egais.document_tbl dtb ON dtb.id_document = doc.id_document
left join whs.warehouse ws on ws.id_ws = dtb.id_ws
left join doc_egais.replyrests_doc_header_tbl dhed ON dhed.id_Document = dtb.id_document
left join doc_egais.replyrests_doc_rest_tbl dcon ON dcon.id_document = dtb.id_document
left join doc_egais.product_tbl pr ON pr.id_product = dcon.id_product
WHERE
doc.id_document = 295815928  --ИД документа ответа по остаткам на МХ
and pr.alc_code='0378115000001238464' -- алко код полученный в п.3

----------------------------АУ не равно ТУ -------------------------------------
select 'OPNUMBER'||';'||'OPDATE'||';'||'CODE'||';'||'LG1' from dual;
with t as(
select op.ID_OP, op.opnumber, op.opdate,  cc.fullname as cname,cc.code, w1.lg1,
w.fullname as wname, oa.id_art, max(oa.QUANTITY) as op_quant, sum(aop.quantity) as an_quant from whs.operation op
left join whs.contractor cc on cc.id_contr=op.id_contr
left join whs.warehouse w on w.id_ws=op.id_wso
left join whs.warehouse w1 on  trim(w1.code) = trim(cc.code)
left join whs.op_art oa on oa.ID_OP = op.ID_OP
left join acan.analyticopart_tbl aop on op.opguid=aop.opguid and oa.ID_ART=aop.id_art
where --trim(op.opnumber) = '560186A1129' 
 --and
op.id_top = 169
and op.opdate between '01.07.206' and '29.07.206'
and  substr(op.opnumber,7,1)  like 'A'
group by op.ID_OP, oa.id_art, op.opnumber, cc.fullname, w.fullname, op.opdate, cc.code, w1.lg1
), a as(
select
t.opnumber,
t.opdate,
t.code,
t.lg1
from t
group by t.opnumber, t.opdate, t.code, t.lg1
having sum(t.op_quant) <> sum(nvl(t.an_quant,0))
)
select opnumber||';'||opdate||';'|| trim(code)||';'|| lg1
from a;




select  ws.code, ws.fullname,
qq.id_doctype,
tt.name,
--ws.fullname,
--to_char(cast(max(d.lastdate) as date),'dd.mm.yyyy HH24:MI:SS')
count (dd.id_document)
from doc_egais.document_tbl dd  
join whs.document qq on dd.id_document = qq.id_document --and qq.id_doctype = 478 
join whs.doctype tt on tt.id_doctype=qq.id_doctype
join  whs.warehouse ws on ws.id_ws = dd.id_ws and ws.code ='571000'
join whs.document d on d.id_document = dd.id_document where d.lastdate between to_date('02.08.2016 20:00:00','dd.mm.yyyy  hh24:mi:ss')
and to_date('02.08.2016 23:00:00','dd.mm.yyyy  hh24:mi:ss') 
-- проверяем с 01.01.16, для  снижения нагрузки запросом and d.origplace = 'R' -- R - Входящий, O -  Исходящий I - /*Внутренний(Внутренняя ТТН - при отгрузке с РЦ на ОО)*/ 
Group by   ws.code, ws.fullname, qq.id_doctype,tt.name --ws.code--,ws.fullname 
Order by 3

 
select ws.code, ws.fullname, d.docnumber , count (1)  from doc_egais.document_tbl dd
join whs.document qq on dd.id_document = qq.id_document and qq.id_doctype = 478 --and isdeleted <> 1
join  whs.warehouse ws on ws.id_ws = dd.id_ws and lg1 in (601) --and code ='522000'
join whs.document d on d.id_document = dd.id_document where d.lastdate between to_date('02.08.2016 20:00:00','dd.mm.yyyy  hh24:mi:ss')
and to_date('02.08.2016 23:00:00','dd.mm.yyyy  hh24:mi:ss') 
Group by ws.code, ws.fullname, d.docnumber

having count (d.docnumber) >1


select * from whs.document 
where  docnumber = 'Ч0308/085'


select * from whs.document
--------------------------------------------------------------------------------
select -- ws.code, 
qq.id_doctype,
tt.name,
--ws.fullname,
--to_char(cast(max(d.lastdate) as date),'dd.mm.yyyy HH24:MI:SS')
count (dd.id_document)
from doc_egais.document_tbl dd  
join whs.document qq on dd.id_document = qq.id_document
join whs.doctype tt on tt.id_doctype=qq.id_doctype
join  whs.warehouse ws on ws.id_ws = dd.id_ws join whs.document d on
d.id_document = dd.id_document where d.lastdate between to_date('04.08.2016 05:00:00','dd.mm.yyyy  hh24:mi:ss')
and to_date('04.08.2016 18:30:00','dd.mm.yyyy  hh24:mi:ss') 
-- проверяем с 01.01.16, для  снижения нагрузки запросом and d.origplace = 'R' -- R - Входящий, O -  Исходящий I - /*Внутренний(Внутренняя ТТН - при отгрузке с РЦ на ОО)*/ 
Group by  qq.id_doctype,tt.name --ws.code--,ws.fullname 
Order by 2


select * from doc_egais.document_tbl d
join whs.document qq on d.id_document = qq.id_document and qq.id_doctype = 474
join whs.docreference dref on qq.id_document = dref.id_doc_depend
--join whs.docreference a1 on dref.id_doc_master = a1.id_doc_depend --and qq.id_doctype = 474
where d.lastdate between to_date('04.08.2016 05:00:00','dd.mm.yyyy  hh24:mi:ss')
and to_date('04.08.2016 18:30:00','dd.mm.yyyy  hh24:mi:ss')
and 

select count () from whs.DOCUMENT dd
join whs.docreference doc2 ON doc2.id_document = dd.id_doc_depend
where  id_doctype = 481

  SELECT *
    FROM whs.docreference dref
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
       WHERE
    dref.id_doc_master IN (285168720)
    285168720      285168732
       and id_doctype =483;


select * from whs.docreference
where id_doc_master = 323960939
select * from whs.document 
where id_document = 323960995








select -- ws.code, 
qq.id_doctype,
tt.name,
dd.id_document,
--ws.fullname,
--to_char(cast(max(d.lastdate) as date),'dd.mm.yyyy HH24:MI:SS')
count (dd.id_document)
from doc_egais.document_tbl dd  
join whs.document qq on dd.id_document = qq.id_document --and qq.id_doctype = 478 
join whs.doctype tt on tt.id_doctype=qq.id_doctype
join  whs.warehouse ws on ws.id_ws = dd.id_ws join 
whs.document d on d.id_document = dd.id_document where d.lastdate between to_date('04.08.2016 07:00:00','dd.mm.yyyy  hh24:mi:ss')
and to_date('04.08.2016 08:00:00','dd.mm.yyyy  hh24:mi:ss') 
-- проверяем с 01.01.16, для  снижения нагрузки запросом and d.origplace = 'R' -- R - Входящий, O -  Исходящий I - /*Внутренний(Внутренняя ТТН - при отгрузке с РЦ на ОО)*/ 
Group by  dd.id_document, qq.id_doctype,tt.name --ws.code--,ws.fullname 
Order by 2

 select * from 
 
  SELECT doc2.id_document, doc2.id_doctype, df.*, dref.*, doc2.*
   FROM whs.docreference dref
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
    left jOIN WHS.docfileset dfs ON dfs.id_document = doc2.id_document
    left JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
       WHERE
      dref.id_doc_master IN (323960939) 
 
 select * from whs.doc_op
where id_document = 323960997

 select * from whs.docreference
where id_doc_master in (321438326)


select * from whs.document
where id_document in(321414244)


-------------межсклад лайт-----------------------
select o.*--, --count (opnumber),
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st  on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.typeop tt on tt.ID_TOP = o.ID_TOP
where   o.opdate >= '01.07.2016'
--o.OPDATE between  '01.07.2016' and '25.07.2016'
and o.id_top in (477,473)
and ss.id_send_status in (3,9,1,7,10,41)
and id_wsi in (11054,9631,11378)
and id_wso in (11054,9631,11378)


-----выгрузка все заданных статусов по всем сущностям в очереди ЭДО
with
all_in_allstatus as (
select 
round((sysdate-last_work_date),0) as age_days --возраст в днях
,ka.id_contr          as ka_id            
,ka.code              as ka_code
,ka.name              as ka_name
,op.ID_OP             as id_op
,op.OPNUMBER          as opnumber
,op.OPDATE            as opdate
,op.OPSUM             as opsum
,war.fullname         as oo_fullname
,war.code             as oo_code
,op.id_top            as id_top
,top.fullname         as top_fullname
,sdt.id_Send_status   as id_send_status
,sdt.id_document      as id_document
,sdt.id_doctype       as id_doctype
,sdt.id_ticket        as id_ticket
,sdt.id_ticket1       as id_ticket1
,sdt.description      as status_description
--,sdt.*
--,count(op.id_op) */
--distinct war.fullname--top.id_top, top.FULLNAME
  from doc_egais.send_doc_egais_tbl sdt 
  join whs.operation op on op.id_op = sdt.id_send_base and sdt.id_send_type = 1
  join whs.typeop top on top.id_top = op.id_top
  join whs.warehouse war on war.id_ws=nvl(op.id_wsi,op.id_wso)
  left join whs.contractor ka on ka.id_contr = op.ID_CONTR
  where 
   sdt.last_work_date < sysdate-1/12 --'20.09.2016'
  and sdt.last_work_date >'01.07.2016'
  and sdt.id_Send_status in (1,2,3,4,5,6,7,8,9,10)
  and war.lg1=101
  -- исключение заданных ММ
  --and war.code not in ('760032')
  --and war.code in ('432306')
  /*group by 
  round((sysdate-last_work_date),0),
  op.id_top,top.fullname,sdt.id_Send_Status*/
  order by sdt.id_Send_Status
  )
, ordering_status3 as ( -- операции в статусе 3
-- исключение из вывода типовых операции приход/перевеоз/недовоз
-- исключение из вывода типовых оперций корп. приходов
select a.* from all_in_allstatus a
where a.id_send_status = 3 and a.id_top not in (1,17)
)
, status3_top17_1 as ( -- недовозы в 3 статусе
select a.* from all_in_allstatus a
where
a.id_send_status = 3 
and a.id_top = 17
and a.opsum < 0
)
, status3_top17_2 as ( -- перевозы в 3 статусе
select a.* from all_in_allstatus a
where
a.id_send_status = 3 
and a.id_top = 17
and a.opsum  >= 0
)
, status3_top1 as ( -- приходы в 3 статусе
select a.* from all_in_allstatus a
join whs.opreference opr on opr.id_op = a.id_op
join doc_egais.send_doc_egais_tbl sdt on sdt.id_send_base = opr.id_opref and sdt.id_send_status = 11 --расходы в 11 статусе
where
a.id_send_status = 3 
and a.id_top = 1
)
, togetehr as (
select * from all_in_allstatus where id_send_status <> 3
union
select * from ordering_status3
union
select * from status3_top17_1
union
select * from status3_top17_2
union
select * from status3_top1
)
select * from togetehr t
order by t.id_send_status, t.opdate

-- �������������� ���������� �� ��������
select *
--tt.basename as task_type--"��� �������",
--, tt.id_transfer_task_base
/*st.last_work_date
, st.id_document
, st.id_doctype
, st.id_send_status
, st.id_ticket
, st.id_ticket1
, tr.*
, wh.code
, wh.name
--, st.id_send_type
--, stst.name as "id_send_type NAME"
, case when enwh.id_ws is not null then '1' else '0' end as permition--"�� � �������� ���������" 
, case when ex.id_send_base is not null then '1' else '0' end as exclude--"�������� �� ��������"
, cast(substr(st.description, 1, 4000) as varchar2(4000)) "description"
, cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment"
, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment"*/
-- ���� ������ �� ��������
from whs.operation op
join whs.warehouse whm on whm.id_ws = nvl (op.id_wsi, op.id_wso)
left join doc_egais.send_doc_egais_tbl stm on stm.id_send_base = op.ID_OP
left join doc_egais.send_doc_type_egais_tbl ststm on ststm.id_send_type = stm.id_send_type
left join doc_Egais.Reg_Transfer_Task_Enablews_Tbl enwhm on enwhm.id_ws = nvl (op.id_wsi, op.id_wso) --����������� � �������� ��
left join doc_egais.exclude_send_data_tbl exm on exm.id_send_base = op.id_op -- ������� ����������
left join whs.document dm on dm.id_document = stm.id_document
left join doc_egais.send_doc_egais_tbl wwm on wwm.id_send_base = stm.id_send_base
left join whs.docreference dfm on dfm.id_doc_master = wwm.id_document
left join doc_egais.ticket_doc_header_tbl thm on thm.id_document = dfm.id_doc_depend
left join doc_egais.ticket_doc_opresult_tbl t0m
    on t0m.id_ticket_doc_opresult = thm.id_ticket_doc_opresult
left join doc_egais.ticket_doc_result_tbl t1m
    on t1m.id_ticket_doc_result = thm.id_ticket_doc_result
-- ���� ������ �� �������
left join doc_Egais.Reg_Transfer_Task_Tbl tr on tr.id_op = op.id_op
--join doc_Egais.Reg_Transfer_Task_Base_Tbl tt on tt.id_transfer_task_base = tr.id_transfer_task_base
left join whs.warehouse wh on wh.id_ws = tr.id_ws
left join doc_egais.send_doc_egais_tbl st on st.id_send_base = tr.id_transfer_task
left join doc_egais.send_doc_type_egais_tbl stst on stst.id_send_type = st.id_send_type
left join doc_Egais.Reg_Transfer_Task_Enablews_Tbl enwh on enwh.id_ws = tr.id_ws --����������� � �������� ��
left join doc_egais.exclude_send_data_tbl ex on ex.id_send_base = tr.id_op -- ������� ����������
left join whs.document d on d.id_document = st.id_document
left join doc_egais.send_doc_egais_tbl ww on ww.id_send_base = st.id_send_base
left join whs.docreference df on df.id_doc_master = ww.id_document
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
where --tr.id_transfer_task = 1072719
op.id_op = 


-- �������������� ���������� �� ������� �� ������� �2-�1
select
--tt.basename as task_type--"��� �������",
--, tt.id_transfer_task_base
st.last_work_date
, st.id_document
, st.id_doctype
, st.id_send_status
, st.id_ticket
, st.id_ticket1
, tr.*
, wh.code
, wh.name
--, st.id_send_type
--, stst.name as "id_send_type NAME"
, case when enwh.id_ws is not null then '1' else '0' end as permition--"�� � �������� ���������" 
, case when ex.id_send_base is not null then '1' else '0' end as exclude--"�������� �� ��������"
, cast(substr(st.description, 1, 4000) as varchar2(4000)) "description"
, cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment"
, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment"
from doc_Egais.Reg_Transfer_Task_Tbl tr
--join doc_Egais.Reg_Transfer_Task_Base_Tbl tt on tt.id_transfer_task_base = tr.id_transfer_task_base
join whs.warehouse wh on wh.id_ws = tr.id_ws
left join doc_egais.send_doc_egais_tbl st on st.id_send_base = tr.id_transfer_task
left join doc_egais.send_doc_type_egais_tbl stst on stst.id_send_type = st.id_send_type
left join doc_Egais.Reg_Transfer_Task_Enablews_Tbl enwh on enwh.id_ws = tr.id_ws --����������� � �������� ��
left join doc_egais.exclude_send_data_tbl ex on ex.id_send_base = tr.id_op -- ������� ����������
left join whs.document d on d.id_document = st.id_document
left join doc_egais.send_doc_egais_tbl ww on ww.id_send_base = st.id_send_base
left join whs.docreference df on df.id_doc_master = ww.id_document
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
where tr.id_transfer_task = 1072719
--wh.lg1 in (101,201) --��
--and 
--st.id_send_status /*in (1,2,3,4,5,6,7,8,9,10)--*/not in (11)
--st.id_send_status in (7)
--and
-- tr.taskdate between to_date('01.01.2016') and to_date (sysdate-1/48)
-- and st.id_send_type = 6 -- ������ ������� �� ������� �������� �1<>�2
 --and tr.id_transfer_task_type = 1 -- �������� 1 �� �1 � �2, 2 �2 � �1
 --order by tt.id_transfer_task_base, tr.taskdate
 --and wh.code in ('310132','680072','230344','310112','70037','427364','560082','230159','670097','744096','230967','720081','100049','161704','310154','470261','630577','660204','660512','760024','161726','784179','480031','560060','600134','780059','210088','770220','560171','580080','210083','363641','660179','590054','524613','524589','502410','260285','107015','450038','760075','729739','160233','570086','660389','720096','644672','430393','430349','610108','21198','520083','20115','210092','322575','230809','860290','610015','182429','524588','740668','210067','130091','310098','640414','230279','333265','301309','520205','611756','221423','230128','610038','233668','322577','230603','230766','780148','780044','774765','470019','770095','160469','570009','730107','333250','343089','770136','161706','350067','210094','690079','743071','221383','427325','860327','720101','740159','543390','552288','558730','558738','703050','432326','550106','743046','550009','558746','560600','590043','740113','661969','360097','543430','590150','720001','720040','720107','740105','744052','720006','20288','20227','180053','21131','110029','230563','743077','20047','20218','427370','630582','660123','660397','668564','710034','860396','892307','560132','560155','450019','668502','661916','161627','590205','860295','560215','630239','630545','20151','180011','110052','593351','20096','20222','21129','21179','21317','729884','563341','610039','610324','634340','20049','640323','744050','773383','590061','610130','860268','860365','524761','120022','502352','230050','524591','583042','21144','21308','21361','84727','130026','160070','160257','161686','230311','432330','524708','530041','530076','560191','563178','590117','611674','677937','740012','743021','120007','593468','504045','580079','430332','230474','690044','130081','110019','593328','690712','180048','212966','21422','300020','400030','470091','560049','570047','640133','230056','300103','504067','680036','670108','780081','230596','690033','690075','760111','770075','680049','580111','460115','730125','600041','130004','350090','610680','630316','620073','333257','160085','520194','710126','161696','180160','230521','230950','233431','320069','330130','340026','343313','460126','530061','620112','160023','743063','777793','160355','212948','230334','460114','630289','744068','100074','161666','230998','260250','502478','560111','593437','670117','773458','230094','502470','630209','690012','161705','230992','233501','600124','623300','634338','710111','770007','580106','233622','212943','110054','230713','680090','10039','10035','20149','21141','100009','100017','113703','160096','160225','161590','166285','185929','210065','212988','230129','230772','233398','290031','310069','310136','312325','312335','333244','340143','480075','502386','504083','520215','160208','230045','230271','107025','430380','710089','760107','160493','180138','230207','580085','600084','610103','740074','130024','233418','300036','350070','470009','777760','610702','610361','580045','610624','210121','504099','504066','161653','161680','640127','370115','670110','110057','160203','161739','310146','100023','290038','502604','610602','640068','760023','301326','760056','260274','360019','520161','770219','330097','784345','160244','161603','517020','773352','110006','150037','160330','161609','182411','260018','290049','310115','340139','340192','343092','363579','430003','470024','470133','502341','504441','777962','570041','644701','784472','130012','470045','610364','774771','260257','530114','676555','230364','640023','770055','110056','161769','230548','310121','630307','670010','770063','780077','160388','670124','400107','310003','160335','230918','760152','160471','212979','230176','310047','310109','320095','340160','290068','530094','600130','730147','233679','524721','784316','502366','517029','670116','770125','440046','502582','504048','743029','773342','160218','530024','620014','230942','100010','770176','353022','340201','290066','640324','400047','773440','133825','160393','230155','524804','677929','530104','160304','310104','400074','670008','21171','784521','580049','583048','360180','640558','782493','773425','670101','640339','340210','623309','221417','427401','694756','450034','462335','610409','470173','777864','510464','370075','524835','623307','350046','508845','407583','21356','777836','470272','462316','212970','161703','543472','524848','113790','782530','363651','483638','508740','291893','21416','182424','343357','530138','301328','558786','593472','593475','668660','668658','668650','694802','777926','212952')


, cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment"
, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment"
from perenos pp
left join whs.document d on d.id_document = pp.id_document
left join doc_egais.send_doc_egais_tbl ww on ww.id_send_base = pp.id_op
left join whs.docreference df on df.id_doc_master = ww.id_document
--  left join whs.document wd
--   on wd.id_document = ww.id_document
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
--left join doc_egais.TICKET_DOC_HEADER_TBL yy on yy.id_document= ww.id_ticket
left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result








select
             /*+ index(d PK_DOCUMENT) use_nl(d)
                 index(df IDX_DOCREF_MASTER) use_nl(df)
                 index(th TICKET_DOC_HEADER_PK) use_nl(th)
                 index(t0 TICKET_DOC_OPRESULT_PK) use_nl(t0)
                 index(t1 TICKET_DOC_RESULT_PK)*/
pp.last_work_date
,pp.ka_id            
,pp.ka_code
,pp.ka_name
,pp.id_op
,pp.opnumber
,pp.opdate
,pp.opsum
,pp.oo_fullname
,pp.oo_code
,pp.id_top
,pp.top_fullname
,pp.id_send_status
,pp.id_document
,d.isdeleted
,d.lastdate         as "document_lastdate"
,pp.id_doctype
,pp.id_ticket
,pp.id_ticket1
,pp.status_description 
, cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment"
, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment"
, pp.tasknumber
, pp.taskdate
, pp.id_transfer_task
, pp.perenos_status as "������ ��������"
, pp.V as "�������"
, pp.excl as "� �����������"
from perenos pp
left join whs.document d on d.id_document = pp.id_document
left join doc_egais.send_doc_egais_tbl ww on ww.id_send_base = pp.id_op
left join whs.docreference df on df.id_doc_master = ww.id_document
--  left join whs.document wd
--   on wd.id_document = ww.id_document
left join doc_egais.ticket_doc_header_tbl th on th.id_document = df.id_doc_depend
--left join doc_egais.TICKET_DOC_HEADER_TBL yy on yy.id_document= ww.id_ticket
left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
    
    
-- ������ ����� � ��������� ����������
----���� ��������-�����
with op as(
select 
op.id_op as dochka
, op.OPNUMBER as op_kp
, op.id_top as idtop_kp
, wh.code as ka1_kp
, c.code as ka2_kp
, op2.id_op as roditel
, op2.OPNUMBER as op_rpm
, op2.id_top as idtop_rpm
, wh2.code as ka1_rpm
, c2.code as ka2_rpm
, opr.reftype
from whs.opreference opr
join whs.reftype rt on rt.code = opr.reftype 
join whs.operation op on opr.id_op = op.id_op 
join whs.warehouse wh on wh.id_ws = nvl (op.ID_WSI, op.ID_WSO)
join whs.contractor c on c.id_contr = op.ID_CONTR
join whs.operation op2 on opr.id_opref = op2.ID_OP
join whs.warehouse wh2 on wh2.id_ws = nvl (op2.ID_WSI, op2.ID_WSO)
join whs.contractor c2 on c2.id_contr = op2.ID_CONTR
where 
opr.id_op = -1339470702 -- �� ����� ���� ��������
)
, d481 as ( --481 �������
select op.roditel, doc.id_document, doc.docnumber, doc.docdate, dh.actdate, doc.id_doctype, doc.isdeleted, wbh.identity
from op op
join whs.doc_op do ON do.id_op = op.roditel
join whs.document doc ON doc.id_document = do.id_document
left join doc_egais.waybill_doc_header_tbl wbh on wbh.id_document = doc.id_document
join whs.document_history dh ON dh.id_document = doc.id_document and dh.action = 'I'
where doc.id_doctype = 481 and (doc.isdeleted = 0 OR doc.isdeleted is null)
)
, d483 as (
SELECT d481.id_document, doc2.id_document as d482_id, doc2.docnumber, doc2.docdate, doc2.id_doctype, doc2.isdeleted, fbh.wb_reg_id
   from d481
   join whs.docreference dref on dref.id_doc_master = d481.id_document
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
    left join doc_egais.wbinformbreg_doc_header_tbl fbh on fbh.id_document = doc2.id_document
       WHERE
      doc2.id_doctype = 483 and (doc2.isdeleted = 0 OR doc2.isdeleted is null)
)
select 
op.dochka
, op.op_kp
, op.idtop_kp
, op.ka1_kp
, op.ka2_kp
, op.roditel
, op.op_rpm
, op.idtop_rpm
, op.ka1_rpm
, op.ka2_rpm
, op.reftype
, d481.id_document as d481_ID
, d481.docnumber as d481_number
, d481.docdate as d481_docdate
, d481.actdate as d481_create
, d481.id_doctype as d481_iddoctype
, d481.isdeleted as d481_isdel
, d481.identity as d481_identity
, d483.d482_id
, d483.docnumber as d483_number
, d483.docdate as d483_docdate
, d483.id_doctype as d483_iddoctype
, d483.isdeleted as d483_isdel
, d483.wb_reg_id as d483_wbregid
from op
left join d481 on d481.roditel = op.roditel
left join d483 on d483.id_document = d481.id_document

select * from doc_egais.wbinformbreg_doc_header_tbl wbh


--481 
select op.id_Op, op.OPNUMBER, op.opdate, op.opsum, op.opguid, doc.id_document, doc.docnumber, doc.docdate, dh.actdate, doc.id_doctype, doc.isdeleted, art.NAME, drd.*
from whs.operation op
join whs.doc_op do ON do.id_op = op.id_op
join whs.document doc ON doc.id_document = do.id_document
left join whs.doc_rda_detail drd ON drd.id_document = doc.id_document
left join whs.article art ON art.ID_ART = drd.id_art
join whs.document_history dh ON dh.id_document = doc.id_document and dh.action = 'I'
where
     op.id_op in (-1339470696)
     --do.id_document in (356883974)
     and
     doc.id_doctype = 481

--483
SELECT *
   FROM whs.docreference dref
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
       WHERE
      dref.id_doc_master IN (502092219) -- ����������� id ����, ��� (481)
      and doc2.id_doctype = 483--482 


-- ����������� �� � �2. ������� ������ v2.0
with ri as --������ ������ �����
(
select r.id_art, r.id_ws, wh.code as wscode, a.CODE as art_code, a.NAME, max (r.rowid) as ri
from whs.rest r
join whs.warehouse wh on wh.id_ws = r.id_ws
--join mm_work mm on mm.code = wh.code 
join whs.article a on a.ID_ART = r.id_art
join whs.art_moreinfo am on am.id_art = r.id_art
join whs.addition adi on adi.ID_ADD = am.id_add
where 
wh.code in ('680022','640048','640110','640134','730030','730008','680004','730002','640139','730031','640086','730007','730034','680021','680024','680018','640111','680005','640094','640015','680025','680007','640129','730032','680003','730041')
/*--wh.lg1 in (101,201)*/ 
and am.vstring not like '000' -- ���������� ��������������� ����
and adi.name like '���_���'
group by r.id_ws, wh.code, r.id_art, a.CODE, a.NAME
)
, rest_tu as (
select ri.id_art, ri.id_ws, ri.wscode, ri.ri, r.fquant, r.lastdate /* r.**/ from ri
join whs.rest r on r.rowid = ri.ri
--join whs.article a on a.id_art = ri.id_art
where r.fquant > 0
)
, rest_vw as ( --������� � ����� �2
select 
vw.wscode
,  vw.art_code
, a.id_art
, sum (vw.quantity) as quantity
from ri a
join RETAIL.Registr_Rest_Vw vw on vw.wscode = a.wscode and vw.art_code = a.art_code
where vw.rest_type in ('1','2','5')
group by vw.wscode,  vw.art_code, a.id_art
)
, rest_vw_34 as ( --������� � ����� �2 �� ����������� � �����
select 
vw.wscode
,  vw.art_code
, a.id_art
, sum (vw.quantity) as quantity
from ri a
join RETAIL.Registr_Rest_Vw vw on vw.wscode = a.wscode and vw.art_code = a.art_code
where vw.rest_type in ('3','4')
group by vw.wscode,  vw.art_code, a.id_art
)
select
a.wscode
, sum (rt.fquant) as "REST_TU"
, sum (rv.quantity) as "REST_R2"
, sum (rv34.quantity) as "REST_R2_t3-4"
, case when sum (rt.fquant) > sum (rv.quantity) then '1' else '0' end as "TU>R2"
from ri a
left join rest_vw rv on rv.id_art = a.id_art and rv.wscode = a.wscode
left join rest_vw_34 rv34 on rv34.id_art = a.id_art and rv34.wscode = a.wscode
left join rest_tu rt on rt.id_art = a.id_art and rt.wscode = a.wscode
where ((rt.fquant is not null OR rt.fquant > 0) 
and rt.fquant > rv.quantity) -- �������� ��� �������
OR (rv.quantity < 0 and rt.fquant > 0)
-- � ������� ��
group by a.wscode



select wdc.identity from whs.opreference opr
join whs.operation op on op.id_op = opr.id_opref and op.ID_TOP=169
join whs.doc_op do on do.id_op=op.ID_OP
join whs.document d on d.id_document=do.id_document and d.id_doctype=481 and (d.isdeleted=0 or d.isdeleted is null)
join doc_egais.waybill_doc_header_tbl wdc on wdc.id_document=d.id_document
where opr.id_op = -1425362737


select doc483.id_document as d483document,doc483.isdeleted as d483deleted,d481.id_document,d481.isdeleted from whs.doc_op do
join whs.document d481 on d481.id_document = do.id_document and d481.id_doctype=481
left join whs.docreference docr on docr.id_doc_master=d481.id_document
join whs.document doc483 on doc483.id_document= docr.id_doc_depend and doc483.id_doctype=483
where do.id_op= -1425362737 and (d481.isdeleted is null OR d481.isdeleted = 0)



select distinct  
doc.id_document
, doc.docnumber
, doc.docdate
, doc.isdeleted
, c_ka.code as code_ka  
,ka.kpp as kpp2  
,ka.code 
,ool_ka.*
, op.id_op
, op.opnumber
, op.opdate
, op.opsum
, op.typeop
, sde.id_send_status
, sde.id_document as id_document_sde
, sde.id_doctype as id_doctype_sde
, op.id_contr
, do_ka.code as FSRARID_SHIPPER
, do_oo.code as FSRARID_CONSIGNEE
, op.opguid
, dev.wb_reg_id 
from whs.document doc 
join doc_egais.waybill_doc_header_tbl wh on wh.id_document = doc.id_document 
join doc_egais.organization_tbl do_oo on do_oo.id_organization = wh.id_consignee 
join onsi_egais.organization_tbl oo on oo.code = do_oo.code 
join onsi_egais.org_kpp_link_tbl ool_oo on ool_oo.id_organization = oo.id_organization 
join whs.contractor c_oo on c_oo.inn = oo.inn and c_oo.kpp = oo.kpp and c_oo.id_contr = 84423 
join whs.group_contr gr_oo on gr_oo.id_grcontr = c_oo.id_grcontr and gr_oo.fullname like '���� ��%' 
join doc_egais.organization_tbl do_ka on do_ka.id_organization = wh.id_shipper 
join onsi_egais.organization_tbl ka on ka.code = do_ka.code 
join onsi_egais.org_kpp_link_tbl ool_ka on ool_ka.id_organization = ka.id_organization 
join whs.contractor c_ka on c_ka.inn = ka.inn and c_ka.id_contr = 16018 
left join whs.doc_op do on do.id_document = doc.id_document 
left join whs.operation op on op.id_op = do.id_op 
left join doc_egais.send_doc_egais_tbl sde on sde.id_send_base = op.id_op 
left join whs.docreference dref on dref.id_doc_master = doc.id_document 
left join whs.DOCUMENT doc483 on doc483.id_document = dref.id_doc_depend and doc483.id_doctype = 483 
join whs.docfileset dfs483 ON dfs483.id_document = doc483.id_document and doc483.id_document is not null 
left join whs.docfile df483 ON df483.id_dfs = dfs483.id_Dfs 
left join doc_Egais.Wbinformbreg_Doc_Header_Tbl dev on dev.id_document = doc483.id_document 
where (op.typeop <> 20 or op.id_op is null) 
and doc.docnumber = '110019A2265' 
and doc.id_doctype = 481


select distinct  doc.id_document, doc.docnumber, doc.docdate, doc.isdeleted, c_ka.code as code_ka  ,ka.kpp as kpp2   ,ka.code  ,ool_ka.*, op.id_op, op.opnumber, op.opdate, op.opsum, op.typeop, sde.id_send_status, sde.id_document as id_document_sde , sde.id_doctype as id_doctype_sde, op.id_contr, do_ka.code as FSRARID_SHIPPER, do_oo.code as FSRARID_CONSIGNEE, op.opguid ,dev.wb_reg_id from whs.document doc join doc_egais.waybill_doc_header_tbl wh on wh.id_document = doc.id_document join doc_egais.organization_tbl do_oo on do_oo.id_organization = wh.id_consignee join onsi_egais.organization_tbl oo on oo.code = do_oo.code join onsi_egais.org_kpp_link_tbl ool_oo on ool_oo.id_organization = oo.id_organization join whs.contractor c_oo on c_oo.inn = oo.inn and c_oo.kpp = oo.kpp and c_oo.id_contr = 84423 join whs.group_contr gr_oo on gr_oo.id_grcontr = c_oo.id_grcontr and gr_oo.fullname like '���� ��%' join doc_egais.organization_tbl do_ka on do_ka.id_organization = wh.id_shipper join onsi_egais.organization_tbl ka on ka.code = do_ka.code join onsi_egais.org_kpp_link_tbl ool_ka on ool_ka.id_organization = ka.id_organization join whs.contractor c_ka on c_ka.inn = ka.inn and c_ka.id_contr = 16018 left join whs.doc_op do on do.id_document = doc.id_document left join whs.operation op on op.id_op = do.id_op left join doc_egais.send_doc_egais_tbl sde on sde.id_send_base = op.id_op left join whs.docreference dref on dref.id_doc_master = doc.id_document left join whs.DOCUMENT doc483 on doc483.id_document = dref.id_doc_depend and doc483.id_doctype = 483 join whs.docfileset dfs483 ON dfs483.id_document = doc483.id_document and doc483.id_document is not null left join whs.docfile df483 ON df483.id_dfs = dfs483.id_Dfs left join doc_Egais.Wbinformbreg_Doc_Header_Tbl dev on dev.id_document = doc483.id_document where (op.typeop <> 20 or op.id_op is null) and doc.docnumber = '110019A2265' and doc.id_doctype = 481


-- ���� �� �� �� ���������� ����������� � �����
select distinct wh.code from whs.warehouse wh
join doc_egais.send_doc_egais_tbl s on s.ws_guid = wh.guid
where wh.code in ('782707')
and s.id_send_status in (1,2,3,4,5,6,7,8,9,10)




-- ���������� ������� �� ��
-- �������� � ����������� �� ��������� � ����������
-- ���� ������� ����� 3 ����� - ����� �������� �������� � ����������� �� ��
select s.id_send_base, s.id_send_status, s.id_send_substatus, s.id_send_type, s.id_document from whs.warehouse wh
join doc_egais.send_doc_egais_tbl s on s.ws_guid = wh.guid
where wh.code in ('770097')
and s.id_send_status in (7)
union
select s.id_send_base, s.id_send_status, s.id_send_substatus, s.id_send_type, s.id_document 
from whs.warehouse wh
join whs.operation op on nvl(op.ID_WSI, op.ID_WSO) = wh.id_ws
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
where wh.code in ('770097')
and 
(
    (
      op.ID_TOP = 1
      and EXISTS (
             select 1 from whs.opreference opr 
             join whs.operation op2 on op2.ID_OP = opr.id_opref and op2.ID_TOP = 169
             join doc_egais.send_doc_egais_tbl s2 on s2.id_send_base = op2.ID_OP and s2.id_send_status = 11
             where opr.reftype = 'E'
             and opr.id_op = op.ID_OP
             )
    )
    OR 
    (
      (op.ID_TOP = 17 and op.OPSUM > 0  OR op.ID_TOP = 635)
      and EXISTS (
             select 1 from whs.opreference opr 
             join whs.operation op2 on op2.ID_OP = opr.id_op and op2.ID_TOP = 169
             join doc_egais.send_doc_egais_tbl s2 on s2.id_send_base = op2.ID_OP and s2.id_send_status = 11
             where opr.reftype = 'E'
             and opr.id_opref = op.ID_OP
             )
    )
    /*OR (op.ID_TOP = 17 and op.OPSUM < 0)*//*��������� �������� � �������� ���*/
    OR op.ID_TOP not in (1,17,635,634)
)
and s.id_send_status in (3)




-- �������� � ����������� �� ��������� � ����������
-- ���� ������� ����� 3 ����� - ����� �������� �������� � ����������� �� ��
select s.id_send_base, s.id_send_status, s.id_send_substatus, s.id_send_type, s.id_document from whs.warehouse wh
join doc_egais.send_doc_egais_tbl s on s.ws_guid = wh.guid
where wh.code in ('770097')
and s.id_send_status not in (11)
union
select s.id_send_base, s.id_send_status, s.id_send_substatus, s.id_send_type, s.id_document 
from whs.warehouse wh
join whs.operation op on nvl(op.ID_WSI, op.ID_WSO) = wh.id_ws
join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
where wh.code in ('770097')
and 
(
    (
      op.ID_TOP = 1
      and EXISTS (
             select 1 from whs.opreference opr 
             join whs.operation op2 on op2.ID_OP = opr.id_opref and op2.ID_TOP = 169
             join doc_egais.send_doc_egais_tbl s2 on s2.id_send_base = op2.ID_OP and s2.id_send_status = 11
             where opr.reftype = 'E'
             and opr.id_op = op.ID_OP
             )
    )
    OR 
    (
      (op.ID_TOP = 17 and op.OPSUM > 0  OR op.ID_TOP = 635)
      and EXISTS (
             select 1 from whs.opreference opr 
             join whs.operation op2 on op2.ID_OP = opr.id_op and op2.ID_TOP = 169
             join doc_egais.send_doc_egais_tbl s2 on s2.id_send_base = op2.ID_OP and s2.id_send_status = 11
             where opr.reftype = 'E'
             and opr.id_opref = op.ID_OP
             )
    )
    /*OR (op.ID_TOP = 17 and op.OPSUM < 0)*//*��������� �������� � �������� ���*/
    OR op.ID_TOP not in (1,17,635,634)
)
and s.id_send_status not in (11)




select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1685752782

select * from whs.reftype rtt where rtt.code = 'E' OR rtt.code = '�'

select 
     -- sd.id_send
      btar.id_document AS "�� ����",
     -- doc.docguid AS "���� ����",
      '��������',
      bac.id_action,
      sta.name,
      sd.id_send_status RASHST,
      sd2.id_send_status PRST,
    --  bac.id_type_action,
      '����.',
      sd.id_send,
      op.id_op AS "�� ���.", 
      op.OPNUMBER NUM, 
      op.OPDATE AS "DATEO",
      op.ID_TOP AS "TYPE",
      ws.lg1,
      ws.fullname AS "WS",
      sd.add_date AS "DATEA", 
      sd.id_document IDDOC, 
      sd.id_send_status STATUS, 
      sd.description AS "DESC", 
      coalesce(sd.ticket_date, sd.send_date, sd.last_work_date) As DATEL,
      nvl(sd3.id_ticket, sd.id_ticket) AS "TD1",
      '��������� ��-���',
      sd2.id_Send,
      op2.id_op, 
      op2.OPNUMBER NUM, 
      op2.OPDATE DATEO, 
      op2.ID_TOP, 
      ws2.fullname WS2,
      sd2.id_send_status STATUS, 
      sd2.add_date AD, 
      sd2.id_document IDDOC, 
      sd2.description AS "DESC", 
      coalesce(sd2.ticket_date, sd2.send_date, sd2.last_work_date) AS DATEL,
      sd2.id_ticket,
      dtb.reply_id, dtb.lastdate
from acan.BB_TARGET_TBL btar
join acan.bb_task_tbl btas ON btas.id_target = btar.id_target
join acan.BB_ACTION_TBL bac ON bac.id_task = btas.id_task
join whs.document doc ON doc.id_document = btar.id_document
left join acan.BB_RESULT_TBL brs On brs.id_action = bac.id_action
join acan.bb_status_action_vw sta ON sta.id_status = bac.id_status
--��������, ��������� � ������ ��
left join doc_Egais.Send_Doc_Egais_Tbl sd 
     join whs.operation op 
     join whs.opreference opf     
     join whs.operation op2 ON op2.ID_OP = opf.id_op
                            ON opf.id_opref = op.id_op and opf.reftype = 'E'
                            ON op.ID_OP = sd.id_send_base
                            ON sd.id_send_base = brs.id_op and bac.id_type_action = 5
     left join doc_Egais.Send_Doc_Egais_Tbl sd2 ON sd2.id_send_base = opf.id_op
     left join whs.warehouse ws ON ws.id_ws = nvl(op.ID_WSI, op.ID_WSO)
     left join whs.warehouse ws2 ON ws2.id_ws = nvl(op2.ID_WSI, op2.ID_WSO)
     left join doc_Egais.Reg_Transfer_Task_Tbl rt ON rt.id_op = sd2.id_send_base
     left join doc_Egais.Send_Doc_Egais_Tbl sd3 ON sd3.id_send_base = rt.id_transfer_task and sd3.id_send_type = 6  
     left join doc_Egais.document_tbl dtb ON dtb.id_document = sd.id_Document                                      
where
     btar.id_document in (579472715)
     and bac.id_type_action in (5)
     and sta.name not in ('���������', '���������� � �������')--, '��������������')  
     and sd.id_send_status = 7 -- and sd2.id_send_status = 3
     --and sd.id_send is not null
     and ws.lg1 != 601 
     --and sd.id_send_base in (-1428213220, -1428217239, -1428197123)
order by 5 desc;  

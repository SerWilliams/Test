--------------------------------------------------------------------------------------------------  
----------------------------------------�������� ���������----------------------------------------
--------------------------------------------------------------------------------------------------
 SELECT sdt2.id_send_status, count (op.id_op)
FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sdt1 on sdt1.id_send_status =sdt.id_send_status 
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1
--left join whs.docreference df ON df.id_doc_master = sdt2.id_document
JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate -->= '01.01.2016'
between  '01.04.2016' and '30.06.2016'-- and op.opdate < to_date(sysdate-2)
-->= '20.05.2016' and op.opdate < to_date(sysdate-2)
and ws.lg1=601
and op.id_top = 169
--and ws2.lg1 in (101)
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top  in (1)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is  null)
and sdt2.id_send_status is not null
group by sdt2.id_send_status
--------------------------------------------------------------------------------------------------  
----------------------------------------�������� ���������----------------------------------------
--------------------------------------------------------------------------------------------------  
/*  select 
round((sysdate-last_work_date),0),  --������� � ����
  op.id_top,top.fullname, sdt.id_Send_status,count(op.id_op) from doc_egais.send_doc_egais_tbl sdt 
  join whs.operation op on op.id_op = sdt.id_send_base and sdt.id_send_type = 1
  join whs.typeop top on top.id_top = op.id_top
  where 1=1  
  and sdt.last_work_date < sysdate-1/12
  and sdt.last_work_date >'01.07.2016'
  and sdt.id_Send_status = 7
  group by 
  round((sysdate-last_work_date),0),
  op.id_top,top.fullname,sdt.id_Send_Status
  order by sdt.id_Send_Status; */

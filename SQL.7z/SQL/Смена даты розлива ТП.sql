select op.id_Op, op.OPNUMBER, op.opdate, doc.id_document, doc.docnumber, doc.docdate, doc.id_doctype, doc.isdeleted, art.NAME, drd.*
from whs.operation op
join whs.doc_op do ON do.id_op = op.id_op
join whs.document doc ON doc.id_document = do.id_document
left join whs.doc_rda_detail drd ON drd.id_document = doc.id_document
left join whs.article art ON art.ID_ART = drd.id_art
where
     op.id_op in (-1085909177)
    -- and doc.id_doctype = 376
order by doc.isdeleted, doc.id_document asc
     


-- ����� ���� �������     
UPDATE whs.document doc
SET doc.docdate = to_date('25.09.15')
WHERE doc.id_doctype = 376
  and doc.id_document = 170541368;
commit;

select * from whs.document where id_document = 170541368

select * from whs.docreference dr 
join whs.document d on d.id_document = dr.id_doc_master
where dr.id_doc_depend = 170541368

-- ���� ������� �� FB-���
select distinct wbf.reg_id_b, ra.bottling_date from doc_egais.wbinformbreg_doc_content_tbl wbf
join doc_egais.wbinformbreg_doc_header_tbl wbh on wbh.id_document = wbf.id_document
join doc_egais.waybill_doc_header_tbl wh on wh.identity = wbh.id_wb
join doc_egais.waybill_doc_content_tbl wc on wc.id_document = wh.id_document and wc.wbi_reg_id_b = wbf.reg_id_b
join doc_egais.product_tbl p on p.id_product = wc.id_product
join doc_egais.replyforma_doc_header_tbl ra on ra.reg_id = wc.reg_id_a
where wbf.reg_id_b = 'FB-000000090030685'


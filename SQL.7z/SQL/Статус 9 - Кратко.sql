SELECT 'file://///Esb-egais-01/egais/' || to_char(df.lastdate, 'dd-mm-yyyy') || '/' || df.filename
FROM whs.DOCUMENT doc
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE
doc.id_document in (916486432) 

420105109
548594252


select * from whs.operation where opnumber = '720027A3034'
select * from doc_egais.send_doc_egais_tbl s where s.id_send_base in (-1768225480)

 SELECT *
FROM whs.DOCUMENT doc
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE 
--doc.docguid in hextoraw('B5D669ACD90F1000018078542E709247')
--doc.id_document in (683526394)
df.filename like ('3BF55ADD4AC94BC9A99565B7D74E9875%')

7A087D35197642F188A42B3B63CE89B1
A2A92BBCE674445F91E4E3A9BD615EF6
3BF55ADD4AC94BC9A99565B7D74E9875


SELECT doc.id_document, doc.id_doctype, doc.isdeleted
FROM whs.DOCUMENT doc
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE 
df.filename like ('5F70EF234FB04C6D9557489BF1837D3A%')


select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1260112422
select * from whs.document where id_document = 375230046--375740091 (482)

select * from whs.docreference where id_doc_master = 411180060

-- ���� ���������
 SELECT *
   FROM whs.docreference dref
    left JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_master
       WHERE
      dref.id_doc_depend IN (716230143) -- ����������� id ����, ��� (481)
      and doc2.id_doctype = 482
      order by doc2.id_document
      
select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1536999276
 s.id_document = 694700798 

-1536999276 
�� ������� ��� 715051937
� ����� 713378425      
update whs.document d
set d.isdeleted = 1
where d.id_document = 715051937
and d.id_doctype = 482;
commit;

-- ���� �����
 SELECT *
   FROM whs.docreference dref
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
       WHERE
      dref.id_doc_master IN (762133715,762133733) -- ����������� id ����, ��� (481)
     -- group by doc2.id_doctype
      and doc2.id_doctype = 483
      order by doc2.id_document      
532927295	481
  -- 563643300 483 �����
�������� -1330734803
  -- 495086222 481
      -- 495086223  483
      
select * from ACAN.CNB_TASK_DETAIL_PACKS_TBL



-- ���� �����
 SELECT doc2.id_doctype, count (1)
   FROM whs.docreference dref
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
       WHERE
      dref.id_doc_master IN (662602432) -- ����������� id ����, ��� (481)
      group by doc2.id_doctype
      and doc2.id_doctype = 483
      order by doc2.id_document
      
      
-- ����� ������ �� 483 �� id ����
SELECT 'file://///Esb-egais-01/egais/' || to_char(df.lastdate, 'dd-mm-yyyy') || '/' || df.filename
FROM whs.docreference dref
JOIN whs.DOCUMENT doc on doc.id_document = dref.id_doc_depend
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE
dref.id_doc_master IN (762133715,762133733) --481
and doc.id_doctype = 483
order by doc.id_document


-- �� �� id_op
select d.*, do.*, op.* from whs.operation op
left join whs.doc_op do on do.id_op = op.id_op
left join whs.document d on d.id_document = do.id_document
where op.id_op in (-1770290053)
and d.id_doctype = 481
do.id_document = 662602432

update whs.document d set d.isdeleted = '1' where d.id_document in (762133695,762133555)
commit;


select s.id_send_status, s.send_date, op.* from whs.operation op 
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
where op.OPNUMBER in ('427436M5828', '427436M5845','427436M5852','427436M5855','427436M5862','427436M5864','427436M5872')

-- 376 �������
select a.code, a.name, a.id_art, oa.quantity, dt.quantity as "���-�� � ��������", dt.*, d.*, do.*, op.* from whs.operation op
join whs.doc_op do on do.id_op = op.id_op
join whs.op_art oa on oa.id_op = op.id_op
join whs.article a on a.id_art = oa.id_art
join whs.document d on d.id_document = do.id_document and d.id_doctype = 376
left join whs.doc_rda_detail dt on dt.id_document = do.id_document and oa.id_art = dt.id_art
where op.id_op in (-1519221946
,-1520418811
,-1520418786
,-1520418779
,-1520418766
,-1520418757
,-1520418738
)

select * from whs.doc_rda_detail where id_doc_rda_detail in (10749209
,10749341
,10749192
,10749107
,10749160
,10749287
,10749247)
UPDATE whs.doc_rda_detail set quantity = '12' where id_doc_rda_detail in (10749209
,10749341
,10749192
,10749107
,10749160
,10749287
,10749247)
commit;

select * from whs.op_art where id_op in (-1519221946
,-1520418811
,-1520418786
,-1520418779
,-1520418766
,-1520418757
,-1520418738
)

select * from whs.doc_rda_detail dt where dt.id_document = 678981829
select * from whs.


/
select d.docnumber, d.docdate, d.id_document, d.id_doctype, d.isdeleted, do.*, op.* from whs.operation op
left join whs.doc_op do on do.id_op = op.id_op
left join whs.document d on d.id_document = do.id_document
where op.id_op = -1531655227
and d.id_doctype in (2, 376, 481) and (d.isdeleted is null OR d.isdeleted = '0')
order by d.id_doctype
/

select * from doc_egais.send_doc_egais_tbl s where s.id_document = 660989954


678222744
685031629
update whs.document d
set d.isdeleted = 1
where d.id_document in (686371652) and d.id_doctype = 482;
commit;
select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1508395799
489300769

select * from whs.document where docnumber = '550028A2560' and docdate >='14.01.17' and id_doctype = 482
select * from whs.document_history dh where dh.id_document = 500618776     
� ���� - 500618775 16.01.17 11:26:13,000000000 DOC_EGAIS
� �� - 500626125 16.01.17 10:26:16,000000000 DOC_EGAIS

--������� ������� ����������
select * from doc_egais.send_doc_egais_history_tbl h where h.id_send_base = -1334418759
select * from doc_egais.send_doc_egais_tbl s where s.id_send_base = -1334418759

���� �� ���� ��� ������, ����� id ��������� � ����� 482 �� ���������� ����������� � �������� .
���� ����������� � ���� ������.  ����� - ��� ������ �� �����. ��� ��������� 480.

    SELECT *
    FROM whs.docreference dref
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
       WHERE
      dref.id_doc_master IN (188945408)
      
      
select * from whs.doc_op where id_document = 488489731

select * from whs.operation where opnumber = '���00011986'

      

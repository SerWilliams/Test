-- ���� �� ������� ������� ��������
select distinct
   d3.id_document
   , d3.id_doctype
   , d3.docnumber
   , d3.docdate
   , c.code as "��� ��"
   , c.name as "������������ ��"
   , c2.code as "��� ��"
   , c2.name as "������������ ��"
from whs.operation o
left join whs.op_art oa on oa.id_op = o.id_op
left join whs.article a on a.id_art=oa.id_art
left join whs.art_moreinfo am
     join whs.addition addi on addi.ID_ADD = am.id_add and addi.NAME = '���_���'
                            on am.id_art = a.ID_ART
left join whs.alc_art_type aat on aat.alc_art_code = am.vstring
left join whs.art_moreinfo am2
     join whs.addition addi2 on addi2.ID_ADD = am2.id_add and addi2.NAME = '���_�����'
                             on am2.id_art = a.ID_ART
left join whs.doc_rda_detail rda
     join whs.document d on d.id_document = rda.id_document and nvl(d.isdeleted,0) = 0
                         on rda.id_op = o.ID_OP and rda.id_art = oa.ID_ART
join whs.docreference dref on dref.id_doc_depend = d.id_document
join whs.document d2 on d2.id_document = dref.id_doc_master
join whs.docreference dref3 on dref3.id_doc_depend = dref.id_doc_master
join whs.document d3 on d3.id_document = dref3.id_doc_master
join doc_egais.waybill_doc_header_tbl wh on wh.id_document = d3.id_document
join doc_egais.organization_tbl do on do.id_organization = wh.id_shipper
join onsi_egais.organization_tbl oo on oo.code = do.code
--join onsi_egais.org_kpp_link_tbl ool on ool.id_organization = oo.id_organization
join whs.contractor c on c.inn = oo.inn
join doc_egais.organization_tbl do2 on do2.id_organization = wh.id_consignee
join onsi_egais.organization_tbl oo2 on oo2.code = do2.code
--join onsi_egais.org_kpp_link_tbl ool on ool.id_organization = oo.id_organization
join whs.contractor c2 on c2.inn = oo2.inn
                     and c2.kpp = oo2.kpp
--join whs.group_contr gr2 on gr2.id_grcontr = c2.id_grcontr
where d2.id_doctype in (477, 478)
and d3.id_doctype = 481
--and c.name like '%��%'
--and gr2.fullname like '���� ��%';
and o.id_op =  -977327698

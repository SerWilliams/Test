with tt as(
select op.id_Op, op.OPNUMBER, op.opdate, /*doc1.id_document, doc1.docnumber, doc1.id_doctype, doc1.isdeleted,*/ doc2.id_document, doc2.docnumber, doc2.id_doctype, doc2.isdeleted, tdht.reg_id
from whs.operation op
join whs.doc_op do ON do.id_op = op.id_op
join whs.document doc1 ON doc1.id_document = do.id_document
left join whs.doc_rda_detail drd ON drd.id_document = doc1.id_document
left join whs.article art ON art.ID_ART = drd.id_art
left join whs.docreference dref on dref.id_doc_master = doc1.id_document
left join whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
left join doc_Egais.Ticket_Doc_Header_Tbl tdht on tdht.id_document=doc2.id_document
where op.id_op = :idop1
and doc1.id_doctype = 481
and doc2.id_doctype = 480
and tdht.doc_type = 'WAYBILL'
)
select /*'�(�)�' as TYPE_OP, (select id_op from tt) as ID_OP,*/'480' as DOC_TYPE,tdht1.id_document
from doc_Egais.Ticket_Doc_Header_Tbl tdht1
left join whs.docreference dref1 on tdht1.id_document = dref1.id_doc_depend
where tdht1.reg_id = (select reg_id from tt)
and tdht1.doc_type = 'WAYBILL'
and tdht1.id_document <> (select id_document from tt)
and tdht1.id_document is not null and dref1.id_doc_depend is null
union
/*����� 482 ��� �������*/
select '482', doc2.id_document
from whs.operation op
join whs.doc_op do ON do.id_op = op.id_op
join whs.document doc1 ON doc1.id_document = do.id_document
left join whs.doc_rda_detail drd ON drd.id_document = doc1.id_document
left join whs.article art ON art.ID_ART = drd.id_art
left join whs.docreference dref on dref.id_doc_master = doc1.id_document
left join whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
where op.id_op = :idop2
and doc1.id_doctype = 481
and doc2.id_doctype = 482

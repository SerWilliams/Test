select 
sdt.id_send_status as "������ � ���", 
op.opdate as "���� ��������",
op.opnumber as "����� ��������",
op.opguid as "���� ��������",
w.code as "��� ��",
w.fullname as "��� ��",
co.code as "��� ��",
co.name as "��",
art.code as "��� ������",
art.name as "�����",
oa.quantity as "����������"
         from whs.operation op
         join doc_egais.send_doc_egais_tbl sdt on sdt.id_send_base = op.id_op and sdt.id_send_type =1   
         join whs.warehouse w on w.id_ws = op.id_wsi
         join whs.contractor co on co.id_contr = op.id_contr
         join whs.op_art oa on oa.id_op = op.id_op
         join whs.article art on art.id_art = oa.id_art
         where 1=1 
         and op.id_top = 15
         and op.opdate > '31.12.2015'
         and op.opdate < '01.07.2016'
         and sdt.id_Send_status <>11
         and sdt.id_Send_status <>12
         
         
select * from whs.operation op
join doc_egais.send_doc_egais_tbl st on st.id_send_base = op.id_op
  left join whs.docreference df
    on df.id_doc_master = st.id_document
  left join doc_egais.ticket_doc_header_tbl th
    on th.id_document = nvl(st.id_ticket, df.id_doc_depend)
  left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
  left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
where op.id_op in (-943925412,-943925412,-944836169,-944836169,-945673644,-945673644,-945904665,-945904665,-946731096,-946731096,-947556327,-947556327,-948292051,-949154627,-949154627,-950078523,-950078523,-951185843,-951391534,-951929190,-952909668,-952909668,-954070817,-954070817,-954869563,-954869563,-955807054,-955807054,-957044116,-957630603,-959179141,-959179141,-959570106,-960741636,-961167413,-962175993,-963004375,-963906537,-964462568,-965093001,-965093001,-966007847,-966690794,-966794592,-967746022,-968450525,-969601995)


select * from whs.operation op 
join whs.warehouse w on w.id_ws = op.id_wsi
where op.id_op = -717272398 op.opnumber = '����-000924'

select * from whs.document d where d.docnumber = '��-924'
select * from whs.docreference dr where dr.id_doc_master = 67881254
select * from whs.doc_op d where d.id_document = 79456856


select * from whs.opreference opr
join whs.operation op on op.id_op = opr.id_opref
join doc_egais.send_doc_egais_tbl st on st.id_send_base = op.id_op
  left join whs.docreference df
    on df.id_doc_master = st.id_document
  left join doc_egais.ticket_doc_header_tbl th
    on th.id_document = nvl(st.id_ticket, df.id_doc_depend)
  left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
  left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
where opr.id_op in (-943925412,-943925412,-944836169,-944836169,-945673644,-945673644,-945904665,-945904665,-946731096,-946731096,-947556327,-947556327,-948292051,-949154627,-949154627,-950078523,-950078523,-951185843,-951391534,-951929190,-952909668,-952909668,-954070817,-954070817,-954869563,-954869563,-955807054,-955807054,-957044116,-957630603,-959179141,-959179141,-959570106,-960741636,-961167413,-962175993,-963004375,-963906537,-964462568,-965093001,-965093001,-966007847,-966690794,-966794592,-967746022,-968450525,-969601995)


select * from whs.sh_task sht where sht.guid = DF9CE472D90F1000018074D435DB16CC

select * from whs.operation where opguid = hextoraw ('33803A20C3BA436EE0530921080A1732')
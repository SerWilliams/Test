-- ����� ��������, � ������� ��� �� � �������
select * from whs.operation op
where (select count (id_op) from whs.op_art oa where oa.id_op = op.id_op) = 0
and op.id_op in (-718873377,-718875869,-718898802)


--��������� � �������� �� � �� ������� ������
select * from whs.operation op
join whs.op_art oa on oa.id_op = op.id_op
where oa.quantity = 0
and op.opsum <> 0
and op.id_op in (-718873377,-718875869,-718898802)


-- ����� ������ �� �� ��������
select 
op.ID_OP, op.id_top, s.id_send_status,
op.opnumber
, op.opdate
, op.opsum
, a.code
, a.name
, oa.price
, oa.quantity
, oa.opsum
--, oa.* 
--, a.*
--count (op.id_op)
from whs.operation op
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
join whs.op_art oa on oa.id_op = op.id_op
join whs.article a on a.id_art = oa.id_art
-- -943925412
where op.OPNUMBER = '773083A1935/1'
--op.id_op in (-1222738282)
op.OPGUID in (                            
hextoraw('B303F304D90F10000280C412F5344416')
,hextoraw('50C0C89CD90F10000680C412F5344416')
)
order by op.opdate, op.opnumber

select * from whs.historyop h where h.opnumber = '773083A1935/1' and h.opdate >= '01.01.2017'
select * from whs.operation where id_op = -1342071077


select wh.fullname 
from whs.operation op
join whs.warehouse wh on wh.id_ws = op.id_wsi
where op.opnumber in ('020111D0923','020287D0789','020297D0489','160086D0953','160086D0954','161595D0574','161661D0217','161674D0335','161674D0336','353020D0795','475436D0755','560048D1542','560056D1509','560078D1408','560081D1902','560121D1632','560179D1168','560219D1212','560611D0637','563345D0117','563350D0145','563357D0108','563363D0363')
and op.opdate >= to_date( '01.01.16' )







-- �������� ������� �� ���. ���� ��� ������
select distinct
op.ID_OP, op.OPNUMBER, op.OPDATE, op.OPSUM, s.id_send_status, ss.name as "�������� ������� ���", p.alc_code, wc.quantity, wbc.reg_id_b
from
doc_egais.product_tbl p
join doc_egais.waybill_doc_content_tbl wc on wc.id_product = p.id_product
left join doc_egais.waybill_doc_header_tbl wh on wh.id_document = wc.id_document
left join doc_egais.wbinformbreg_doc_header_tbl wbh on wbh.id_wb = wh.identity
left join doc_egais.wbinformbreg_doc_content_tbl wbc on wbc.id_position = wc.id_position and wbc.id_document = wbh.id_document
left join whs.doc_op dop on dop.id_document = wh.id_document
left join whs.operation op on op.ID_OP = dop.id_op
join whs.warehouse w on w.id_ws = op.ID_WSI
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.ID_OP
left join doc_egais.send_doc_status_egais_tbl ss on ss.id_send_status = s.id_send_status
where 
p.alc_code in ('0014247000001191302') -- ���. ����
--wbc.reg_id_b in ('FB-000000290404216','FB-000000245378691','FB-000000312448734','FB-000000245375589','FB-000000306421224','FB-000000274951307','FB-000000266361173','FB-000000314838322','FB-000000274951277','FB-000000311382841','FB-000000300769195','FB-000000275107313','FB-000000275011281','FB-000000263525271','FB-000000275107307','FB-000000300769205','FB-000000275107312','FB-000000287624338','FB-000000311382845','FB-000000293126677','FB-000000272890276','FB-000000306421212','FB-000000277868138','FB-000000275107322','FB-000000312448744','FB-000000312448731','FB-000000308281449','FB-000000312921439','FB-000000314838321','FB-000000245378677','FB-000000290403149','FB-000000290404222','FB-000000274951295','FB-000000298889616','FB-000000293126676','FB-000000277868123','FB-000000285617017','FB-000000293126675','FB-000000263525260','FB-000000275107316','FB-000000298916114','FB-000000312448742','FB-000000245378696','FB-000000275508094','FB-000000275508090','FB-000000245375603','FB-000000245385237','FB-000000275508103','FB-000000245378704','FB-000000312921438','FB-000000308281440','FB-000000311382849','FB-000000308281439','FB-000000290251628','FB-000000298889622','FB-000000298916099','FB-000000298916098','FB-000000298916115','FB-000000275290756','FB-000000275107310','FB-000000245385240','FB-000000274951286','FB-000000245375587','FB-000000275011259','FB-000000274951282','FB-000000295509157','FB-000000312921447','FB-000000290404234','FB-000000275011294','FB-000000245375612') -- ������
--and w.code = '312365'
and op.ID_OP in (-1603616786)
--and op.ID_OP = -1166061926
--'0150320000001206856')--,'0010255000001942949','0014247000001191302'
,-1634778819
,-1634748957
,-1634441494
,-1634764631
,-1634646449
,-1634763954


-- ��� �������� �� �� � ��
select s.id_send_status, op.ID_OP, op.id_top, a.name, a.code, a.ID_ART, op.OPDATE, op.opnumber, oa.QUANTITY
from
whs.article a
join whs.op_art oa on oa.ID_ART = a.ID_ART
join whs.operation op on op.ID_OP = oa.ID_OP
--join whs.typeop t on t.ID_TOP = op.ID_TOP;
--join whs.contractor c on c.id_contr = op.ID_CONTR
join whs.warehouse wh on wh.id_ws = op.ID_WSI
left join doc_egais.send_doc_egais_tbl s on s.id_send_base = op.id_op
where a.CODE in('1000206117')-- and wh.code = '230495' and op.opdate >= '01.01.2016'
and op.ID_OP in (-1603616786,-1634778819,-1634748957,-1634441494,-1634764631,-1634646449,-1634763954)
--where a.ID_ART in (458521, 451495) and wh.code = '120103' and op.opdate >= '01.01.2016'

-- ��
-- ��� ������� ��� ��
with docs as (
select distinct wh. code, wh.fullname, t.task_number, t.task_date, d.id_document, d.isdeleted, d.id_doctype, d.docnumber, d.docdate, d.lastdate as dlastdate, r.lastdate
from doc_egais.doc_revise_tbl r
left join whs.doc_task_tbl t on t.id_task = r.id_task
left join whs.warehouse wh on wh.id_ws = t.id_ws
left join whs.doc_task_lnk_tbl l on t.id_task = l.id_task
LEFT JOIN whs.DOCUMENT d ON d.id_document = l.id_document
LEFT JOIN whs.doc_rda_detail rd ON d.id_document = rd.id_document
where 
r.lastdate >= '01.08.17' and r.lastdate <= '10.08.17' -- �� ���� ������
--wh.code = '563356' -- �� ��
and (r.result_full like ('����������� ��������� � ��� �����������%') 
    OR r.result_full like ('���������� ���������� ������� ������%') 
    OR r.result_full like ('����������� �������� ��� �� ������%'))
and d.id_doctype in (376,377,2,481,477,478)
)
, tasks as (
select distinct d.code, d.fullname, d.task_number, d.lastdate, d.task_date from docs d
)
, d2 as (
select docs.task_number, docs.id_doctype, count (docs.id_document) as d2, docs.dlastdate, docs.docnumber, docs.docdate
from docs
where docs.id_doctype = 2 and (docs.isdeleted is null OR docs.isdeleted = 0)
group by docs.task_number, docs.id_doctype, docs.dlastdate, docs.docnumber, docs.docdate
)
, d376_377 as (
select docs.task_number, docs.id_doctype, count (docs.id_document) as d376
from docs
where docs.id_doctype in (377,376) and (docs.isdeleted is null OR docs.isdeleted = 0)
group by docs.task_number, docs.id_doctype
)
, d477_478 as
(
select docs.task_number, docs.id_doctype, count (docs.id_document) as d477
from docs
where docs.id_doctype in (477,478) and (docs.isdeleted is null OR docs.isdeleted = 0)
group by docs.task_number, docs.id_doctype
)
, d481 as
(
select docs.task_number, docs.id_doctype, docs.isdeleted, max (docs.id_document) as id_document, docs.docnumber, docs.docdate
from docs
where docs.id_doctype in (481)
group by docs.task_number, docs.id_doctype, docs.isdeleted, docs.docnumber, docs.docdate
)
, finale as (
select distinct d.code, d.fullname, d.task_number, d.task_date, d481.id_document, d481.id_doctype, d481.isdeleted, d481.docnumber, d481.docdate, d2.d2, d2.dlastdate, d2.docnumber as d2docnumber, d2.docdate as d2docdate, d376_377.d376, d477_478.d477
from tasks d
left join d481 on d481.task_number = d.task_number
left join d2 on d2.task_number = d.task_number
left join d376_377 on d376_377.task_number = d.task_number
left join d477_478 on d477_478.task_number = d.task_number
where d376_377.d376 > d477_478.d477 OR d477_478.d477 is null OR d481.id_document is null
)
select distinct * from finale


select * from doc_egais.wbinformbreg_doc_content_tbl where id_document = 669215426
select * from doc_egais.waybill_doc_content_tbl where id_document = 669215415
select * from doc_egais.product_tbl p where p.id_product = 101385377
select * from doc_egais.waybill_doc_header_tbl wb where wb.wb_number like 'N000017557' and wb.wb_date = '30.05.2017'
select wb.id_document from doc_egais.waybill_doc_header_tbl wb where wb.wb_number like '��-00031200' and wb.wb_date = '30.05.2017'


select * from doc_egais.wbinformbreg_doc_header_tbl wbh
/*join whs.docreference dr on dr.id_doc_depend = wbh.id_document
join whs.document d on d.id_document = dr.id_doc_master and d.id_doctype = 481*/
where wbh.wb_reg_id = '��N-0135579773'


select * from whs.document where id_document = 658238474

select d.* from whs.docreference dr
join whs.document d on d.id_document = dr.id_doc_depend
where dr.id_doc_master = 658237667


-- ��� �� ������� ������ �� ����
with tp as (
select c.id_document as id_document, count (1) as tp
from doc_egais.waybill_doc_content_tbl c
where c.id_document = 658024587 -- ����
group by c.id_document
)
, d477_478 as (
select dr.id_doc_master as id_document, count (distinct d.id_document) as d477
from tp
join whs.docreference dr on dr.id_doc_master = tp.id_document
left join whs.document d on d.id_document = dr.id_doc_depend and d.id_doctype in (477, 478) and (d.isdeleted is null OR d.isdeleted = 0)
group by dr.id_doc_master
)
select 
tp.id_document
, tp.tp
, d477_478.d477 
, case when (d477_478.d477 = 0 OR d477_478.d477 < tp.tp*2) then '1'
       else '0' end as request
from tp 
join d477_478 on d477_478.id_document = tp.id_document


select wb.id_document from doc_egais.waybill_doc_header_tbl wb where wb.wb_number like '��-00031200' and wb.wb_date = '30.05.2017'


with tp as ( select c.id_document as id_document, count (1) as tp from doc_egais.waybill_doc_content_tbl c where c.id_document = " + dt_freg_bsmd.Rows[0]["ID_DOCUMENT"].ToString() + " group by c.id_document) , d477_478 as ( select dr.id_doc_master as id_document, count (distinct d.id_document) as d477 from tp join whs.docreference dr on dr.id_doc_master = tp.id_document left join whs.document d on d.id_document = dr.id_doc_depend and d.id_doctype in (477, 478) group by dr.id_doc_master ) select  tp.id_document , tp.tp , d477_478.d477  , case when (d477_478.d477 = 0 OR d477_478.d477 < tp.tp*2) then '1'        else '0' end as request from tp  join d477_478 on d477_478.id_document = tp.id_document

begin doc_egais.support_api.queueAB_with_change_fsrarid(p_id_document => 655355352); end;

select * from whs.document d where d.id_document = 655355352

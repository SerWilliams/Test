--�������� (������� ��������� ���������� ����� ��� �� �������)
           with doc as
     (select  id_task -- �� �������
            ,r.id_document
            ,r.alc_code
            ,r.quantity
            ,d.id_document id_doc_formreg
            ,d.id_position
            ,d.reg_id_b
            ,row_number() over(partition by d.id_document, r.alc_code order by d.id_wbinformbreg_doc_content) rn
        from whs.redistrib_task_doc_content_tbl r
        join doc_egais.wbinformbreg_doc_content_tbl d on r.reg_id_b = d.reg_id_b
       where r.id_task =  :p_task ),
    doc_cmplt as
     (select /*+ index(r, RDAD_GENERAL_PARTB_PK)*/
       d.id_task
      ,r.id_document
      ,d.quantity
      ,d.alc_code
      ,h.id_shipper
      ,b.reg_id
      ,r.id_art
        from doc d
        join doc_egais.wbinformbreg_doc_header_tbl h on d.id_doc_formreg = h.id_document
        join doc_egais.replyformb_doc_header_tbl b on d.reg_id_b = b.reg_id
        join whs.docreference dr on b.id_document = dr.id_doc_master
                                and dr.reftype = 'A'
        join whs.rdad_general_partb_tbl r on dr.id_doc_depend = r.id_document
       where rn = 1),
    vnd as
     (select op.id_op
            ,d.id_document
        from doc_cmplt d
        join whs.doc_op dop on d.id_document = dop.id_document
        join whs.operation op on dop.id_op = op.id_op
                             and op.id_top = 169),
    vendetta as
     (select /*+ index(op, P_OPERATION)*/
       d.id_document
      ,case
         when decode(wbc.reg_id_a, v.old_reg_id_a, 1, 0) = 1
              and decode(wbc.reg_id_b, v.old_reg_id_b, 1, 0) = 1 then
          0
         else
          1
       end v
      ,row_number() over(partition by d.id_document, v.id_op order by v.move_date desc) rn
      ,v.id_op
        from doc_cmplt d
        join doc_egais.wbinformbreg_doc_content_tbl dc on d.reg_id = dc.reg_id_b
        join whs.docreference dr on dc.id_document = dr.id_doc_depend
                                and dr.reftype = 'D'
        join whs.document dd on dr.id_doc_master = dd.id_document
                            and dd.id_doctype = 481
        join whs.doc_op dop on dd.id_document = dop.id_document
        join whs.operation op on dop.id_op = op.id_op
                             and op.id_top = 1
        join doc_egais.waybill_doc_content_tbl wbc on dd.id_document = wbc.id_document
                                                  and wbc.id_position = dc.id_position

        join vnd on d.id_document = vnd.id_document

        join doc_egais.vdt_moverests_log_tbl v on v.id_op = vnd.id_op),
    fact_redist as
     (select d.id_document
            ,sum(rf.quantity) qnt
        from doc_cmplt d
       join whs.redistribution_task_fact_tbl rf on d.id_document = rf.id_document
       where rf.redistribution_date >= trunc(sysdate)
       group by d.id_document),
    apb as
     (select r.id_task
            ,ft.id_foreign_task
            ,ft.id_ws_rc
            ,t.id_ws_from
            ,acc.id_document
            ,acc.id_art
            ,case
               when nvl(af.vnumber, 0) != 0 then
                (r.quantity / af.vnumber)
               else
                r.quantity
             end quantity
            ,td.quantity quantity_required
            ,td.quantity_rc quantity_rc_max
            ,td.quantity_act_b quantity_rc_pre_2016
        from whs.redistrib_task_doc_content_tbl r
      --
        join doc_egais.actinvinfbreg_doc_infb_tbl i on r.reg_id_b = i.reg_id_b
        join doc_egais.actinvinfbreg_doc_cont_tbl c on c.id_actinvinfbreg_doc_cont = i.id_actinvinfbreg_doc_cont
        join whs.docreference dr2 on dr2.id_doc_depend = c.id_document
                                 and dr2.reftype = 'D'
        join whs.docreference dr3 on dr3.id_doc_master = dr2.id_doc_master
                                 and dr3.reftype = 'A'
        join whs.act_charge_content acc on acc.id_document = dr3.id_doc_depend

        left join whs.redistribution_task_tbl t on r.id_task = t.id_task
        join whs.redistribution_task_detail_tbl td on t.id_task = td.id_task
                                                  and td.id_art = acc.id_art
        join whs.redistr_foreign_task_tbl ft on t.id_task = ft.id_task
        join whs.redistr_fr_task_det_tbl ftr on ft.id_foreign_task = ftr.id_foreign_task
                                            and ftr.id_art = acc.id_art
      -- Ii?aaaeaiea ioeuoeiaea
        left join onsi.art_faset_tbl af
        join onsi.faset_attribute_tbl fattr
        join onsi.attribute_tbl attr on attr.attribute_guid = fattr.attribute_guid
                                    and attr.attrib_fullname = 'Spec_Tabak/PacksQuan' on
       fattr.id_faset_attribute = af.id_faset_attribute on acc.id_art = af.id_art
       where r.id_task = :p_task -- �� �������
         and (select sum(fr.quantity_act_b)
                from whs.redistr_fr_task_det_tbl fr
               where fr.id_task = :p_task) > 0), -- �� �������
    fact_redist_apb as
     (select d.id_document
            ,sum(rf.quantity) qnt
        from apb d
        join whs.redistribution_task_fact_tbl rf on d.id_document = rf.id_document
       where rf.redistribution_date >= trunc(sysdate)
       group by d.id_document),
    res as
     (select /*+ index(rdad, RDAD_GENERAL_PARTB_PK)*/
       d.id_task
      ,ft.id_foreign_task
      ,w.id_ws
      ,t.id_ws_from
      ,d.id_document
      ,akl.id_article
      ,case
         when nvl(af.vnumber, 0) != 0 then
          (d.quantity / af.vnumber) - nvl(fr.qnt, 0)
         else
          d.quantity - nvl(fr.qnt, 0)
       end qnt
      ,td.quantity
      ,td.quantity_rc
      ,td.quantity_act_b
        from doc_cmplt d
      -- Ii?aaaeyai ?O
        join doc_egais.organization_tbl o on d.id_shipper = o.id_organization
        join onsi_egais.organization_tbl oo on o.code = oo.code
        join onsi_egais.org_kpp_link_tbl okl on oo.id_organization = okl.id_organization
        join onsi.div_kpp_tbl dk on okl.id_div_kpp = dk.id_div_kpp
        join onsi_out.division_storage_vw ds on dk.id_div = ds.id_div
                                             or dk.id_div = ds.id_div_alc
        join whs.storage_tbl w on ds.id_ws = w.id_ws
      -- Ii?aaaeyai OI
        join onsi_egais.alc_product_tbl ap on ap.alc_code = d.alc_code
        join onsi_egais.alc_org_link_tbl aol on ap.id_alc_product = aol.id_alc_product
                                            and aol.isdeleted != 1
        join onsi_egais.alc_prod_prov_link_tbl ppl on aol.id_alc_org_link = ppl.id_alc_org_link
                                                  and ppl.is_deleted != 1
        join whs.article_kiscontr_link akl on ppl.id_article_kiscontr_link = akl.id_article_kiscontr_link
                                          and akl.id_article = d.id_art
      --
/*        join whs.rdad_general_partb_tbl rdad on d.id_document = rdad.id_document
                                            and akl.id_article = rdad.id_art*/
      --
        join whs.redistribution_task_tbl t on d.id_task = t.id_task
        join whs.redistr_foreign_task_tbl ft on d.id_task = ft.id_task
                                            and ft.id_ws_rc = (select w2.id_ws
                                                                 from whs.warehouse w2
                                                                where w2.name = '�������'
                                                               connect by prior w2.id_ws = w2.higher
                                                                start with w2.id_ws = w.id_ws)
       join whs.redistr_fr_task_det_tbl td on ft.id_foreign_task = td.id_foreign_task
                                       and td.id_art = akl.id_article
        left join vendetta v on d.id_document = v.id_document
                            and v.rn = 1
        left join fact_redist fr on d.id_document = fr.id_document
      -- Ii?aaaeaiea ioeuoeiaea
        left join onsi.art_faset_tbl af
        join onsi.faset_attribute_tbl fattr
        join onsi.attribute_tbl attr on attr.attribute_guid = fattr.attribute_guid
                                    and attr.attrib_fullname = 'Spec_Tabak/PacksQuan' on
       fattr.id_faset_attribute = af.id_faset_attribute on akl.id_article = af.id_art
      --where nvl(v.v, 0) != 1
       group by d.id_task
               ,ft.id_foreign_task
               ,w.id_ws
               ,t.id_ws_from
               ,d.id_document
               ,akl.id_article
               ,d.quantity
               ,td.quantity
               ,td.quantity_rc
               ,td.quantity_act_b
               ,case
                  when nvl(af.vnumber, 0) != 0 then
                   (d.quantity / af.vnumber) - nvl(fr.qnt, 0)
                  else
                   d.quantity - nvl(fr.qnt, 0)
                end
      union all
      select id_task
            ,id_foreign_task
            ,id_ws_rc
            ,id_ws_from
            ,a.id_document
            ,id_art
            ,quantity - nvl(f.qnt, 0)
            ,quantity_required
            ,quantity_rc_max
            ,quantity_rc_pre_2016
        from apb a
        left join fact_redist_apb f on a.id_document = f.id_document)
    select *
  from res;

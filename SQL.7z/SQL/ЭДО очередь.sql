-- ��������� ������ � �������� � ��������� ��
select 
ww.id_send_base
, ww.id_send_status
, ww.id_document
, rr.reg_id_a
, rr.reg_id_b
, rr.id_analyticopart
, cast(substr(t0.operation_comment, 1, 4000) as varchar2(4000)) "O_Comment"
, cast(substr(t1.comments, 1, 4000) as varchar2(4000)) "D_Comment"
, ww.description
, rr.id_position
, rr.id_document
, rr.id_product
, tt.alc_code
, tt.full_name
from doc_egais.send_doc_egais_tbl ww
left join whs.docreference df on df.id_doc_master = ww.id_document
--  left join whs.document wd
--   on wd.id_document = ww.id_document
left join doc_egais.ticket_doc_header_tbl th on th.id_document = nvl(ww.id_ticket, df.id_doc_depend)
--left join doc_egais.TICKET_DOC_HEADER_TBL yy on yy.id_document= ww.id_ticket
left join doc_egais.ticket_doc_opresult_tbl t0
    on t0.id_ticket_doc_opresult = th.id_ticket_doc_opresult
left join doc_egais.ticket_doc_result_tbl t1
    on t1.id_ticket_doc_result = th.id_ticket_doc_result
--left join doc_egais.TICKET_DOC_OPRESULT_TBL uu on yy.ID_TICKET_DOC_OPRESULT= uu.ID_TICKET_DOC_OPRESULT
left join doc_egais.WAYBILL_DOC_CONTENT_TBL rr on ww.id_document = rr.id_document
left join doc_egais.product_tbl tt on rr.id_product=tt.id_product

where ww.id_send_base in (-1207110541)

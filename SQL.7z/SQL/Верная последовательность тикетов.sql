-- ������ ������������������ ������� �� �������
with doc_whs as
(
select /*+ materialise index(op P_OPERATION) index(de483 WBINFBR_DOC_HEADER_PK)
        index(do IDX_DOCOP_OP) index(d481 PK_DOCUMENT)
        index(d483 PK_DOCUMENT) index(de483 WBINFBR_DOC_HEADER_PK)
        index(dr482 IDX_DOCREF_MASTER)  */
   op.ID_OP
  ,d481.id_document d481_id
  ,d481.id_doctype d481_type
  ,d481.isdeleted d481_isdel
  ,d483.id_document d483_id
  ,de483.wb_reg_id wb_reg_id
  ,d483.isdeleted d483_isdel
  ,d482.id_document d482_id
  ,d482.id_doctype d482_type
  ,d482.isdeleted d482_isdel
    from whs.operation op
    join whs.doc_op do on do.id_op = op.ID_OP
    join whs.document d481 on d481.id_document = do.id_document
                           and d481.id_doctype = 481
    left join whs.docreference dr483 on dr483.id_doc_master = d481.id_document
    join whs.document d483 on d483.id_document = dr483.id_doc_depend
                           and d483.id_doctype = 483
    left join doc_egais.wbinformbreg_doc_header_tbl de483 on de483.id_document = d483.id_document
    left join whs.docreference dr482 on dr482.id_doc_master = d481.id_document
    join whs.document d482 on d482.id_document = dr482.id_doc_depend
                           and d482.id_doctype = 482
   where op.id_op in (-1770290053)
  ),
doc_eg as
(
  select
  /*+ index(de482 WAYBILLACT_DOC_HEADER_PK)*/
   doc_whs.ID_OP
  ,doc_whs.d481_id
  ,doc_whs.d481_type
  ,doc_whs.d481_isdel
  ,doc_whs.d483_id
  ,doc_whs.wb_reg_id
  ,doc_whs.d483_isdel
  ,doc_whs.d482_id
  ,doc_whs.d482_type
  ,de482.wb_reg_id d482_eb_reg_id
  ,doc_whs.d482_isdel
    --, d480.id_document
    --, d480.id_doctype 
  ,d4801.id_document d4801_id
  ,d4801.id_doctype d4801_type
  , t1r.conclusion             d4801_conclu
  ,d4801.docdate as d4801_date
  ,d4801.isdeleted d4801_isdel
  ,case
      when (select /*+ index(re IDX_DOCREF_MASTER) index(d4801 PK_DOCUMENT)
                    index(d4802 PK_DOCUMENT) index(t2 TMP_IDX2)
                    */
           count(*)
              from whs.docreference re
             where re.id_doc_master = doc_whs.d482_id
               and re.id_doc_depend = d4801.id_document) > 0
       then
       '����'
      else
       '���'
    end
    as "����� ��� 1 � 482"
    ,d4802.id_document d4802_id
    ,d4802.id_doctype d4802_type
    ,d4802.docdate d4802_date
    ,d4802.isdeleted d4802_isdel
    ,case
      when (select /*+ index(re IDX_DOCREF_MASTER)
                   index(t1 TICKET_DOC_HEADER_IDENTITY_IDX) */
                   count(*)
              from whs.docreference re
             where re.id_doc_master = doc_whs.d482_id
               and re.id_doc_depend = d4802.id_document) > 0
       then
       '����'
      else
       '���'
    end
    as "����� ��� 2 � 482"
    from doc_whs
  -- identity ���� 482
    left join doc_egais.waybillact_doc_header_tbl de482 on de482.id_document = doc_whs.d482_id
  -- identity � transport id 480 ������ ����� �������� �� ���������
    left join doc_egais.ticket_doc_header_tbl t1 on de482.id_act = t1.identity
    left join doc_egais.ticket_doc_result_tbl t1r on t1r.id_ticket_doc_result = t1.id_ticket_doc_result
    left join whs.document d4801 on d4801.id_document = t1.id_document
  -- ������ ����� �������� �� transport_id
    left join doc_egais.ticket_doc_header_tbl t2 on UPPER(REPLACE(t2.transport_id,'-')) = UPPER(REPLACE(t1.transport_id,'-'))
                                                 and t2.id_document <> t1.id_document
    left join whs.document d4802 on d4802.id_document = t2.id_document
   where t2.id_document is not null
   --and t1r.conclusion = 'Accepted'
   -- ����� ������ �� �������� �������
   and (select count (1)
       from --tdo3.operation_comment
      doc_egais.ticket_doc_opresult_tbl  tdo
      left join doc_egais.ticket_doc_header_tbl  td on td.id_ticket_doc_opresult = tdo.id_ticket_doc_opresult
      left join whs.document d  on td.id_document = d.id_document
      left join whs.docreference dr on dr.id_doc_depend = d.id_document
      join whs.doc_op do on do.id_document = dr.id_doc_master
      join whs.operation op on op.id_op = do.id_op
      where td.id_document = d4802.id_document
       and REGEXP_LIKE (tdo.operation_comment,'��������� �'||trim (op.OPNUMBER)||' �� .+ ������������')) = 1
       )
select * from doc_eg


/*
--��������

op.ID_OP
,op.OPNUMBER
,op.OPDATE
,op.OPSUM
,d481.id_document "481 id"
,d481.isdeleted   "�������"
,d483.id_document "483 id"
,d483.isdeleted   "�������"
,d482.id_document "482 id"
,d482.isdeleted   "�������"
from whs.operation op
join whs.doc_op dop on dop.id_op = op.ID_OP
join whs.document d481 on d481.id_document = dop.id_document and d481.id_doctype = 481
join whs.docreference dr1 on dr1.id_doc_master = d481.id_document
join whs.document d482 on d482.id_document = dr1.id_doc_depend and d482.id_doctype = 482
join whs.docreference dr2 on dr2.id_doc_master = d481.id_document
join whs.document d483 on d483.id_document = dr2.id_doc_depend and d483.id_doctype = 483
where op.ID_OP = -1674472049
*/

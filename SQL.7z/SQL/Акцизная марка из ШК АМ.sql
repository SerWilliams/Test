declare
  function get10from36(p_base36 in varchar2) return varchar2 as
    l_result number := 0;
    l_base   varchar2(500 char) := upper(p_base36);
    l_len    number;
  begin
    -- ����� ����� --
    l_len := length(l_base);
    -- ��������� ��������� --
    --NoFormat Start
    for i in 1..l_len
    loop
      l_result := l_result + (to_number(case substr(l_base,i,1)
                                          when '0' then 0
                                          when '1' then 1
                                          when '2' then 2
                                          when '3' then 3
                                          when '4' then 4
                                          when '5' then 5
                                          when '6' then 6
                                          when '7' then 7
                                          when '8' then 8
                                          when '9' then 9
                                          when 'A' then 10
                                          when 'B' then 11
                                          when 'C' then 12
                                          when 'D' then 13
                                          when 'E' then 14
                                          when 'F' then 15
                                          when 'G' then 16
                                          when 'H' then 17
                                          when 'I' then 18
                                          when 'J' then 19
                                          when 'K' then 20
                                          when 'L' then 21
                                          when 'M' then 22
                                          when 'N' then 23
                                          when 'O' then 24
                                          when 'P' then 25
                                          when 'Q' then 26
                                          when 'R' then 27
                                          when 'S' then 28
                                          when 'T' then 29
                                          when 'U' then 30
                                          when 'V' then 31
                                          when 'W' then 32
                                          when 'X' then 33
                                          when 'Y' then 34
                                          when 'Z' then 35
                                         end) * power(36,l_len - i));
    end loop;
    --NoFormat End
    return to_char(l_result);
  end get10from36;
  function get_alc_code_fnc(p_exise varchar2) return varchar2 as
  begin
    return lpad(get10from36(substr(p_exise, 4, 16)), 19, 0);
  end;
begin
  dbms_output.put_line(get_alc_code_fnc('22N000004ZCBO35FKAG0E1Y7061500103795IZU5R39W4WIAAZL9R9JNFB6JHOESKA8')); -- ���� ���� ���������� ���� ������
end;

-- ��� ������� ���������������� � �� (���. ����)
with ri as --������ ������ �����
(
select r.id_art, r.id_ws, wh.code as wscode, a.CODE as art_code, a.NAME, max (r.rowid) as ri
from whs.rest r
join whs.warehouse wh on wh.id_ws = r.id_ws
join whs.article a on a.ID_ART = r.id_art
join whs.art_moreinfo am on am.id_art = r.id_art
join whs.addition adi on adi.ID_ADD = am.id_add
where 
wh.code = '610202'/*--'483638'-- '782527''550028'--
--wh.lg1 in (101,201)*/ 
and am.vstring not like '000' -- ���������� ��������������� ����
and adi.name like '���_���'
group by r.id_ws, wh.code, r.id_art, a.CODE, a.NAME
)
, rest_tu as (
select ri.id_art, ri.id_ws, ri.wscode, ri.ri, r.fquant, r.lastdate, a.CODE as art_code /* r.**/ from ri
join whs.rest r on r.rowid = ri.ri
join whs.article a on a.id_art = ri.id_art
where r.fquant > 0
)
, pr as (
select rtb.wscode, rtb.alc_code/*, rtb.rest_type*/, sum (rtb.quantity) as quantity from retail.registr_tbl rtb
where rtb.wscode = '610202'
and rtb.reg_id_b is not null
and rtb.rest_type in (1,2,5)
and rtb.move_type = 'P'
group by rtb.wscode, rtb.alc_code, --, rtb.rest_type 
)
, ras as (
select rtb.wscode, rtb.alc_code/*, rtb.rest_type*/, sum (rtb.quantity) as quantity from retail.registr_tbl rtb
where rtb.wscode = '610202'
and rtb.reg_id_b is not null
and rtb.rest_type in (1,2,5)
and rtb.move_type = 'M'
group by rtb.wscode, rtb.alc_code--, rtb.rest_type 
)
, rest_vw as (
select
vw.wscode
, vw.alc_code as alc_code
, vw.art_code as art_code
, sum (vw.quantity) as quantity
from RETAIL.Registr_Rest_Vw vw
where vw.wscode = '610202' and vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code, vw.art_code
)
select rest_vw.*, rest_tu.fquant as "���-�� � ��", (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) as "������ - ������",
case
  when rest_tu.fquant <= rest_vw.quantity then
       case when rest_tu.fquant <= (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) then rest_tu.fquant
    else (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) end
  else
    case when rest_vw.quantity <= (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) then rest_vw.quantity
    else (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) end
  end as "�������� ����������������"
from rest_tu
left join rest_vw on rest_vw.wscode = rest_tu.wscode and rest_vw.art_code = rest_tu.art_code
left join pr on pr.wscode = rest_vw.wscode and pr.alc_code = rest_vw.alc_code
left join ras on ras.wscode = rest_vw.wscode and ras.alc_code = rest_vw.alc_code
where rest_vw.quantity > 0




-- ��� ������� ���������������� � �� (������, ���� �������)
with ri as --������ ������ �����
(
select r.id_art, r.id_ws, wh.code as wscode, a.CODE as art_code, a.NAME, max (r.rowid) as ri
from whs.rest r
join whs.warehouse wh on wh.id_ws = r.id_ws
join whs.article a on a.ID_ART = r.id_art
join whs.art_moreinfo am on am.id_art = r.id_art
join whs.addition adi on adi.ID_ADD = am.id_add
where 
wh.code = '610202'/*--'483638'-- '782527''550028'--
--wh.lg1 in (101,201)*/ 
and am.vstring not like '000' -- ���������� ��������������� ����
and adi.name like '���_���'
group by r.id_ws, wh.code, r.id_art, a.CODE, a.NAME
)
, rest_tu as (
select ri.id_art, ri.id_ws, ri.wscode, ri.ri, r.fquant, r.lastdate, a.CODE as art_code /* r.**/ from ri
join whs.rest r on r.rowid = ri.ri
join whs.article a on a.id_art = ri.id_art
where r.fquant > 0
)
, pr as (
select rtb.wscode, rtb.alc_code, rtb.reg_id_b /*, rtb.rest_type*/, sum (rtb.quantity) as quantity from retail.registr_tbl rtb
where rtb.wscode = '610202'
and rtb.reg_id_b is not null
and rtb.rest_type in (1,2,5)
and rtb.move_type = 'P'
group by rtb.wscode, rtb.alc_code, rtb.reg_id_b--, rtb.rest_type 
)
, ras as (
select rtb.wscode, rtb.alc_code, rtb.reg_id_b/*, rtb.rest_type*/, sum (rtb.quantity) as quantity from retail.registr_tbl rtb
where rtb.wscode = '610202'
and rtb.reg_id_b is not null
and rtb.rest_type in (1,2,5)
and rtb.move_type = 'M'
group by rtb.wscode, rtb.alc_code, rtb.reg_id_b--, rtb.rest_type 
)
, rest_vw as (
select
vw.wscode
, vw.alc_code as alc_code
, vw.art_code as art_code
, sum (vw.quantity) as quantity
from RETAIL.Registr_Rest_Vw vw
where vw.wscode = '610202' and vw.rest_type in ('1','2','5')
group by vw.wscode, vw.alc_code, vw.art_code
)
select distinct a.NAME, p.alc_art_code as "���", rest_vw.*, pr.reg_id_b, rest_tu.fquant as "���-�� � ��", (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) as "������ - ������",
ra.bottling_date as "���� �������",
case
  when rest_tu.fquant <= rest_vw.quantity then
       case when rest_tu.fquant <= (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) then rest_tu.fquant
    else (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) end
  else
    case when rest_vw.quantity <= (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) then rest_vw.quantity
    else (nvl (pr.quantity, 0) - nvl (ras.quantity, 0)) end
  end as "�������� ����������������"
, wc.id_analyticopart as "���������"
from rest_tu
left join rest_vw on rest_vw.wscode = rest_tu.wscode and rest_vw.art_code = rest_tu.art_code
left join pr on pr.wscode = rest_vw.wscode and pr.alc_code = rest_vw.alc_code
left join ras on ras.wscode = rest_vw.wscode and ras.alc_code = rest_vw.alc_code
left join doc_egais.wbinformbreg_doc_content_tbl wbf on wbf.reg_id_b = pr.reg_id_b
left join doc_egais.wbinformbreg_doc_header_tbl wbh on wbh.id_document = wbf.id_document
left join doc_egais.waybill_doc_header_tbl wh on wh.identity = wbh.id_wb
left join doc_egais.waybill_doc_content_tbl wc on wc.id_document = wh.id_document and wc.wbi_reg_id_b = wbf.reg_id_b
left join doc_egais.product_tbl p on p.id_product = wc.id_product
left join doc_egais.replyforma_doc_header_tbl ra on ra.reg_id = wc.reg_id_a
join whs.article a on a.CODE = rest_vw.art_code
where rest_vw.quantity > 0
and pr.reg_id_b is not null



-- ���� ������� �� FB-���
select distinct wbf.reg_id_b, ra.bottling_date from doc_egais.wbinformbreg_doc_content_tbl wbf
join doc_egais.wbinformbreg_doc_header_tbl wbh on wbh.id_document = wbf.id_document
join doc_egais.waybill_doc_header_tbl wh on wh.identity = wbh.id_wb
join doc_egais.waybill_doc_content_tbl wc on wc.id_document = wh.id_document and wc.wbi_reg_id_b = wbf.reg_id_b
join doc_egais.product_tbl p on p.id_product = wc.id_product
join doc_egais.replyforma_doc_header_tbl ra on ra.reg_id = wc.reg_id_a
where wbf.reg_id_b = 'FB-000000090030685'

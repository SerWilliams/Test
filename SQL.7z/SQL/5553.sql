select /*+ INDEX (I_OPERATION op)*/
-- w.code,w.fullname,
  --op.opdate,
  op.id_top,top.fullname,
  --sdt.id_doctype,
  sdt.id_Send_status,max(op.opdate),count(op.id_op) 
  
  
  
  
  from doc_egais.send_doc_egais_tbl sdt
  join whs.operation op on op.id_op = sdt.id_send_base
  join whs.typeop top on top.id_top = op.id_top
  join whs.warehouse w on w.id_ws = op.id_wso and w.lg1=601
  where 1=1 
  and op.id_top = 169 and sdt.id_send_type = 1
  and ((sdt.last_work_date > to_date('24.08.2016','dd.mm.yyyy')
  and op.opdate > to_date('24.08.2016','dd.mm.yyyy')
and w.fullname not like '%������������%' and w.fullname not like '%�����������%')
  or
  (sdt.last_work_date > to_date('29.08.2016','dd.mm.yyyy')
  and op.opdate > to_date('29.08.2016','dd.mm.yyyy')
  and w.fullname like '%������������%')
  or
  (sdt.last_work_date > to_date('06.09.2016','dd.mm.yyyy')
  and op.opdate > to_date('06.09.2016','dd.mm.yyyy')
  and w.fullname like '%�����������%'))
  
  
  group by
  op.id_top,top.fullname,
  sdt.id_Send_Status
  order by sdt.id_Send_Status

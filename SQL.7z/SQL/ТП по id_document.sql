select distinct
       --wh.id_document
      p.full_name
      --,p.short_name
      ,p.alc_art_code
      ,wc.quantity
      ,wc.price
      ,ra.bottling_date
      ,p.alc_code
  from doc_egais.waybill_doc_header_tbl wh
  join doc_egais.waybill_doc_content_tbl wc on wc.id_document = wh.id_document
  join doc_egais.product_tbl p on p.id_product = wc.id_product
  join doc_egais.replyforma_doc_header_tbl ra on ra.reg_id = wc.reg_id_a
 where wh.id_document = 141501087
 
 -- ������� �� ����
  SELECT doc.docnumber, doc.docdate, df.filename, df.lastdate
FROM whs.DOCUMENT doc
jOIN WHS.docfileset dfs ON dfs.id_document = doc.id_document
JOIN whs.docfile df ON df.id_dfs = dfs.id_Dfs
WHERE 
--doc.docguid in hextoraw('6A28BF2CC1D0450099F2439E93C7AF37')
doc.id_document in (
  SELECT dref.id_doc_depend
   FROM whs.docreference dref
    JOIN whs.DOCUMENT doc2 ON doc2.id_document = dref.id_doc_depend
       WHERE
      dref.id_doc_master IN (133573575) -- ����������� id ����, ��� (481)
      and doc2.id_doctype = 477
)
--df.filename like ('6A28BF2CC1D0450099F2439E93C7AF37%')
 
 
 

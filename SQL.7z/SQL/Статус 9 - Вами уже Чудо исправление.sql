----------���� �����������------------------------------------------------------ ��� ��
begin
  for cur in (select /*+ leading(sde, opr)
                         index(opr p_operation) use_nl(opr)*/
                     max(tk.id_document) id_tk,
                     max(tk2.id_document) id_tk1,
                     wa.id_document id_wa,
                     sde.id_send,
                     sde.id_document
                from doc_egais.send_doc_egais_tbl sde
                    ,whs.operation opr
                    ,whs.doc_op dp
                    ,doc_egais.waybillact_doc_header_tbl wa
                    ,whs.docreference rf
                    ,doc_egais.ticket_doc_header_tbl tk
                    ,doc_egais.ticket_doc_opresult_tbl tor
                    ,whs.docreference rf2
                    ,doc_egais.ticket_doc_header_tbl tk2
                    ,doc_egais.ticket_doc_result_tbl tr
               where sde.id_send_type = 1
                 and sde.id_send_status = 9
                 and sde.id_doctype = 482
                 and opr.ID_OP = sde.id_send_base
                 and opr.opdate >= to_date('01.07.2016')
                 and dp.id_op = opr.ID_OP
                 and wa.id_document = dp.id_document
                 and rf.id_doc_master = wa.id_document
                 and tk.id_document = rf.id_doc_depend
                 and tor.id_ticket_doc_opresult = tk.id_ticket_doc_opresult
                 and tor.operation_result = 'Accepted'
                 and rf2.id_doc_master = wa.id_document
                 and tk2.id_document = rf2.id_doc_depend
                 and tr.id_ticket_doc_result = tk2.id_ticket_doc_result
                 and tr.conclusion = 'Accepted'
               group by sde.id_send,sde.id_document,wa.id_document)
  loop
    update whs.document d
       set d.isdeleted = 1
     where d.id_document = cur.id_document;
     
    update whs.document d
       set d.isdeleted = null
     where d.id_document = cur.id_wa;
     
    update doc_egais.send_doc_egais_tbl sde
       set sde.id_send_status = 11
          ,sde.id_document = cur.id_wa
          ,(sde.id_ticket,sde.ticket_date,sde.ticket_conclusion) = 
           (select cur.id_tk, ticket_date, 'Accepted'
              from doc_egais.ticket_doc_header_tbl
             where id_document = cur.id_tk)
          ,sde.id_ticket1 = cur.id_tk1
     where sde.id_send = cur.id_send;
  end loop;
  commit;
end;

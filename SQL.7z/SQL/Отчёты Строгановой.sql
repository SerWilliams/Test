-----------------------------������� �������--------------2291 ������-------------------------------------    
select w.lg1, ss.id_send_status, count(1), 
case
             when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1� �������'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2� �������'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3� �������'
             end time_queue
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st  on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.warehouse w  on w.id_ws = o.ID_WSI and w.lg1  in (101,201)
join whs.typeop tt on tt.id_top = o.id_top and upper(tt.fullname) like upper('������%�������') 
where  o.opdate >= '01.01.2016'
---o.OPDATE between  '01.07.2016' and '25.07.2016'
and ss.id_send_type = 1
and ss.id_send_status <> 11   
and ss.id_send_status <> 12 
group by case
             when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1� �������'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2� �������'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3� �������'
             end, w.lg1, st.Name, ss.id_send_status;
             
---------------------------���������-------6256 ���------------------------------
select o.id_top, st.Name, ss.id_send_status, count (opnumber),
case
             when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1� �������'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2� �������'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3� �������'
             end "�������"
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st  on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.typeop tt on tt.ID_TOP = o.ID_TOP
where   o.opdate >= '01.01.2016'
--o.OPDATE between  '01.07.2016' and '25.07.2016'
and o.id_top in (477,473)
and ss.id_send_status in (3,9,1,7,10,41)
Group by case
             when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1� �������'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2� �������'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3� �������'
             end, o.id_top, st.Name,  ss.id_send_status;
 ----------===========            
             select * from whs.typeop
             where id_top = 477
             
-----------------------------��� ��������----------------------------------------------------------------
select st.name,st.id_send_status,count(ss.id_send_base)"����",
 case when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1� �������'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2� �������'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3� �������'
             end "�������"
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.warehouse w on w.id_ws = o.ID_WSo and w.lg1 = 601
join whs.typeop tt on tt.ID_TOP = o.ID_TOP 
where o.OPDATE >= '01.01.2016' 
and o.id_top = 169
and ss.id_send_status <> 11
and ss.id_send_status <> 12
and ss.id_send_status <> 4
and ss.id_send_status <> 8
Group by  case when  o.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1� �������'
             when o.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2� �������'
             when o.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3� �������'
             end,
st.id_send_status, st.name;



----------------------------�� �� ����� �� -------------------------------------
select 'OPNUMBER'||';'||'OPDATE'||';'||'CODE'||';'||'LG1' from dual;
with t as(
select op.ID_OP, op.opnumber, op.opdate,  cc.fullname as cname,cc.code, w1.lg1,
w.fullname as wname, oa.id_art, max(oa.QUANTITY) as op_quant, sum(aop.quantity) as an_quant from whs.operation op
left join whs.contractor cc on cc.id_contr=op.id_contr
left join whs.warehouse w on w.id_ws=op.id_wso
left join whs.warehouse w1 on  trim(w1.code) = trim(cc.code)
left join whs.op_art oa on oa.ID_OP = op.ID_OP
left join acan.analyticopart_tbl aop on op.opguid=aop.opguid and oa.ID_ART=aop.id_art
where --trim(op.opnumber) = '560186A1129' 
 --and
op.id_top = 169
and op.opdate between '01.07.206' and '15.07.2016'
and  substr(op.opnumber,7,1)  like 'A'
group by op.ID_OP, oa.id_art, op.opnumber, cc.fullname, w.fullname, op.opdate, cc.code, w1.lg1
), a as(
select
t.opnumber,
t.opdate,
t.code,
t.lg1
from t
group by t.opnumber, t.opdate, t.code, t.lg1
having sum(t.op_quant) <> sum(nvl(t.an_quant,0))
)
select opnumber||';'||opdate||';'|| trim(code)||';'|| lg1
from a;
-------------------------------------------------------------------------------------------
-------------------------------����.�������------------------------------------------------
SELECT ws2.lg1, sdt2.id_send_status, count (op2.id_op) "����",
case when  op.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1� �������'
             when op.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2� �������'
             when op.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3� �������'
             end "�������"
  FROM doc_egais.send_doc_egais_tbl sdt
JOIN whs.operation op ON op.id_op = sdt.id_send_base AND sdt.id_send_type=1
JOIN whs.warehouse ws ON op.id_wso = ws.id_ws
join whs.opreference opr on opr.id_opref=op.id_op and opr.reftype = 'E'
join whs.operation op2 on op2.id_op = opr.id_op
join DOC_EGAIS.Send_Doc_Status_Egais_Tbl sdt1 on sdt1.id_send_status =sdt.id_send_status 
left join doc_egais.send_doc_egais_tbl sdt2 on op2.id_op = sdt2.id_send_base AND sdt.id_send_type=1
left join whs.docreference df ON df.id_doc_master = sdt2.id_document
left join DOC_EGAIS.Ticket_Doc_Header_Tbl tk ON Tk.Id_Document = Df.Id_Doc_Depend
left join DOC_EGAIS.Ticket_Doc_Result_Tbl tor ON Tor.Id_Ticket_Doc_Result = Tk.Id_Ticket_Doc_Result
JOIN whs.warehouse ws2 ON ws2.id_ws = op2.id_wsi
where op.opdate >= '01.01.2016'
--and '31.03.2016' 
and ws.lg1=601
and op.id_top = 169
and ws2.lg1 in (101,201)
and substr(op.opnumber,7,1)  like 'A'
and sdt.id_send_status = 11
and op.opsum<>0
and op2.id_top   in (1,17,634,635)
and (sdt2.id_send_status <> 11 or sdt2.id_send_status is  null)
and sdt2.id_send_status is not null
and sdt2.id_send_status <> 8
group by case when  op.opdate between to_date('01.01.2016') and to_date('31.03.2016') then '1� �������'
             when op.opdate between to_date('01.04.2016') and to_date('30.06.2016') then '2� �������'
             when op.opdate between to_date('01.07.2016') and to_date(sysdate)  then '3� �������'
             end,
ws2.lg1, sdt1.name, sdt2.id_send_status;
--------------------------------------------------------
-----------------------------------------------------------
--------------������� ��---------------------------------
select /*+ index(o, p_operation) index(ss, SEND_DOC_SEND_IDX)*/  tt.id_top, tt.FULLNAME, o.opnumber,o.opdate,
w.fullname, st.id_send_status,st.name,count(*)
from doc_egais.send_doc_egais_tbl ss
join doc_egais.send_doc_status_egais_tbl st on st.id_send_status = ss.id_send_status
join whs.operation o on o.ID_OP = ss.id_send_base
join whs.warehouse w on w.id_ws = o.ID_WSI and w.lg1 = 601
join whs.typeop tt on tt.ID_TOP = o.ID_TOP --and UPPER(tt.FULLNAME) like UPPER('������%')
where o.OPDATE >='01.01.2016'
--and ss.id_send_type in (1,169,473,477)
and o.id_top in (1)
--and  w.fullname like ('%���� �֕�֕�� ������%')
and st.id_send_status in (3,9,1,7,10,41)
Group by  tt.FULLNAME,w.fullname,tt.id_top, o.opnumber,o.opdate,st.id_send_status,st.name
Order by 1,2
